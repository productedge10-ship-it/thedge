/* ==================================================================
   Іконки інструментів — тонкі, у стилі лівої панелі TradingView.
   Свої, а не з lucide: там немає ні Фібоначчі, ні позицій, ні
   каналу, а змішані набори виглядали б латкою.
================================================================== */

const P = {
  'cur-cross': <><path d="M14 4v20M4 14h20" /></>,
  'cur-dot': <><circle cx="14" cy="14" r="3" fill="currentColor" stroke="none" /></>,
  'cur-arrow': <><path d="M8 5l13 8-6 1.5 3.5 6.5-2.5 1.3-3.5-6.6L8 20z" /></>,
  eraser: <><path d="M6 19l9-11 7 6-7 8H10z" /><path d="M11 22h12" /><path d="M10 12l7 6" /></>,
  trend: <><path d="M6 22L22 6" /><circle cx="6" cy="22" r="2" /><circle cx="22" cy="6" r="2" /></>,
  ray: <><path d="M6 22L25 3" /><circle cx="6" cy="22" r="2" /><circle cx="14" cy="14" r="2" /></>,
  info: <><path d="M5 22L19 8" /><circle cx="5" cy="22" r="2" /><circle cx="19" cy="8" r="2" /><path d="M17 20h7M17 24h5" /></>,
  extended: <><path d="M3 25L25 3" /><circle cx="10" cy="18" r="2" /><circle cx="18" cy="10" r="2" /></>,
  angle: <><path d="M5 22L21 8M5 22h18" /><path d="M13 22a8 8 0 0 0-2-6" /></>,
  hline: <><path d="M3 14h22" /><circle cx="14" cy="14" r="2" /></>,
  hray: <><path d="M10 14h16" /><circle cx="8" cy="14" r="2" /></>,
  vline: <><path d="M14 3v22" /><circle cx="14" cy="14" r="2" /></>,
  cross: <><path d="M14 3v22M3 14h22" /><circle cx="14" cy="14" r="2" /></>,
  channel: <><path d="M4 18L18 6M10 24L24 12" /><path d="M7 21L21 9" strokeDasharray="2 2" /></>,
  fib: <><path d="M4 6h20M4 11h20M4 15h20M4 19h20M4 23h20" /><path d="M6 23L22 6" strokeDasharray="2 2" /></>,
  fibext: <><path d="M10 6h15M10 11h15M10 16h15M10 21h15" /><path d="M3 24l5-12 4 8" strokeDasharray="2 2" /></>,
  long: <><path d="M4 14h20" /><rect x="4" y="5" width="20" height="9" fill="currentColor" fillOpacity=".18" /><rect x="4" y="14" width="20" height="7" fill="currentColor" fillOpacity=".08" /><path d="M9 11V7M7 9l2-2 2 2" /></>,
  short: <><path d="M4 14h20" /><rect x="4" y="7" width="20" height="7" fill="currentColor" fillOpacity=".08" /><rect x="4" y="14" width="20" height="9" fill="currentColor" fillOpacity=".18" /><path d="M9 17v4M7 19l2 2 2-2" /></>,
  prange: <><path d="M5 6h18M5 22h18M14 7v14M11 10l3-3 3 3M11 18l3 3 3-3" /></>,
  drange: <><path d="M6 5v18M22 5v18M7 14h14M10 11l-3 3 3 3M18 11l3 3-3 3" /></>,
  dprange: <><rect x="5" y="6" width="18" height="16" rx="1" /><path d="M14 9v10M9 14h10" /></>,
  brush: <><path d="M5 21c3 0 4-2 4-4s1-3 3-3 3 1 3 3" /><path d="M15 17l8-11" /></>,
  highlighter: <><path d="M6 22h16" strokeWidth="4" strokeOpacity=".5" /><path d="M10 18l9-12 3 2-9 12z" /></>,
  rect: <><rect x="5" y="7" width="18" height="14" rx="1" /></>,
  ellipse: <><ellipse cx="14" cy="14" rx="10" ry="7" /></>,
  path: <><path d="M4 20l6-9 6 6 8-11" /><circle cx="10" cy="11" r="1.6" /><circle cx="16" cy="17" r="1.6" /></>,
  arrow: <><path d="M6 22L21 7M13 7h8v8" /></>,
  text: <><path d="M7 7h14M14 7v15M11 22h6" /></>,
  note: <><rect x="10" y="4" width="15" height="10" rx="2" /><path d="M13 14l-8 9" /></>,
  plabel: <><path d="M4 18l4-4h16v8H8z" /><path d="M11 18h9" /></>,
  arrowup: <><path d="M14 5l7 8h-4v9h-6v-9H7z" /></>,
  arrowdown: <><path d="M14 23l7-8h-4V6h-6v9H7z" /></>,
  measure: <><path d="M4 18L18 4l6 6-14 14z" /><path d="M9 13l2 2M12 10l2 2M15 7l2 2" /></>,
  zoom: <><circle cx="12" cy="12" r="7" /><path d="M17 17l6 6M9 12h6M12 9v6" /></>,
  magnet: <><path d="M7 5v9a7 7 0 0 0 14 0V5h-5v9a2 2 0 0 1-4 0V5z" /><path d="M7 9h5M16 9h5" /></>,
  keep: <><path d="M6 22l2-6L19 5l4 4L12 20z" /><path d="M16 8l4 4" /><circle cx="22" cy="22" r="1.5" fill="currentColor" stroke="none" /></>,
  lock: <><rect x="7" y="13" width="14" height="10" rx="2" /><path d="M10 13V9a4 4 0 0 1 8 0v4" /></>,
  unlock: <><rect x="7" y="13" width="14" height="10" rx="2" /><path d="M10 13V9a4 4 0 0 1 7.5-2" /></>,
  eye: <><path d="M3 14s4-7 11-7 11 7 11 7-4 7-11 7S3 14 3 14z" /><circle cx="14" cy="14" r="3" /></>,
  eyeoff: <><path d="M3 14s4-7 11-7c2 0 4 .6 5.5 1.5M25 14s-4 7-11 7c-2 0-4-.6-5.5-1.5" /><path d="M5 23L23 5" /></>,
  trash: <><path d="M6 8h16M11 8V5h6v3M8 8l1 15h10l1-15" /><path d="M12 12v7M16 12v7" /></>,
  gear: <><circle cx="14" cy="14" r="3.5" /><path d="M14 4v3M14 21v3M4 14h3M21 14h3M6.9 6.9l2.1 2.1M19 19l2.1 2.1M6.9 21.1L9 19M19 9l2.1-2.1" /></>,
  clone: <><rect x="9" y="9" width="13" height="13" rx="2" /><path d="M6 18V8a2 2 0 0 1 2-2h10" /></>,
  undo: <><path d="M9 9H5V5" /><path d="M5 9a9 9 0 1 1 2 9" /></>,
};

export default function DrawIcon({ id, size = 28, className = '' }) {
  return (
    <svg width={size} height={size} viewBox="0 0 28 28" fill="none" stroke="currentColor" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round" className={className} aria-hidden>
      {P[id] || P.trend}
    </svg>
  );
}
