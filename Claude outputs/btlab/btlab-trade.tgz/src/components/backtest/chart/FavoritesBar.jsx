import { useEffect, useRef, useState } from 'react';
import { X } from 'lucide-react';
import { T } from '../../../lib/theme';
import { t as tx } from '../../../lib/lang';
import { itemName } from '../../../lib/candles/drawings';
import DrawIcon from './DrawingIcons';

/* ==================================================================
   Панель обраних інструментів — як у TradingView: плаває над
   графіком, тягнеш за «ручку» зліва куди зручно, місце памʼятається.
   Інструменти додаються зірочкою в лівому меню.
================================================================== */

export default function FavoritesBar({ favs, tool, pos, host, onPick, onMove, onClose }) {
  const ref = useRef(null);
  const [at, setAt] = useState(pos || { x: 64, y: 56 });
  const [vertical, setVertical] = useState(!!pos?.v);
  useEffect(() => { if (pos) { setAt({ x: pos.x, y: pos.y }); setVertical(!!pos.v); } }, [pos?.x, pos?.y, pos?.v]); // eslint-disable-line react-hooks/exhaustive-deps

  /* Не даємо панелі вилізти за межі графіка (наприклад, після
     зміни розміру вікна). */
  const clamp = (x, y) => {
    const box = host.current?.getBoundingClientRect();
    const me = ref.current?.getBoundingClientRect();
    if (!box || !me) return { x, y };
    return { x: Math.max(0, Math.min(box.width - me.width, x)), y: Math.max(0, Math.min(box.height - me.height, y)) };
  };

  const startDrag = (e) => {
    e.preventDefault();
    e.stopPropagation();
    const el = e.currentTarget;
    el.setPointerCapture?.(e.pointerId);
    const sx = e.clientX; const sy = e.clientY;
    const start = { ...at };
    let last = start;
    const move = (ev) => { last = clamp(start.x + ev.clientX - sx, start.y + ev.clientY - sy); setAt(last); };
    const up = () => {
      el.removeEventListener('pointermove', move);
      el.removeEventListener('pointerup', up);
      el.removeEventListener('pointercancel', up);
      onMove({ ...last, v: vertical });
    };
    el.addEventListener('pointermove', move);
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
  };

  const flip = () => { const v = !vertical; setVertical(v); onMove({ ...at, v }); };

  return (
    <div
      ref={ref}
      className={`absolute z-[8] flex items-center gap-0.5 rounded-xl p-1 shadow-lg ${vertical ? 'flex-col' : 'flex-row'}`}
      style={{ left: at.x, top: at.y, background: T.surface3, border: `1px solid ${T.lineHi}`, boxShadow: '0 10px 28px rgba(0,0,0,0.4)' }}
      onPointerDown={(e) => e.stopPropagation()}
      onMouseDown={(e) => e.stopPropagation()}
    >
      <button
        type="button"
        title={tx('Тягни, щоб перемістити. Подвійний клік — повернути панель', 'Drag to move. Double-click to rotate')}
        aria-label={tx('Перемістити панель', 'Move toolbar')}
        onPointerDown={startDrag}
        onDoubleClick={flip}
        className={`grid cursor-grab place-items-center rounded active:cursor-grabbing ${vertical ? 'h-4 w-8' : 'h-8 w-4'}`}
        style={{ color: T.text3, touchAction: 'none' }}
      >
        <svg width={vertical ? 14 : 6} height={vertical ? 6 : 14} viewBox={vertical ? '0 0 14 6' : '0 0 6 14'} aria-hidden>
          {(vertical ? [[2, 1.5], [7, 1.5], [12, 1.5], [2, 4.5], [7, 4.5], [12, 4.5]] : [[1.5, 2], [4.5, 2], [1.5, 7], [4.5, 7], [1.5, 12], [4.5, 12]]).map(([cx, cy]) => <circle key={`${cx}-${cy}`} cx={cx} cy={cy} r="1.1" fill="currentColor" />)}
        </svg>
      </button>
      {favs.length === 0 && (
        <span className="px-2 text-[12px]" style={{ color: T.text3 }}>{tx('Зірочка в лівому меню додає інструмент сюди', 'Star a tool in the left menu')}</span>
      )}
      {favs.map((id) => {
        const on = tool === id;
        return (
          <button
            key={id}
            type="button"
            title={itemName(id)}
            aria-label={itemName(id)}
            aria-pressed={on || undefined}
            onClick={() => onPick(on ? null : id)}
            className="grid h-8 w-8 place-items-center rounded-lg transition-colors"
            style={{ color: on ? '#5b8cff' : T.text2, background: on ? 'rgba(41,98,255,0.18)' : 'transparent' }}
            onMouseEnter={(e) => { if (!on) e.currentTarget.style.background = 'rgba(255,255,255,0.07)'; }}
            onMouseLeave={(e) => { if (!on) e.currentTarget.style.background = 'transparent'; }}
          >
            <DrawIcon id={id} size={22} />
          </button>
        );
      })}
      <button
        type="button"
        title={tx('Сховати панель обраних', 'Hide favorites')}
        aria-label={tx('Сховати панель обраних', 'Hide favorites')}
        onClick={onClose}
        className="grid h-6 w-6 place-items-center rounded opacity-50 transition-opacity hover:opacity-100"
        style={{ color: T.text3 }}
      >
        <X size={13} />
      </button>
    </div>
  );
}
