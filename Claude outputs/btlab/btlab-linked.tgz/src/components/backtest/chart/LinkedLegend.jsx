import { useEffect, useState } from 'react';
import { Loader2, X } from 'lucide-react';
import { t as tx } from '../../../lib/lang';

/* ==================================================================
   Підписи панелей з іншими інструментами (LinkedPanes) — зліва
   вгорі кожної панелі, як у TV: назва, таймфрейм, OHLC свічки під
   курсором (або останньої), хрестик — прибрати панель.
================================================================== */

const FONT = "-apple-system,BlinkMacSystemFont,'Trebuchet MS',Roboto,sans-serif";

export default function LinkedLegend({ lp, chart, items, prefs, tfLabel, onRemove }) {
  const [tops, setTops] = useState([]);
  const [hover, setHover] = useState(null);

  /* Межу між панелями можна тягнути — підглядаємо зрідка. */
  useEffect(() => {
    if (!lp) return undefined;
    const upd = () => {
      const t = lp.paneTops();
      setTops((prev) => (JSON.stringify(prev) === JSON.stringify(t) ? prev : t));
    };
    upd();
    const iv = setInterval(upd, 300);
    return () => clearInterval(iv);
  }, [lp, items]);

  /* Перехрестя спільне для всіх панелей — беремо свічку кожної. */
  useEffect(() => {
    if (!chart || !lp) return undefined;
    const fn = (param) => {
      if (!param?.time) { setHover(null); return; }
      setHover(lp.list.map((x) => (x.api ? param.seriesData.get(x.api) || null : null)));
    };
    chart.subscribeCrosshairMove(fn);
    return () => { try { chart.unsubscribeCrosshairMove(fn); } catch { /* графік уже знищено */ } };
  }, [chart, lp]);

  if (!lp || !items?.length) return null;
  const style = { color: prefs.text, fontSize: prefs.fontSize + 1, fontFamily: FONT };

  return items.map((it, i) => {
    const top = tops[i];
    if (top == null) return null;
    const x = lp.list[i];
    const b = (hover ? hover[i] : null) || x?.last || null;
    const d = x?.digits ?? 2;
    const up = b ? b.close >= b.open : true;
    const col = up ? prefs.up : prefs.down;
    return (
      <div key={it.key} className="group pointer-events-none absolute left-2 z-[5] flex items-center gap-2 whitespace-nowrap" style={{ top: top + 4, ...style }}>
        <span className="font-semibold">{it.name}</span>
        <span className="opacity-60">· {tfLabel}</span>
        {it.loading && <Loader2 size={13} className="animate-spin opacity-70" />}
        {it.error && !it.loading && (
          <span className="text-[11px]" style={{ color: '#f23645' }}>
            {it.error === 'no_history' ? tx('немає історії', 'no history') : tx('не вдалося завантажити', 'failed to load')}
          </span>
        )}
        {b && (
          <span className="tabular-nums" style={{ fontSize: prefs.fontSize }}>
            <span className="opacity-60">O</span><span style={{ color: col }}>{b.open.toFixed(d)}</span>{' '}
            <span className="opacity-60">H</span><span style={{ color: col }}>{b.high.toFixed(d)}</span>{' '}
            <span className="opacity-60">L</span><span style={{ color: col }}>{b.low.toFixed(d)}</span>{' '}
            <span className="opacity-60">C</span><span style={{ color: col }}>{b.close.toFixed(d)}</span>
          </span>
        )}
        {!b && !it.loading && !it.error && it.ready && (
          <span className="text-[11px] opacity-60">{tx('немає свічок на цих датах', 'no candles at these dates')}</span>
        )}
        <button
          type="button"
          title={tx('Прибрати панель', 'Remove pane')}
          aria-label={tx('Прибрати панель', 'Remove pane')}
          onClick={() => onRemove(it.key)}
          className="pointer-events-auto grid h-[20px] w-[20px] place-items-center rounded opacity-60 transition-opacity hover:opacity-100"
          style={{ background: 'rgba(128,128,128,0.18)' }}
        >
          <X size={13} />
        </button>
      </div>
    );
  });
}
