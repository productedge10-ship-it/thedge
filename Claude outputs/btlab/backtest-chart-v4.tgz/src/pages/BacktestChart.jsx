import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { useNavigate, useSearchParams } from 'react-router-dom';
import {
  ArrowLeft, Scissors, Play, Pause, SkipForward, X, Settings2, CalendarDays, ChevronDown,
  UploadCloud, Trash2, RotateCcw, PanelRight, Maximize2, Check, Loader2, CircleDot,
} from 'lucide-react';

import { supabase } from '../lib/supabase';
import { useAuth } from '../context/AuthContext';
import useCloudState from '../hooks/useCloudState';
import { T, useEdgeFonts } from '../lib/theme';
import { t as tx, LOCALE } from '../lib/lang';
import { notify } from '../utils/notify';
import { isDemo } from '../lib/backtestDemo';
import { ACT, act } from '../components/backtest/accent';
import Button from '../components/ui/Button';
import ChartEngine from '../components/backtest/chart/ChartEngine';
import ChartSettings from '../components/backtest/chart/ChartSettings';
import DrawingManager from '../components/backtest/chart/DrawingManager';
import DrawingToolbar from '../components/backtest/chart/DrawingToolbar';
import DrawingFloatBar from '../components/backtest/chart/DrawingFloatBar';
import DrawingSettings from '../components/backtest/chart/DrawingSettings';
import { loadDrawings, saveDrawings, loadDefaults, saveDefaults, TOOLS } from '../lib/candles/drawings';
import ImportCandles, { ImportProgress, useCandleFilePicker } from '../components/backtest/chart/ImportCandles';
import { listSets, loadSet, saveSet, deleteSet, parseFile } from '../lib/candles/store';
import { TFS, isoDay, sessionOf, fmtTime } from '../lib/candles/agg';
import { fmtStamp } from '../lib/candles/timefmt';
import { DEFAULT_PREFS, normalizePrefs } from '../lib/candles/chartPrefs';

/* ==================================================================
   Бектест на реальному графіку.

   Сторінка — лише рамка: тулбар, панель угоди, список закритих.
   Графік, реплей і розрахунок стопів живуть у ChartEngine, бо
   оновлюються частіше, ніж має сенс перемальовувати React.

   Угоди пишуться в той самий backtest_trades, що й ручні, — тож уся
   статистика бектесту (R, вінрейт, сесії, крива) працює для них без
   жодної окремої логіки.
================================================================== */

const SPEEDS = [
  { ms: 10000, label: '10с', en: '10s' },
  { ms: 3000, label: '3с', en: '3s' },
  { ms: 1000, label: '1с', en: '1s' },
  { ms: 500, label: '0.5с', en: '0.5s' },
  { ms: 300, label: '0.3с', en: '0.3s' },
  { ms: 100, label: '0.1с', en: '0.1s' },
];

/* Курсори з лівої панелі. Бібліотека ставить свій курсор на полотно,
   тож перебиваємо його лише в області свічок (першому рядку таблиці
   графіка), а шкали лишають свої «тягнути»-курсори. */
const DOT = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='16' height='16'%3E%3Ccircle cx='8' cy='8' r='2.5' fill='%23ffffff' stroke='%23000' stroke-width='1'/%3E%3C/svg%3E\") 8 8, crosshair";
const ERASER = "url(\"data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='22' height='22'%3E%3Cpath d='M4 15l8-10 6 5-7 8H8z' fill='%23fff' stroke='%23000'/%3E%3C/svg%3E\") 4 18, pointer";
const CURSOR_CSS = `
.edge-chart-host[data-cursor="cur-cross"] tr:first-child td:nth-child(2) canvas { cursor: crosshair !important; }
.edge-chart-host[data-cursor="cur-dot"] tr:first-child td:nth-child(2) canvas { cursor: ${DOT} !important; }
.edge-chart-host[data-cursor="cur-arrow"] tr:first-child td:nth-child(2) canvas { cursor: default !important; }
.edge-chart-host[data-cursor="eraser"] tr:first-child td:nth-child(2) canvas { cursor: ${ERASER} !important; }
.edge-chart-host[data-over="move"] tr:first-child td:nth-child(2) canvas { cursor: move !important; }
.edge-chart-host[data-over="point"] tr:first-child td:nth-child(2) canvas { cursor: pointer !important; }
.edge-chart-host[data-over="pointer"] tr:first-child td:nth-child(2) canvas { cursor: pointer !important; }
.edge-chart-host[data-selecting="1"] tr:first-child td:nth-child(2) canvas { cursor: crosshair !important; }
`;

const fmtNum = (v, d) => (Number.isFinite(v) ? v.toFixed(d) : '—');
const fmtR = (r) => `${r > 0 ? '+' : r < 0 ? '−' : ''}${Math.abs(r).toFixed(2)}R`;
const plural = (n, one, few, many) => {
  const t = n % 100;
  if (t >= 11 && t <= 14) return many;
  const d = n % 10;
  if (d === 1) return one;
  if (d >= 2 && d <= 4) return few;
  return many;
};

/* Кнопка тулбара — плоска, як у TV, з тонкою підкладкою на наведенні. */
function ToolBtn({ active, title, onClick, children, className = '', disabled }) {
  return (
    <button
      type="button"
      title={title}
      aria-label={title}
      aria-pressed={active || undefined}
      disabled={disabled}
      onClick={onClick}
      className={`flex h-9 shrink-0 items-center gap-1.5 rounded-lg px-2.5 text-[13px] font-semibold transition-colors disabled:opacity-40 ${className}`}
      style={{ background: active ? act(0.18) : 'transparent', color: active ? '#fff' : T.text2 }}
      onMouseEnter={(e) => { if (!active) e.currentTarget.style.background = 'rgba(255,255,255,0.06)'; }}
      onMouseLeave={(e) => { if (!active) e.currentTarget.style.background = 'transparent'; }}
    >
      {children}
    </button>
  );
}

const Divider = () => <span className="mx-1 hidden h-5 w-px shrink-0 sm:block" style={{ background: T.line }} />;

function Menu({ open, onClose, children, align = 'left', width = 280 }) {
  const ref = useRef(null);
  useEffect(() => {
    if (!open) return undefined;
    const down = (e) => { if (ref.current && !ref.current.contains(e.target)) onClose(); };
    const key = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('pointerdown', down, true);
    window.addEventListener('keydown', key);
    return () => { window.removeEventListener('pointerdown', down, true); window.removeEventListener('keydown', key); };
  }, [open, onClose]);
  if (!open) return null;
  return (
    <div
      ref={ref}
      className={`absolute top-[calc(100%+6px)] z-50 overflow-hidden rounded-xl p-1.5 ${align === 'right' ? 'right-0' : 'left-0'}`}
      style={{ width, background: T.surface3, border: `1px solid ${T.lineHi}`, boxShadow: '0 16px 40px rgba(0,0,0,0.45)' }}
    >
      {children}
    </div>
  );
}

export default function BacktestChart() {
  useEdgeFonts();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [params, setParams] = useSearchParams();
  const sessionId = params.get('session') || '';
  const uid = user?.id || 'anon';

  const [prefsRaw, setPrefsRaw] = useCloudState('chart_prefs', DEFAULT_PREFS, { normalize: normalizePrefs });
  const prefs = useMemo(() => normalizePrefs(prefsRaw), [prefsRaw]);
  const setPrefs = useCallback((p) => setPrefsRaw(normalizePrefs(p)), [setPrefsRaw]);

  const [sets, setSets] = useState(null);
  const [symbol, setSymbol] = useState('');
  const [loadingSet, setLoadingSet] = useState(false);
  const [importing, setImporting] = useState(null);
  const [st, setSt] = useState({ ready: false, tf: prefs.tf, replay: false, selecting: false, playing: false, pos: null });
  const [legend, setLegend] = useState(null);
  const [closed, setClosed] = useState([]);
  const [sessions, setSessions] = useState([]);
  const [menu, setMenu] = useState(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [dateVal, setDateVal] = useState('');
  const [leaving, setLeaving] = useState(false);
  const [saving, setSaving] = useState(false);

  const rootRef = useRef(null);
  const boxRef = useRef(null);
  const ovRef = useRef(null);
  const slRef = useRef(null);
  const tpRef = useRef(null);
  const engRef = useRef(null);
  const posRef = useRef(null);
  const digits = useRef(2);
  const sessionRef = useRef(sessionId);
  sessionRef.current = sessionId;
  const dmRef = useRef(null);
  const symRef = useRef('');
  const saveTimer = useRef(null);
  const [draw, setDraw] = useState({ tool: null, count: 0 });
  const [selDraw, setSelDraw] = useState(null);
  const [drawEdit, setDrawEdit] = useState(null);

  /* ---------------- рушій ---------------- */

  useEffect(() => {
    const eng = new ChartEngine(boxRef.current, ovRef.current, prefs, {
      onState: (s) => { posRef.current = s.pos; setSt(s); },
      onLegend: (b, prev) => setLegend({ ...b, prev }),
      onClosed: (trade) => setClosed((list) => [...list, { ...trade, saved: false }]),
      onFrame: () => placeHandles(),
    });
    engRef.current = eng;

    /* Малювання. Список зберігається окремо для кожного інструмента:
       лінії по золоту не мають зʼявлятися на євро. */
    const dm = new DrawingManager(eng, boxRef.current, {
      onChange: (list) => {
        setDraw((v) => ({ ...v, count: list.length }));
        clearTimeout(saveTimer.current);
        const sym = symRef.current;
        saveTimer.current = setTimeout(() => saveDrawings(uid, sym, list), 300);
      },
      onSelect: (d) => setSelDraw(d ? { ...d, style: { ...d.style } } : null),
      onTool: (tool) => setDraw((v) => ({ ...v, tool })),
      onText: (d) => setDrawEdit(d.id),
      onSettings: (d) => setDrawEdit(d.id),
    });
    dm.defaults = loadDefaults(uid);
    eng.drawings = dm;
    dmRef.current = dm;
    if (import.meta.env?.DEV) window.__dm = dm;
    return () => { dm.destroy(); eng.destroy(); engRef.current = null; dmRef.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => { engRef.current?.applyPrefs(prefs); }, [prefs]);

  /* Стан лівої панелі живе в налаштуваннях графіка — магніт, режим
     малювання, вибрані в групах інструменти памʼятаються. */
  useEffect(() => {
    const dm = dmRef.current;
    if (!dm) return;
    dm.magnet = prefs.drawMagnet || 'off';
    dm.keep = !!prefs.drawKeep;
    dm.lockAll = !!prefs.drawLock;
    dm.hideAll = !!prefs.drawHide;
    if (dm.cursor !== (prefs.drawCursor || 'cur-cross')) { dm.cursor = prefs.drawCursor || 'cur-cross'; dm.applyCursor(); }
  }, [prefs.drawMagnet, prefs.drawKeep, prefs.drawLock, prefs.drawHide, prefs.drawCursor]);

  const drawAct = {
    tool: (id) => dmRef.current?.setTool(id),
    cursor: (id) => { setPrefs({ ...prefs, drawCursor: id }); dmRef.current?.setCursor(id); },
    groupSel: (g, id) => setPrefs({ ...prefs, drawGroups: { ...(prefs.drawGroups || {}), [g]: id }, ...(g === 'cursor' ? { drawCursor: id } : {}) }),
    magnet: (m) => setPrefs({ ...prefs, drawMagnet: m, ...(m !== 'off' ? { drawLastMagnet: m } : {}) }),
    keep: () => setPrefs({ ...prefs, drawKeep: !prefs.drawKeep }),
    lock: () => setPrefs({ ...prefs, drawLock: !prefs.drawLock }),
    hide: () => setPrefs({ ...prefs, drawHide: !prefs.drawHide }),
    removeAll: () => dmRef.current?.removeAll(),
    undo: () => dmRef.current?.undo(),
  };

  const drawSt = {
    tool: draw.tool,
    cursor: prefs.drawCursor || 'cur-cross',
    magnet: prefs.drawMagnet || 'off',
    lastMagnet: prefs.drawLastMagnet,
    keep: !!prefs.drawKeep,
    lockAll: !!prefs.drawLock,
    hideAll: !!prefs.drawHide,
    count: draw.count,
    groupSel: prefs.drawGroups || {},
  };

  const editing = drawEdit ? dmRef.current?.list.find((x) => x.id === drawEdit) : null;

  /* Ручки SL/TP ставимо напряму в DOM на кожен кадр: тягнеш графік чи
     шкалу — вони мають їхати разом із ціною без запізнення на рендер. */
  function placeHandles() {
    const eng = engRef.current;
    const p = posRef.current;
    [[slRef.current, 'sl'], [tpRef.current, 'tp']].forEach(([el, key]) => {
      if (!el) return;
      const y = p && eng ? eng.y(eng.pos?.[key] ?? p[key]) : null;
      if (y == null) { el.style.display = 'none'; return; }
      el.style.display = 'flex';
      /* Біля шкали цін, як ручки позиції в TV, а не під легендою. */
      el.style.right = `${eng.chart.priceScale('right').width() + 10}px`;
      el.style.transform = `translateY(${Math.round(y) - 11}px)`;
    });
  }

  /* ---------------- набори свічок ---------------- */

  const refreshSets = useCallback(async () => {
    const list = await listSets(uid);
    setSets(list);
    return list;
  }, [uid]);

  useEffect(() => {
    refreshSets().then((list) => {
      const want = list.find((x) => x.symbol === prefs.symbol) || list[0];
      if (want) setSymbol(want.symbol);
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [refreshSets]);

  useEffect(() => {
    if (!symbol) return undefined;
    let alive = true;
    setLoadingSet(true);
    loadSet(uid, symbol).then((rec) => {
      if (!alive || !rec || !engRef.current) return;
      digits.current = rec.digits;
      engRef.current.useTf(prefs.tf);
      engRef.current.setData(rec);
      setClosed([]);
      symRef.current = rec.symbol;
      const list = loadDrawings(uid, rec.symbol);
      dmRef.current?.setList(list);
      setDraw((v) => ({ ...v, count: list.length }));
      if (prefs.symbol !== symbol) setPrefs({ ...prefs, symbol });
    }).catch((e) => {
      notify.error(tx('Не вдалось відкрити свічки', 'Couldn’t open candles'), e.message);
    }).finally(() => { if (alive) setLoadingSet(false); });
    return () => { alive = false; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [symbol, uid]);

  const onFile = async (file) => {
    setMenu(null);
    setImporting(0);
    try {
      const set = await parseFile(file, (p) => setImporting(p));
      if (set.n < 100) throw new Error(tx('У файлі замало свічок', 'Too few candles in the file'));
      setImporting(1);
      await saveSet(uid, set);
      await refreshSets();
      const days = Math.round((set.t[set.n - 1] - set.t[0]) / 86400);
      notify.success(
        tx(`${set.symbol}: ${set.n.toLocaleString(LOCALE)} свічок`, `${set.symbol}: ${set.n.toLocaleString(LOCALE)} candles`),
        tx(`Історія за ${days} дн. — з ${fmtTime(set.t[0]).slice(0, 10)}.`, `${days} days of history from ${fmtTime(set.t[0]).slice(0, 10)}.`),
      );
      if (set.symbol === symbol) {
        const rec = await loadSet(uid, set.symbol);
        engRef.current?.setData(rec);
      } else setSymbol(set.symbol);
    } catch (e) {
      const msg = e.message === 'no_rows'
        ? tx('Не знайшов у файлі жодної свічки. Це точно експорт барів з MT5?', 'No candles found. Is this an MT5 bars export?')
        : e.message;
      notify.error(tx('Не вдалось прочитати файл', 'Couldn’t read the file'), msg);
    } finally {
      setImporting(null);
    }
  };
  const [fileInput, pickFile] = useCandleFilePicker(onFile);

  const removeSet = async (sym) => {
    await deleteSet(uid, sym);
    const list = await refreshSets();
    if (sym === symbol) setSymbol(list[0]?.symbol || '');
  };

  /* ---------------- куди писати угоди ---------------- */

  useEffect(() => {
    if (!user?.id) return;
    supabase
      .from('backtest_sessions')
      .select('id,name,pair')
      .eq('user_id', user.id)
      .order('created_at', { ascending: false })
      .then(({ data }) => setSessions(data || []));
  }, [user?.id]);

  const currentSession = sessions.find((s) => s.id === sessionId);
  const demo = isDemo(sessionId);

  const toPayload = (t) => ({
    session_id: sessionRef.current,
    user_id: user?.id,
    date: isoDay(t.entryT),
    type: t.side,
    result: t.result,
    rr: t.result === 'BE' ? 0 : Math.abs(t.r),
    notes: '',
    screenshot_url: null,
    tda_data: {
      pair: t.symbol,
      session: sessionOf(t.entryT),
      tags: [tx('Реальний графік', 'Real chart')],
      shots: [],
      chart: {
        tf: t.tf, entry: t.entry, sl: t.sl, sl_final: t.slFinal, tp: t.tp, exit: t.exit,
        entry_time: t.entryT, exit_time: t.exitT, exit_reason: t.reason,
      },
    },
  });

  const saveTrades = useCallback(async (list) => {
    if (!sessionRef.current || isDemo(sessionRef.current) || !user?.id || !list.length) return;
    setSaving(true);
    try {
      const { error } = await supabase.from('backtest_trades').insert(list.map(toPayload));
      if (error) throw error;
      const ids = new Set(list.map((t) => t.id));
      setClosed((all) => all.map((t) => (ids.has(t.id) ? { ...t, saved: true } : t)));
    } catch (e) {
      notify.error(tx('Угоду не записано', 'Trade not saved'), e.message);
    } finally {
      setSaving(false);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  /* Щойно закрита угода — одразу в бектест, якщо його обрано. */
  const lastClosed = closed[closed.length - 1];
  useEffect(() => {
    if (lastClosed && !lastClosed.saved && sessionRef.current) saveTrades([lastClosed]);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [lastClosed?.id]);

  const unsaved = closed.filter((t) => !t.saved);

  const chooseSession = (id) => {
    const next = new URLSearchParams(params);
    if (id) next.set('session', id); else next.delete('session');
    setParams(next, { replace: true });
    setMenu(null);
  };

  /* ---------------- дії ---------------- */

  /* Вихід — з тією самою анімацією, що й вхід, лише навпаки. */
  const leave = () => {
    if (leaving) return;
    setLeaving(true);
    engRef.current?.pause();
    setTimeout(() => navigate(sessionId ? `/backtest/${sessionId}` : '/backtest'), 170);
  };

  const eng = () => engRef.current;
  const setTf = (id) => { eng()?.useTf(id); setPrefs({ ...prefs, tf: id }); };
  const speedIdx = Math.min(SPEEDS.length - 1, Math.max(0, prefs.speed ?? 2));
  const togglePlay = () => {
    const e = eng();
    if (!e?.replay) return;
    if (e.playing) e.pause(); else e.play(SPEEDS[speedIdx].ms);
  };
  const setSpeed = (i) => { setPrefs({ ...prefs, speed: i }); eng()?.setSpeed(SPEEDS[i].ms); setMenu(null); };

  const openPos = (side) => {
    const e = eng();
    if (!e) return;
    if (!e.replay) {
      notify.error(tx('Спершу обери точку старту', 'Pick a starting point first'), tx('Натисни «Реплей» і клікни на свічку — далі графік сховано, і можна торгувати.', 'Press “Replay” and click a candle — the future is hidden and you can trade.'));
      return;
    }
    e.openPosition(side, { rr: prefs.rr });
  };

  const exitReplay = () => eng()?.exitReplay();

  const goDate = (mode) => {
    if (!dateVal) return;
    const sec = Date.UTC(+dateVal.slice(0, 4), +dateVal.slice(5, 7) - 1, +dateVal.slice(8, 10)) / 1000;
    if (mode === 'replay') eng()?.startAtTime(sec);
    setMenu(null);
  };

  const fullscreen = () => {
    const el = rootRef.current;
    if (!el) return;
    if (document.fullscreenElement) document.exitFullscreen?.();
    else el.requestFullscreen?.();
  };

  /* Гарячі клавіші як у TV: Shift+→ крок, Shift+↓ пуск/пауза,
     Alt+R — скинути масштаб, Esc — скасувати вибір точки. */
  useEffect(() => {
    const k = (e) => {
      const tag = (e.target?.tagName || '').toLowerCase();
      if (tag === 'input' || tag === 'textarea' || tag === 'select') return;
      const en = engRef.current;
      if (!en) return;
      if (e.shiftKey && e.key === 'ArrowRight') { e.preventDefault(); en.pause(); en.step(true); }
      else if (e.shiftKey && e.key === 'ArrowDown') { e.preventDefault(); if (en.replay) { if (en.playing) en.pause(); else en.play(); } }
      else if (e.altKey && e.shiftKey && e.code === 'KeyR') { e.preventDefault(); dmRef.current?.setTool('rect'); }
      else if (e.altKey && (e.key === 'r' || e.key === 'R' || e.code === 'KeyR')) { e.preventDefault(); en.resetView(); }
      else if (e.key === 'Escape' && en.selecting) en.cancelSelect();
      else {
        /* Малювання: гарячі клавіші TradingView. */
        const dm = dmRef.current;
        if (!dm) return;
        const hot = { KeyT: 'trend', KeyH: 'hline', KeyJ: 'hray', KeyV: 'vline', KeyC: 'cross', KeyF: 'fib' };
        if (e.altKey && !e.ctrlKey && hot[e.code]) { e.preventDefault(); dm.setTool(hot[e.code]); }
        else if ((e.ctrlKey || e.metaKey) && e.code === 'KeyZ' && !e.shiftKey) { e.preventDefault(); dm.undo(); }
        else if ((e.ctrlKey || e.metaKey) && (e.code === 'KeyY' || (e.code === 'KeyZ' && e.shiftKey))) { e.preventDefault(); dm.redo(); }
        else if ((e.key === 'Delete' || e.key === 'Backspace') && dm.sel) { e.preventDefault(); dm.remove(dm.sel); }
        else if (e.key === 'Escape') {
          if (dm.draft) { dm.draft = null; }
          else if (dm.tool) dm.setTool(null);
          else if (dm.sel) dm.select(null);
          dm.temp = null;
        }
      }
    };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, []);

  /* ---------------- тягання SL / TP ---------------- */

  const startDrag = (key) => (e) => {
    e.preventDefault();
    e.stopPropagation();
    const el = e.currentTarget;
    el.setPointerCapture?.(e.pointerId);
    const top = boxRef.current.getBoundingClientRect().top;
    const move = (ev) => {
      const price = eng()?.priceAt(ev.clientY - top);
      if (price != null) eng()?.setLevels({ [key]: price });
    };
    const up = () => {
      el.removeEventListener('pointermove', move);
      el.removeEventListener('pointerup', up);
      el.removeEventListener('pointercancel', up);
    };
    el.addEventListener('pointermove', move);
    el.addEventListener('pointerup', up);
    el.addEventListener('pointercancel', up);
  };

  /* ---------------- підсумки ---------------- */

  const stats = useMemo(() => {
    const dec = closed.filter((t) => t.result !== 'BE');
    const wins = closed.filter((t) => t.result === 'WIN').length;
    return {
      n: closed.length,
      net: closed.reduce((a, t) => a + (t.result === 'BE' ? 0 : t.r), 0),
      wr: dec.length ? (wins / dec.length) * 100 : null,
    };
  }, [closed]);

  const d = digits.current;
  const pos = st.pos;
  const hasSets = sets && sets.length > 0;
  const tfLabel = TFS.find((x) => x.id === st.tf)?.label || '';
  const legendUp = legend ? legend.close >= legend.open : true;
  const chg = legend ? legend.close - legend.prev : 0;

  /* Графік — на весь екран поверх застосунку, як окрема вкладка
     графіка в TV: сайдбар і фон сторінки тут лише заважають. Портал у
     body, бо батьківські блоки застосунку мають власні шари й
     прокрутку, і «fixed» усередині них поводився б непередбачувано. */
  const page = (
    <div
      ref={rootRef}
      className="fixed inset-0 z-[70] flex min-h-0 w-full min-w-0 flex-col overflow-hidden"
      style={{
        background: T.bg,
        animation: leaving ? 'edgeChartOut .18s ease-in forwards' : 'edgeChartIn .32s cubic-bezier(.22,1,.36,1)',
      }}
    >
      <style>{`
        @keyframes edgeChartIn { from { opacity: 0; transform: scale(.985); } to { opacity: 1; transform: none; } }
        @keyframes edgeChartOut { to { opacity: 0; transform: scale(.985); } }
      `}</style>
      {fileInput}

      {/* ─────────── Тулбар ─────────── */}
      {/* Без overflow: прокрутка тулбара обрізала б випадні меню. На
          вузькому екрані замість цього ховаються підписи й другорядне. */}
      <div className="relative z-30 flex h-12 shrink-0 items-center gap-0.5 overflow-x-clip px-1.5 sm:gap-1 sm:px-2" style={{ borderBottom: `1px solid ${T.line}`, background: T.surface }}>
        <ToolBtn title={tx('Назад до бектестів', 'Back to backtests')} onClick={leave}>
          <ArrowLeft size={17} />
        </ToolBtn>
        <Divider />

        {/* Символ */}
        <div className="relative">
          <ToolBtn title={tx('Інструмент', 'Symbol')} onClick={() => setMenu(menu === 'sym' ? null : 'sym')} active={menu === 'sym'}>
            <span className="text-[14px] font-bold" style={{ color: T.text }}>{symbol || tx('Свічки', 'Candles')}</span>
            <ChevronDown size={14} />
          </ToolBtn>
          <Menu open={menu === 'sym'} onClose={() => setMenu(null)} width={300}>
            {(sets || []).map((s) => (
              <div key={s.symbol} className="group flex items-center gap-1 rounded-lg" style={{ background: s.symbol === symbol ? act(0.14) : 'transparent' }}>
                <button type="button" onClick={() => { setSymbol(s.symbol); setMenu(null); }} className="min-w-0 flex-1 px-2.5 py-2 text-left">
                  <div className="text-[13.5px] font-bold" style={{ color: T.text }}>{s.symbol}</div>
                  <div className="truncate text-[11.5px]" style={{ color: T.text3, fontFamily: T.mono }}>
                    {fmtTime(s.from).slice(0, 10)} — {fmtTime(s.to).slice(0, 10)} · {s.n.toLocaleString(LOCALE)}
                  </div>
                </button>
                <button
                  type="button"
                  title={tx('Видалити з браузера', 'Remove from browser')}
                  onClick={() => removeSet(s.symbol)}
                  className="mr-1 grid h-8 w-8 place-items-center rounded-md opacity-0 transition-opacity group-hover:opacity-100 focus:opacity-100"
                  style={{ color: T.text3 }}
                >
                  <Trash2 size={14} />
                </button>
              </div>
            ))}
            <button type="button" onClick={pickFile} className="mt-1 flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-[13px] font-semibold" style={{ color: ACT.tint }}>
              <UploadCloud size={15} /> {tx('Завантажити CSV з MT5', 'Load CSV from MT5')}
            </button>
          </Menu>
        </div>
        <Divider />

        {/* Таймфрейми: на телефоні — одним випадним списком, рядок кнопок не влазить. */}
        {TFS.map((tf) => (
          <ToolBtn key={tf.id} active={st.tf === tf.id} title={tf.id} onClick={() => setTf(tf.id)} className={`hidden px-2 ${tf.id === 'M30' || tf.id === 'H4' ? 'md:flex' : 'sm:flex'}`}>
            {tf.label}
          </ToolBtn>
        ))}
        <div className="relative sm:hidden">
          <ToolBtn title={tx('Таймфрейм', 'Timeframe')} active={menu === 'tf'} onClick={() => setMenu(menu === 'tf' ? null : 'tf')}>
            {tfLabel || '15m'} <ChevronDown size={13} />
          </ToolBtn>
          <Menu open={menu === 'tf'} onClose={() => setMenu(null)} width={120}>
            {TFS.map((tf) => (
              <button key={tf.id} type="button" onClick={() => { setTf(tf.id); setMenu(null); }} className="block w-full rounded-lg px-3 py-2 text-left text-[13px] font-semibold" style={{ color: st.tf === tf.id ? '#fff' : T.text2, background: st.tf === tf.id ? act(0.3) : 'transparent' }}>
                {tf.label}
              </button>
            ))}
          </Menu>
        </div>
        <Divider />

        <ToolBtn
          active={st.replay || st.selecting}
          title={tx('Реплей: обери свічку, з якої почати', 'Replay: pick a starting candle')}
          onClick={() => (st.selecting ? eng()?.cancelSelect() : eng()?.startSelect())}
          disabled={!st.ready}
        >
          <Scissors size={16} /> <span className="hidden lg:inline">{tx('Реплей', 'Replay')}</span>
        </ToolBtn>

        <div className="relative hidden sm:block">
          <ToolBtn title={tx('Почати з дати', 'Start from date')} onClick={() => setMenu(menu === 'date' ? null : 'date')} active={menu === 'date'} disabled={!st.ready}>
            <CalendarDays size={16} />
          </ToolBtn>
          <Menu open={menu === 'date'} onClose={() => setMenu(null)} width={260}>
            <div className="p-2">
              <div className="text-[12px] font-semibold" style={{ color: T.text3 }}>{tx('Почати реплей з дати', 'Start replay at date')}</div>
              <input
                type="date"
                value={dateVal}
                onChange={(e) => setDateVal(e.target.value)}
                className="mt-2 w-full rounded-lg px-2.5 py-2 text-[13px] outline-none"
                style={{ background: T.sunken, border: `1px solid ${T.line}`, color: T.text, colorScheme: 'dark' }}
              />
              <Button size="sm" block className="mt-2" disabled={!dateVal} onClick={() => goDate('replay')}>
                {tx('Почати', 'Start')}
              </Button>
            </div>
          </Menu>
        </div>

        <ToolBtn className="hidden sm:flex" title={tx('Скинути масштаб (Alt+R)', 'Reset chart (Alt+R)')} onClick={() => eng()?.resetView()} disabled={!st.ready}>
          <RotateCcw size={15} />
        </ToolBtn>

        <div className="flex-1" />

        {/* Бектест, у який пишуться угоди */}
        <div className="relative">
          <ToolBtn title={tx('Куди записувати угоди', 'Where trades are saved')} onClick={() => setMenu(menu === 'sess' ? null : 'sess')} active={menu === 'sess'}>
            <CircleDot size={14} style={{ color: currentSession ? T.ok : T.text3 }} />
            <span className="hidden max-w-[180px] truncate lg:inline">{currentSession?.name || (demo ? tx('Демо', 'Demo') : tx('Без запису', 'Not saving'))}</span>
            <ChevronDown size={14} />
          </ToolBtn>
          <Menu open={menu === 'sess'} onClose={() => setMenu(null)} align="right" width={280}>
            <div className="px-2.5 pb-1.5 pt-1 text-[11.5px] font-semibold" style={{ color: T.text3 }}>{tx('Записувати угоди в бектест', 'Save trades to backtest')}</div>
            <div className="max-h-[300px] overflow-y-auto">
              {sessions.map((s) => (
                <button key={s.id} type="button" onClick={() => chooseSession(s.id)} className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-[13px]" style={{ color: T.text, background: s.id === sessionId ? act(0.14) : 'transparent' }}>
                  <span className="min-w-0 flex-1 truncate">{s.name}</span>
                  <span className="text-[11px]" style={{ color: T.text3, fontFamily: T.mono }}>{s.pair}</span>
                  {s.id === sessionId && <Check size={14} style={{ color: ACT.tint }} />}
                </button>
              ))}
            </div>
            <button type="button" onClick={() => chooseSession('')} className="flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-left text-[13px]" style={{ color: T.text2 }}>
              {tx('Не записувати (тренування)', 'Don’t save (practice)')}
            </button>
          </Menu>
        </div>
        <ToolBtn title={tx('Налаштування графіка', 'Chart settings')} onClick={() => setSettingsOpen(true)}>
          <Settings2 size={16} />
        </ToolBtn>
        <ToolBtn className="hidden md:flex" title={tx('Панель угоди', 'Trade panel')} active={prefs.panel} onClick={() => setPrefs({ ...prefs, panel: !prefs.panel })}>
          <PanelRight size={16} />
        </ToolBtn>
        <ToolBtn className="hidden sm:flex" title={tx('На весь екран', 'Fullscreen')} onClick={fullscreen}>
          <Maximize2 size={15} />
        </ToolBtn>
      </div>

      <div className="flex min-h-0 flex-1">
        {st.ready && <DrawingToolbar st={drawSt} act={drawAct} />}
        {/* ─────────── Графік ─────────── */}
        <div className="relative min-w-0 flex-1" style={{ background: prefs.bg }}>
          <div ref={boxRef} className="edge-chart-host absolute inset-0" data-selecting={st.selecting ? '1' : ''} />
          <style>{CURSOR_CSS}</style>
          {selDraw && !drawEdit && (
            <DrawingFloatBar
              d={selDraw}
              onStyle={(patch) => dmRef.current?.update(selDraw.id, (d) => ({ style: { ...d.style, ...patch } }))}
              onPatch={(patch) => dmRef.current?.update(selDraw.id, patch)}
              onSettings={() => setDrawEdit(selDraw.id)}
              onClone={() => dmRef.current?.clone(selDraw.id)}
              onDelete={() => dmRef.current?.remove(selDraw.id)}
            />
          )}
          <svg ref={ovRef} className="pointer-events-none absolute inset-0 h-full w-full" style={{ zIndex: 3 }} />

          {/* Ручки SL / TP — тягнуться мишкою, як на позиції в TV. */}
          {['tp', 'sl'].map((key) => (
            <div
              key={key}
              ref={key === 'sl' ? slRef : tpRef}
              onPointerDown={startDrag(key)}
              className="absolute top-0 z-10 hidden h-[22px] cursor-ns-resize select-none items-center gap-1.5 rounded-md px-2 text-[11.5px] font-bold text-white shadow-md"
              style={{ background: key === 'sl' ? '#f23645' : '#089981', fontFamily: T.mono, touchAction: 'none' }}
              title={key === 'sl' ? tx('Тягни, щоб посунути стоп', 'Drag to move stop') : tx('Тягни, щоб посунути тейк', 'Drag to move target')}
            >
              {(prefs.markerText || !pos) && (key === 'sl' ? 'SL' : 'TP')}
              {!prefs.markerText && <span className="flex flex-col gap-[2px] opacity-90" aria-hidden><span className="block h-px w-3 bg-white" /><span className="block h-px w-3 bg-white" /><span className="block h-px w-3 bg-white" /></span>}
              {pos && prefs.markerText && (
                <span className="font-semibold opacity-90">
                  {key === 'sl' ? fmtNum(pos.sl, d) : `${fmtNum(pos.tp, d)} · ${pos.rr.toFixed(1)}R`}
                </span>
              )}
            </div>
          ))}

          {/* Рядок статусу — лише те, що ввімкнено в налаштуваннях.
              За замовчуванням графік чистий. */}
          {st.ready && legend && (prefs.stTitle || prefs.stOhlc || prefs.stChange) && (
            <div className="pointer-events-none absolute left-3 top-2 z-[5] flex flex-wrap items-center gap-x-3 gap-y-0.5" style={{ fontFamily: T.mono, color: prefs.text, fontSize: prefs.fontSize + 1 }}>
              {prefs.stTitle && <span className="font-bold" style={{ fontFamily: T.sans }}>{symbol} · {tfLabel}</span>}
              {prefs.stOhlc && [['O', legend.open], ['H', legend.high], ['L', legend.low], ['C', legend.close]].map(([k, v]) => (
                <span key={k}>{k} <span style={{ color: legendUp ? prefs.up : prefs.down }}>{fmtNum(v, d)}</span></span>
              ))}
              {prefs.stChange && (
                <span style={{ color: chg >= 0 ? prefs.up : prefs.down }}>
                  {chg >= 0 ? '+' : ''}{fmtNum(chg, d)} ({legend.prev ? ((chg / legend.prev) * 100).toFixed(2) : '0.00'}%)
                </span>
              )}
            </div>
          )}

          {/* Кнопки Buy / Sell на графіку — як у TV, вмикаються в «Рядку статусу». */}
          {st.ready && prefs.stButtons && (
            <div
              className="absolute left-3 z-[6] flex overflow-hidden rounded-md text-white shadow-md"
              style={{ top: prefs.stTitle || prefs.stOhlc || prefs.stChange ? 30 : 10, fontFamily: T.mono }}
            >
              {pos ? (
                <button type="button" onClick={() => eng()?.closePosition('manual')} className="px-3 py-1 text-left text-[12px] font-bold" style={{ background: pos.r >= 0 ? '#089981' : '#f23645' }}>
                  {tx('Закрити', 'Close')} {fmtR(pos.r)}
                </button>
              ) : (
                <>
                  <button type="button" onClick={() => openPos('SHORT')} className="px-3 py-1 text-left leading-tight transition-[filter] hover:brightness-110" style={{ background: '#f23645' }}>
                    <span className="block text-[13px] font-bold">{fmtNum(st.price, d)}</span>
                    <span className="block text-[10px] font-semibold tracking-wider opacity-90">SELL</span>
                  </button>
                  <button type="button" onClick={() => openPos('LONG')} className="px-3 py-1 text-right leading-tight transition-[filter] hover:brightness-110" style={{ background: '#2962ff' }}>
                    <span className="block text-[13px] font-bold">{fmtNum(st.price, d)}</span>
                    <span className="block text-[10px] font-semibold tracking-wider opacity-90">BUY</span>
                  </button>
                </>
              )}
            </div>
          )}

          {/* Посилання на бібліотеку, коли логотип прибрано, а панелі
              угоди немає (у панелі воно своє). Умова ліцензії. */}
          {st.ready && !prefs.logo && !(prefs.panel && st.ready) && (
            <a href="https://www.tradingview.com/" target="_blank" rel="noreferrer" className="absolute bottom-1 left-2 z-[5] text-[10px] opacity-40 hover:opacity-80" style={{ color: prefs.text }}>
              TradingView Lightweight Charts™
            </a>
          )}

          {/* Порожньо / вантажиться */}
          {sets && !hasSets && importing == null && (
            <div className="absolute inset-0 z-20" style={{ background: T.bg }}>
              <ImportCandles onFile={onFile} />
            </div>
          )}
          {(sets === null || loadingSet) && hasSets !== false && importing == null && (
            <div className="absolute inset-0 z-20 grid place-items-center">
              <Loader2 size={28} className="animate-spin" style={{ color: ACT.tint }} />
            </div>
          )}
          {importing != null && <ImportProgress progress={importing} />}

          {/* Підказка ножиць */}
          {st.selecting && (
            <div className="pointer-events-none absolute left-1/2 top-3 z-20 -translate-x-1/2 rounded-lg px-3 py-1.5 text-[13px] font-semibold text-white" style={{ background: '#2962ff' }}>
              {tx('Клікни на свічку, з якої почати реплей', 'Click the candle to start replay from')}
            </div>
          )}

          {/* Панель реплею */}
          {(st.replay || st.selecting) && (
            <div className="absolute bottom-8 left-1/2 z-20 flex max-w-[calc(100%-16px)] -translate-x-1/2 items-center gap-1 rounded-xl p-1.5" style={{ background: T.surface3, border: `1px solid ${T.lineHi}`, boxShadow: '0 12px 32px rgba(0,0,0,0.45)' }}>
              <ToolBtn title={tx('Обрати іншу точку', 'Pick another point')} active={st.selecting} onClick={() => (st.selecting ? eng()?.cancelSelect() : eng()?.startSelect())}>
                <Scissors size={16} />
              </ToolBtn>
              <ToolBtn title={st.playing ? tx('Пауза (Shift+↓)', 'Pause (Shift+↓)') : tx('Пуск (Shift+↓)', 'Play (Shift+↓)')} onClick={togglePlay} disabled={!st.replay || st.atEnd}>
                {st.playing ? <Pause size={17} /> : <Play size={17} />}
              </ToolBtn>
              <ToolBtn title={tx('Крок вперед (Shift+→)', 'Step forward (Shift+→)')} onClick={() => { eng()?.pause(); eng()?.step(true); }} disabled={!st.replay || st.atEnd}>
                <SkipForward size={17} />
              </ToolBtn>
              <div className="relative">
                <ToolBtn title={tx('Швидкість', 'Speed')} onClick={() => setMenu(menu === 'speed' ? null : 'speed')} active={menu === 'speed'}>
                  <span style={{ fontFamily: T.mono }}>{tx(SPEEDS[speedIdx].label, SPEEDS[speedIdx].en)}</span>
                </ToolBtn>
                {menu === 'speed' && (
                  <div className="absolute bottom-[calc(100%+6px)] left-0 z-50 rounded-xl p-1" style={{ background: T.surface3, border: `1px solid ${T.lineHi}` }}>
                    {SPEEDS.map((s, i) => (
                      <button key={s.ms} type="button" onClick={() => setSpeed(i)} className="block w-full rounded-lg px-3 py-1.5 text-left text-[13px]" style={{ fontFamily: T.mono, color: i === speedIdx ? '#fff' : T.text2, background: i === speedIdx ? act(0.3) : 'transparent' }}>
                        {tx(s.label, s.en)}
                      </button>
                    ))}
                  </div>
                )}
              </div>
              {st.replay && st.time && (
                <span className="hidden px-2 text-[12px] tabular-nums sm:inline" style={{ fontFamily: T.mono, color: T.text3 }}>{fmtStamp(st.time, prefs)}</span>
              )}
              {/* На телефоні бічної панелі немає — вхід і вихід тут. */}
              {st.replay && (
                <span className="flex gap-1 md:hidden">
                  {pos ? (
                    <button type="button" onClick={() => eng()?.closePosition('manual')} className="h-9 rounded-lg px-3 text-[13px] font-bold tabular-nums" style={{ background: T.sunken, color: pos.r >= 0 ? T.ok : T.bad, fontFamily: T.mono }}>
                      {fmtR(pos.r)} ✕
                    </button>
                  ) : (
                    <>
                      <button type="button" onClick={() => openPos('SHORT')} className="h-9 rounded-lg px-3 text-[13px] font-bold text-white" style={{ background: '#f23645' }}>Sell</button>
                      <button type="button" onClick={() => openPos('LONG')} className="h-9 rounded-lg px-3 text-[13px] font-bold text-white" style={{ background: '#2962ff' }}>Buy</button>
                    </>
                  )}
                </span>
              )}
              <ToolBtn title={tx('Вийти з реплею', 'Exit replay')} onClick={() => (st.selecting && !st.replay ? eng()?.cancelSelect() : exitReplay())}>
                <X size={16} />
              </ToolBtn>
            </div>
          )}
        </div>

        {/* ─────────── Панель угоди ─────────── */}
        {prefs.panel && st.ready && (
          <aside className="hidden w-[300px] shrink-0 flex-col overflow-y-auto md:flex" style={{ borderLeft: `1px solid ${T.line}`, background: T.surface }}>
            <div className="p-4">
              <div className="flex items-baseline justify-between">
                <span className="text-[12px] font-semibold uppercase tracking-[0.14em]" style={{ color: T.text3 }}>{symbol}</span>
                <span className="text-[20px] font-bold tabular-nums" style={{ fontFamily: T.mono, color: T.text }}>{fmtNum(st.price, d)}</span>
              </div>

              {!pos ? (
                <>
                  <div className="mt-3 grid grid-cols-2 gap-2">
                    <button type="button" onClick={() => openPos('SHORT')} className="rounded-xl py-3 text-[14px] font-bold text-white transition-transform active:scale-[0.98]" style={{ background: '#f23645' }}>
                      Sell
                    </button>
                    <button type="button" onClick={() => openPos('LONG')} className="rounded-xl py-3 text-[14px] font-bold text-white transition-transform active:scale-[0.98]" style={{ background: '#2962ff' }}>
                      Buy
                    </button>
                  </div>
                  <label className="mt-3 flex items-center justify-between text-[13px]" style={{ color: T.text2 }}>
                    {tx('Тейк, R', 'Target, R')}
                    <input
                      key={prefs.rr}
                      defaultValue={prefs.rr}
                      onBlur={(e) => { const v = Number(e.target.value.replace(',', '.')); if (v > 0) setPrefs({ ...prefs, rr: v }); else e.target.value = prefs.rr; }}
                      onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); }}
                      inputMode="decimal"
                      className="w-20 rounded-lg px-2.5 py-1.5 text-right text-[13px] outline-none"
                      style={{ background: T.sunken, border: `1px solid ${T.line}`, color: T.text, fontFamily: T.mono }}
                    />
                  </label>
                  <p className="mt-3 text-[12.5px] leading-relaxed" style={{ color: T.text3 }}>
                    {st.replay
                      ? tx(`Стоп — ${prefs.atrMult} × ATR(14). Після входу тягни SL і TP прямо на графіку.`, `Stop is ${prefs.atrMult} × ATR(14). After entry, drag SL and TP right on the chart.`)
                      : tx('Натисни «Реплей» і клікни на свічку: усе праворуч сховається, і ти торгуєш, ніби це наживо.', 'Press “Replay” and click a candle: everything to the right is hidden and you trade as if live.')}
                  </p>
                </>
              ) : (
                <div className="mt-3 rounded-xl p-3" style={{ background: T.sunken, border: `1px solid ${pos.side === 'LONG' ? 'rgba(41,98,255,0.5)' : 'rgba(242,54,69,0.5)'}` }}>
                  <div className="flex items-center justify-between">
                    <span className="text-[13px] font-bold" style={{ color: pos.side === 'LONG' ? '#5b8cff' : '#f23645' }}>{pos.side === 'LONG' ? 'Long' : 'Short'}</span>
                    <span className="text-[18px] font-bold tabular-nums" style={{ fontFamily: T.mono, color: pos.r >= 0 ? T.ok : T.bad }}>{fmtR(pos.r)}</span>
                  </div>
                  <div className="mt-2 space-y-1.5 text-[12.5px]" style={{ fontFamily: T.mono }}>
                    <div className="flex justify-between"><span style={{ color: T.text3 }}>{tx('Вхід', 'Entry')}</span><span style={{ color: T.text }}>{fmtNum(pos.entry, d)}</span></div>
                    {[['sl', 'SL', '#f23645'], ['tp', 'TP', '#089981']].map(([key, label, color]) => (
                      <div key={key} className="flex items-center justify-between">
                        <span style={{ color }}>{label}</span>
                        <input
                          key={`${key}-${pos[key]}`}
                          defaultValue={fmtNum(pos[key], d)}
                          onBlur={(e) => eng()?.setLevels({ [key]: Number(e.target.value.replace(',', '.')) })}
                          onKeyDown={(e) => { if (e.key === 'Enter') e.currentTarget.blur(); }}
                          inputMode="decimal"
                          className="w-28 rounded-md px-2 py-1 text-right outline-none"
                          style={{ background: T.surface, border: `1px solid ${T.line}`, color: T.text }}
                        />
                      </div>
                    ))}
                    <div className="flex justify-between"><span style={{ color: T.text3 }}>RR</span><span style={{ color: T.text }}>{pos.rr.toFixed(2)}</span></div>
                  </div>
                  <div className="mt-3 grid grid-cols-2 gap-2">
                    <Button size="sm" variant="secondary" onClick={() => eng()?.moveToBE()}>{tx('Беззбиток', 'Breakeven')}</Button>
                    <Button size="sm" variant="secondary" onClick={() => eng()?.closePosition('manual')}>{tx('Закрити', 'Close')}</Button>
                  </div>
                </div>
              )}
            </div>

            <div className="px-4 pb-4" style={{ borderTop: `1px solid ${T.line}` }}>
              <div className="grid grid-cols-3 gap-2 pt-4">
                {[
                  [tx('Угод', 'Trades'), stats.n, T.text],
                  ['Win rate', stats.wr == null ? '—' : `${stats.wr.toFixed(0)}%`, T.warn],
                  [tx('Разом', 'Net'), stats.n ? fmtR(stats.net) : '—', stats.net >= 0 ? T.ok : T.bad],
                ].map(([label, v, c]) => (
                  <div key={label} className="rounded-lg px-2.5 py-2" style={{ background: T.sunken }}>
                    <div className="text-[10.5px] font-semibold uppercase tracking-[0.1em]" style={{ color: T.text3 }}>{label}</div>
                    <div className="mt-1 text-[15px] font-bold tabular-nums" style={{ fontFamily: T.mono, color: c }}>{v}</div>
                  </div>
                ))}
              </div>

              {unsaved.length > 0 && sessionId && !demo && (
                <Button size="sm" block className="mt-3" loading={saving} onClick={() => saveTrades(unsaved)}>
                  {tx(`Записати ${unsaved.length} ${plural(unsaved.length, 'угоду', 'угоди', 'угод')} у бектест`, `Save ${unsaved.length} to backtest`)}
                </Button>
              )}
              {closed.length > 0 && !sessionId && (
                <p className="mt-3 text-[12px] leading-relaxed" style={{ color: T.text3 }}>
                  {tx('Угоди не записуються. Обери бектест угорі праворуч — і їх можна буде зберегти.', 'Trades aren’t saved. Pick a backtest at the top right to save them.')}
                </p>
              )}

              <div className="mt-3 space-y-1.5">
                {[...closed].reverse().map((t) => (
                  <div key={t.id} className="flex items-center gap-2 rounded-lg px-2.5 py-2 text-[12.5px]" style={{ background: T.sunken }}>
                    <span className="w-10 font-bold" style={{ color: t.side === 'LONG' ? '#5b8cff' : '#f23645' }}>{t.side === 'LONG' ? 'Buy' : 'Sell'}</span>
                    <span className="min-w-0 flex-1 truncate tabular-nums" style={{ fontFamily: T.mono, color: T.text3 }}>{fmtStamp(t.entryT, prefs)}</span>
                    <span className="font-bold tabular-nums" style={{ fontFamily: T.mono, color: t.result === 'BE' ? T.text2 : t.r > 0 ? T.ok : T.bad }}>
                      {t.result === 'BE' ? 'BE' : fmtR(t.r)}
                    </span>
                    {t.saved && <Check size={13} style={{ color: T.ok }} aria-label={tx('Записано', 'Saved')} />}
                  </div>
                ))}
              </div>
            </div>
            {!prefs.logo && (
              <a href="https://www.tradingview.com/" target="_blank" rel="noreferrer" className="mt-auto px-4 pb-3 pt-2 text-[11px] transition-colors hover:underline" style={{ color: T.text4 }}>
                {tx('Графіки', 'Charts by')} TradingView Lightweight Charts™
              </a>
            )}
          </aside>
        )}
      </div>

      {settingsOpen && <ChartSettings prefs={prefs} onChange={setPrefs} onClose={() => setSettingsOpen(false)} />}
      {editing && (
        <DrawingSettings
          key={editing.id}
          d={editing}
          digits={d}
          fmtTime={(t) => fmtStamp(t, prefs)}
          onChange={(patch, record) => { dmRef.current?.update(editing.id, patch, record); setDrawEdit(editing.id); }}
          onClose={() => setDrawEdit(null)}
          onSaveDefault={() => {
            const dm = dmRef.current;
            dm.defaults = { ...dm.defaults, [editing.type]: JSON.parse(JSON.stringify(editing.style)) };
            saveDefaults(uid, dm.defaults);
            notify.success(tx('Збережено', 'Saved'), tx('Нові такі фігури будуть з цим стилем.', 'New drawings of this type will use this style.'));
          }}
          onResetDefault={() => {
            const dm = dmRef.current;
            const next = { ...dm.defaults }; delete next[editing.type];
            dm.defaults = next;
            saveDefaults(uid, next);
            dm.update(editing.id, { style: JSON.parse(JSON.stringify(TOOLS[editing.type].style)) }, false);
          }}
        />
      )}
    </div>
  );

  return createPortal(page, document.body);
}
