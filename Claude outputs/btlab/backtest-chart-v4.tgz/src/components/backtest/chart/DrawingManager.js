import { CrosshairMode } from 'lightweight-charts';
import { upperBound } from '../../../lib/candles/agg';
import { withAlpha } from '../../../lib/candles/chartPrefs';
import {
  TOOLS, newDrawing, distToSeg, extendSeg, DASH, esc,
} from '../../../lib/candles/drawings';
import { t as tx } from '../../../lib/lang';

/* ==================================================================
   Малювання на графіку — мишка, геометрія, SVG.

   Події ловимо на контейнері графіка у фазі перехоплення: так ми
   встигаємо раніше за бібліотеку і, коли клік наш (ставимо точку,
   тягнемо лінію), гасимо його — графік не їде разом із лінією. Коли
   клік не наш (порожнє місце), пропускаємо далі, і графік тягнеться
   як завжди.

   Малюємо в той самий SVG-шар, що й позиції: рушій кличе svg() на
   кожен кадр, тож фігури їдуть разом зі зумом і прокруткою.
================================================================== */

const HANDLE = 5;
const HIT = 6;

const fmtSpan = (sec) => {
  const m = Math.round(Math.abs(sec) / 60);
  const d = Math.floor(m / 1440); const h = Math.floor((m % 1440) / 60); const mm = m % 60;
  const parts = [];
  if (d) parts.push(`${d}${tx('д', 'd')}`);
  if (h) parts.push(`${h}${tx('г', 'h')}`);
  if (mm || !parts.length) parts.push(`${mm}${tx('хв', 'm')}`);
  return parts.join(' ');
};

export default class DrawingManager {
  constructor(engine, host, cb) {
    this.e = engine;
    this.host = host;
    this.cb = cb;
    this.list = [];
    this.sel = null;
    this.hover = null;
    this.tool = null;
    this.cursor = 'cur-cross';
    this.magnet = 'off';
    this.keep = false;
    this.lockAll = false;
    this.hideAll = false;
    this.draft = null;
    this.drag = null;
    this.temp = null;
    this.mouse = null;
    this.defaults = {};
    this.past = [];
    this.futureStack = [];

    this.down = this.down.bind(this);
    this.move = this.move.bind(this);
    this.up = this.up.bind(this);
    this.dbl = this.dbl.bind(this);
    this.leave = this.leave.bind(this);
    host.addEventListener('pointerdown', this.down, true);
    host.addEventListener('mousedown', this.swallow = (ev) => { if (this.ate) { ev.stopPropagation(); ev.preventDefault(); } }, true);
    host.addEventListener('touchstart', this.swallowT = (ev) => { if (this.ate) ev.stopPropagation(); }, true);
    window.addEventListener('pointermove', this.move, true);
    window.addEventListener('pointerup', this.up, true);
    host.addEventListener('dblclick', this.dbl, true);
    host.addEventListener('pointerleave', this.leave);
    this.applyCursor();
  }

  destroy() {
    this.host.removeEventListener('pointerdown', this.down, true);
    this.host.removeEventListener('mousedown', this.swallow, true);
    this.host.removeEventListener('touchstart', this.swallowT, true);
    window.removeEventListener('pointermove', this.move, true);
    window.removeEventListener('pointerup', this.up, true);
    this.host.removeEventListener('dblclick', this.dbl, true);
    this.host.removeEventListener('pointerleave', this.leave);
  }

  /* ---------------- стан ---------------- */

  setList(list) {
    this.list = list || [];
    this.sel = null;
    this.draft = null;
    this.temp = null;
    this.past = [];
    this.futureStack = [];
    this.cb.onSelect?.(null);
  }

  changed() { this.cb.onChange?.(this.list); }

  snapshot() {
    this.past.push(JSON.stringify(this.list));
    if (this.past.length > 60) this.past.shift();
    this.futureStack = [];
  }

  undo() {
    if (!this.past.length) return;
    this.futureStack.push(JSON.stringify(this.list));
    this.list = JSON.parse(this.past.pop());
    this.select(this.list.find((d) => d.id === this.sel)?.id || null);
    this.changed();
  }

  redo() {
    if (!this.futureStack.length) return;
    this.past.push(JSON.stringify(this.list));
    this.list = JSON.parse(this.futureStack.pop());
    this.changed();
  }

  setTool(tool) {
    this.tool = tool;
    this.draft = null;
    if (tool) this.select(null);
    this.applyCursor();
    this.cb.onTool?.(tool);
  }

  setCursor(c) {
    this.cursor = c;
    this.setTool(null);
  }

  applyCursor() {
    const c = this.tool ? 'cur-cross' : this.cursor;
    this.host.dataset.cursor = c;
    /* Курсор «стрілка» — без перехрестя, як у TV. */
    const mode = c === 'cur-arrow' ? CrosshairMode.Hidden : (this.e.prefs.crosshair === 'magnet' ? CrosshairMode.Magnet : CrosshairMode.Normal);
    this.e.chart.applyOptions({ crosshair: { mode } });
  }

  get selected() { return this.list.find((d) => d.id === this.sel) || null; }

  select(id) {
    this.sel = id;
    this.cb.onSelect?.(this.selected);
  }

  update(id, patch, record = true) {
    const d = this.list.find((x) => x.id === id);
    if (!d) return;
    /* Тягнеш повзунок кольору — це одна дія, а не сотня кроків «назад». */
    const now = Date.now();
    if (record && now - (this.lastRec || 0) > 700) this.snapshot();
    if (record) this.lastRec = now;
    Object.assign(d, typeof patch === 'function' ? patch(d) : patch);
    if (d.id === this.sel) this.cb.onSelect?.(d);
    this.changed();
  }

  remove(id) {
    this.snapshot();
    this.list = this.list.filter((d) => d.id !== id);
    if (this.sel === id) this.select(null);
    this.changed();
  }

  removeAll() {
    if (!this.list.length) return;
    this.snapshot();
    this.list = [];
    this.select(null);
    this.changed();
  }

  clone(id) {
    const d = this.list.find((x) => x.id === id);
    if (!d) return;
    this.snapshot();
    const sec = this.e.agg?.sec || 60;
    const copy = { ...JSON.parse(JSON.stringify(d)), id: `d${Date.now().toString(36)}${Math.random().toString(36).slice(2, 5)}` };
    copy.pts = copy.pts.map((q) => ({ t: q.t + sec * 5, p: q.p }));
    this.list.push(copy);
    this.select(copy.id);
    this.changed();
  }

  /* ---------------- координати ---------------- */

  get ready() { return !!(this.e.agg && this.e.base); }

  plot() {
    const ts = this.e.chart.timeScale();
    return { w: ts.width(), h: this.e.chart.paneSize(0).height };
  }

  absOf(t) {
    const a = this.e.agg; const sec = a.sec; const last = this.e.lastK;
    if (t <= a.t[0]) return (t - a.t[0]) / sec;
    if (t >= a.t[last]) return last + (t - a.t[last]) / sec;
    const k = upperBound(a.t, t, 0, last + 1) - 1;
    const span = Math.max(sec, (a.t[k + 1] ?? a.t[k] + sec) - a.t[k]);
    return k + Math.min(0.999, (t - a.t[k]) / span);
  }

  timeOf(abs) {
    const a = this.e.agg; const sec = a.sec; const last = this.e.lastK;
    if (abs <= 0) return a.t[0] + abs * sec;
    if (abs >= last) return a.t[last] + (abs - last) * sec;
    const k = Math.floor(abs);
    const span = Math.max(sec, a.t[k + 1] - a.t[k]);
    return a.t[k] + (abs - k) * span;
  }

  /* Бібліотека перетворює в координату лише цілі індекси (дробовий дає
     0), а точка малюнка може бути між свічками: інтерполюємо самі. */
  lx(l) {
    const ts = this.e.chart.timeScale();
    const f = Math.floor(l);
    const x0 = ts.logicalToCoordinate(f);
    if (x0 == null || l === f) return x0;
    const x1 = ts.logicalToCoordinate(f + 1);
    return x1 == null ? x0 : x0 + (x1 - x0) * (l - f);
  }

  x(t) { return this.lx(this.absOf(t) - this.e.win); }
  y(p) { return this.e.series.priceToCoordinate(p); }

  /* Точка з мишки. Час — на свічку (як у TV), ціна — з магнітом. */
  pointAt(px, py, { snapTime = true, magnet = true } = {}) {
    const ts = this.e.chart.timeScale();
    const l = ts.coordinateToLogical(px);
    let abs = (l ?? 0) + this.e.win;
    if (snapTime) abs = Math.round(abs);
    const t = this.timeOf(abs);
    let p = this.e.series.coordinateToPrice(py);
    const mode = this.magnet;
    if (magnet && mode !== 'off') {
      const k = Math.round(abs);
      if (k >= 0 && k <= this.e.lastK) {
        const b = this.e.bar(k);
        let best = null; let bd = Infinity;
        for (const v of [b.open, b.high, b.low, b.close]) {
          const yy = this.y(v);
          const dd = Math.abs(yy - py);
          if (dd < bd) { bd = dd; best = v; }
        }
        if (mode === 'strong' || bd < 18) p = best;
      }
    }
    return { t, p };
  }

  local(ev) {
    const r = this.host.getBoundingClientRect();
    return { x: ev.clientX - r.left, y: ev.clientY - r.top };
  }

  inPlot({ x, y }) {
    const { w, h } = this.plot();
    return x >= 0 && y >= 0 && x <= w && y <= h;
  }

  visible(d) {
    if (this.hideAll) return false;
    return !d.vis || d.vis[this.e.tf] !== false;
  }

  /* ---------------- мишка ---------------- */

  eat(ev) {
    ev.stopPropagation();
    ev.preventDefault();
    this.ate = true;
  }

  down(ev) {
    this.ate = false;
    if (!this.ready || this.e.selecting || ev.button !== 0) return;
    const m = this.local(ev);
    if (!this.inPlot(m)) return;
    this.mouse = m;
    this.downAt = m;

    /* Тимчасова лінійка й зум зникають з наступним кліком. */
    if (this.temp && !this.draft) { this.temp = null; }

    if (this.tool || (ev.shiftKey && !this.draft)) {
      this.eat(ev);
      const tool = this.tool || 'measure';
      const def = TOOLS[tool];
      const pt = this.pointAt(m.x, m.y, { snapTime: tool !== 'brush' && tool !== 'highlighter' });
      if (def.points === 0) {
        this.draft = newDrawing(tool, [pt], this.defaults);
        this.draft.free = true;
        return;
      }
      if (!this.draft) {
        if (def.points === 1) { this.place(newDrawing(tool, [pt], this.defaults)); return; }
        this.draft = newDrawing(tool, [pt, { ...pt }], this.defaults);
        this.draft.tool = tool;
        return;
      }
      const d = this.draft;
      d.pts[d.pts.length - 1] = pt;
      if (def.points === -1 || d.pts.length < def.points) d.pts.push({ ...pt });
      else this.place(d);
      return;
    }

    const hit = this.hit(m.x, m.y);
    if (this.cursor === 'eraser') {
      if (hit) { this.eat(ev); this.remove(hit.id); }
      return;
    }
    if (hit) {
      this.eat(ev);
      this.select(hit.id);
      const d = this.selected;
      if (d.locked || this.lockAll) return;
      this.drag = { id: d.id, part: hit.part, idx: hit.idx, start: m, orig: JSON.parse(JSON.stringify(d.pts)), moved: false, before: JSON.stringify(this.list) };
    } else if (this.sel) {
      this.select(null);
    }
  }

  move(ev) {
    if (!this.ready) return;
    const m = this.local(ev);
    this.mouse = m;
    if (this.drag) {
      ev.stopPropagation();
      this.dragTo(m, ev.shiftKey);
      return;
    }
    if (this.draft) {
      const d = this.draft;
      if (d.free) {
        if (!(ev.buttons & 1)) return;
        ev.stopPropagation();
        const last = d.pts[d.pts.length - 1];
        const lx = this.x(last.t); const ly = this.y(last.p);
        if (lx == null || Math.hypot(lx - m.x, ly - m.y) > 2.5) d.pts.push(this.pointAt(m.x, m.y, { snapTime: false, magnet: false }));
        return;
      }
      let pt = this.pointAt(m.x, m.y);
      /* Shift — рівно горизонтально, як у TV. */
      if (ev.shiftKey && d.pts.length >= 2) pt = { ...pt, p: d.pts[d.pts.length - 2].p };
      d.pts[d.pts.length - 1] = pt;
      return;
    }
    if (!this.inPlot(m) || ev.buttons) { if (this.hover) { this.hover = null; this.setHostCursor(); } return; }
    const h = this.hit(m.x, m.y);
    const id = h ? `${h.id}:${h.part}` : null;
    if (id !== this.hoverKey) {
      this.hoverKey = id;
      this.hover = h;
      this.setHostCursor();
    }
  }

  up(ev) {
    if (!this.ready) return;
    const m = this.local(ev);
    if (this.drag) {
      const dr = this.drag;
      this.drag = null;
      if (dr.moved) {
        this.past.push(dr.before);
        this.futureStack = [];
        this.changed();
        this.cb.onSelect?.(this.selected);
      }
      ev.stopPropagation();
      return;
    }
    const d = this.draft;
    if (!d) return;
    if (d.free) { if (d.pts.length > 1) this.place(d); else this.draft = null; return; }
    /* Клік-протягування-відпустив для двоточкових — теж ставить фігуру. */
    const def = TOOLS[d.type];
    if (def.points === 2 && d.pts.length === 2 && this.downAt && Math.hypot(m.x - this.downAt.x, m.y - this.downAt.y) > 8) {
      d.pts[1] = this.pointAt(m.x, m.y);
      this.place(d);
    }
  }

  dbl(ev) {
    if (!this.ready) return;
    const d = this.draft;
    if (d && TOOLS[d.type].points === -1) {
      this.eat(ev);
      d.pts.pop();
      if (d.pts.length > 2 && JSON.stringify(d.pts[d.pts.length - 1]) === JSON.stringify(d.pts[d.pts.length - 2])) d.pts.pop();
      if (d.pts.length >= 2) this.place(d); else this.draft = null;
      return;
    }
    const m = this.local(ev);
    const h = this.hit(m.x, m.y);
    if (h) {
      this.eat(ev);
      this.select(h.id);
      const sel = this.selected;
      if (TOOLS[sel.type].text) this.cb.onText?.(sel);
      else this.cb.onSettings?.(sel);
    }
  }

  leave() { this.mouse = null; }

  /* Готова фігура — у список. */
  place(d) {
    this.draft = null;
    const def = TOOLS[d.type];
    if (d.type === 'long' || d.type === 'short') d.pts = this.positionPts(d.type, d.pts[0]);
    if (def.temp) {
      if (d.type === 'zoom') this.applyZoom(d);
      else this.temp = d;
      if (!this.keep) this.setTool(null);
      return;
    }
    delete d.free; delete d.tool;
    this.snapshot();
    this.list.push(d);
    this.select(d.id);
    this.changed();
    if (!this.keep) this.setTool(null);
    if (def.text) this.cb.onText?.(d);
  }

  positionPts(type, pt) {
    const sec = this.e.agg.sec;
    const dist = this.e.defaultDistance() * (this.e.prefs.atrMult || 1);
    const rr = this.e.prefs.rr || 2;
    const dir = type === 'long' ? 1 : -1;
    const t2 = pt.t + sec * 30;
    return [{ t: pt.t, p: pt.p }, { t: t2, p: pt.p + dir * dist * rr }, { t: t2, p: pt.p - dir * dist }];
  }

  applyZoom(d) {
    const a = this.absOf(d.pts[0].t) - this.e.win;
    const b = this.absOf(d.pts[1].t) - this.e.win;
    if (Math.abs(b - a) < 2) return;
    this.e.chart.timeScale().setVisibleLogicalRange({ from: Math.min(a, b), to: Math.max(a, b) });
  }

  dragTo(m, shift) {
    const dr = this.drag;
    const d = this.list.find((x) => x.id === dr.id);
    if (!d) return;
    if (!dr.moved && Math.hypot(m.x - dr.start.x, m.y - dr.start.y) < 3) return;
    dr.moved = true;
    if (dr.part === 'point') {
      let pt = this.pointAt(m.x, m.y);
      if (shift && d.pts.length > 1) pt = { ...pt, p: d.pts[dr.idx === 0 ? 1 : 0].p };
      if (d.type === 'long' || d.type === 'short') {
        const o = dr.orig;
        if (dr.idx === 0) {
          const dp = pt.p - o[0].p;
          d.pts = [{ t: pt.t, p: pt.p }, { t: o[1].t, p: o[1].p + dp }, { t: o[2].t, p: o[2].p + dp }];
        } else if (dr.idx === 1) d.pts[1] = { ...d.pts[1], p: pt.p };
        else if (dr.idx === 2) d.pts[2] = { ...d.pts[2], p: pt.p };
        else { d.pts[1] = { ...d.pts[1], t: Math.max(pt.t, o[0].t + this.e.agg.sec) }; d.pts[2] = { ...d.pts[2], t: d.pts[1].t }; }
        return;
      }
      if (d.type === 'channel' && dr.idx === 2) {
        d.pts[2] = { t: d.pts[2].t, p: pt.p };
        return;
      }
      d.pts[dr.idx] = pt;
      return;
    }
    /* Тягнемо всю фігуру: зсув у свічках і в ціні від точки старту. */
    const ts = this.e.chart.timeScale();
    const l0 = ts.coordinateToLogical(dr.start.x); const l1 = ts.coordinateToLogical(m.x);
    const dAbs = Math.round((l1 ?? 0) - (l0 ?? 0));
    const p0 = this.e.series.coordinateToPrice(dr.start.y); const p1 = this.e.series.coordinateToPrice(m.y);
    const dp = (p1 ?? 0) - (p0 ?? 0);
    const free = d.type === 'brush' || d.type === 'highlighter';
    d.pts = dr.orig.map((q) => {
      const abs = this.absOf(q.t) + dAbs;
      return { t: free ? q.t + dAbs * this.e.agg.sec : this.timeOf(abs), p: q.p + (d.type === 'vline' ? 0 : dp) };
    });
  }

  setHostCursor() {
    const h = this.hover;
    if (this.tool || !h) { this.host.style.removeProperty('--draw-cursor'); this.host.dataset.over = ''; return; }
    if (this.cursor === 'eraser') { this.host.dataset.over = 'erase'; return; }
    const d = this.list.find((x) => x.id === h.id);
    const locked = d?.locked || this.lockAll;
    this.host.dataset.over = locked ? 'pointer' : (h.part === 'point' ? 'point' : 'move');
  }

  /* ---------------- геометрія й попадання ---------------- */

  /* Усе, що треба і для малювання, і для кліку: відрізки, області,
     ручки. Координати — пікселі області графіка. */
  geom(d) {
    const W = this.plot().w; const H = this.plot().h;
    const P = d.pts.map((q) => ({ x: this.x(q.t), y: this.y(q.p) }));
    if (P.some((q) => q.x == null || q.y == null)) return null;
    const g = { segs: [], areas: [], handles: P.map((q, i) => ({ ...q, idx: i })) };
    const s = d.style || {};
    switch (d.type) {
      case 'trend': case 'ray': case 'extended': case 'info': case 'angle': case 'arrow': {
        if (P.length < 2) return g;
        const [ax, ay, bx, by] = extendSeg(P[0].x, P[0].y, P[1].x, P[1].y, W, s.extendLeft, s.extendRight);
        g.segs.push([ax, ay, bx, by]);
        break;
      }
      case 'path': case 'brush': case 'highlighter':
        for (let i = 1; i < P.length; i += 1) g.segs.push([P[i - 1].x, P[i - 1].y, P[i].x, P[i].y]);
        if (d.type !== 'path') g.handles = [];
        break;
      case 'hline':
        g.segs.push([0, P[0].y, W, P[0].y]);
        break;
      case 'hray':
        g.segs.push([P[0].x, P[0].y, W, P[0].y]);
        break;
      case 'vline':
        g.segs.push([P[0].x, 0, P[0].x, H]);
        g.handles = [{ x: P[0].x, y: Math.min(H - 12, Math.max(12, P[0].y)), idx: 0 }];
        break;
      case 'cross':
        g.segs.push([0, P[0].y, W, P[0].y], [P[0].x, 0, P[0].x, H]);
        break;
      case 'channel': {
        if (P.length < 2) return g;
        const off = P.length > 2 ? this.channelOffset(d, P) : 0;
        g.segs.push([P[0].x, P[0].y, P[1].x, P[1].y]);
        if (P.length > 2) {
          g.segs.push([P[0].x, P[0].y + off, P[1].x, P[1].y + off]);
          g.areas.push({ poly: [[P[0].x, P[0].y], [P[1].x, P[1].y], [P[1].x, P[1].y + off], [P[0].x, P[0].y + off]] });
          g.handles = [{ ...P[0], idx: 0 }, { ...P[1], idx: 1 }, { x: (P[0].x + P[1].x) / 2, y: (P[0].y + P[1].y) / 2 + off, idx: 2 }];
          g.off = off;
        }
        break;
      }
      case 'rect': case 'ellipse': case 'prange': case 'drange': case 'dprange': case 'measure': case 'zoom': {
        if (P.length < 2) return g;
        let x1 = Math.min(P[0].x, P[1].x); let x2 = Math.max(P[0].x, P[1].x);
        const y1 = Math.min(P[0].y, P[1].y); const y2 = Math.max(P[0].y, P[1].y);
        if (d.type === 'rect') { if (s.extendLeft) x1 = 0; if (s.extendRight) x2 = W; }
        g.box = { x1, x2, y1, y2 };
        g.areas.push({ rect: [x1, y1, x2 - x1, y2 - y1] });
        if (d.type === 'rect') {
          g.handles = [
            { x: P[0].x, y: P[0].y, idx: 0 }, { x: P[1].x, y: P[1].y, idx: 1 },
          ];
        }
        break;
      }
      case 'fib': case 'fibext': {
        if (P.length < 2) return g;
        const lv = this.fibPrices(d);
        const xs = d.type === 'fib' ? [P[0].x, P[1].x] : [P[2]?.x ?? P[1].x, (P[2]?.x ?? P[1].x) + Math.abs(P[1].x - P[0].x)];
        let x1 = Math.min(...xs); let x2 = Math.max(...xs);
        if (s.extendLeft) x1 = 0;
        if (s.extendRight) x2 = W;
        g.fib = { x1, x2, lv };
        lv.forEach((l) => { const yy = this.y(l.price); if (yy != null) g.segs.push([x1, yy, x2, yy]); });
        g.segs.push([P[0].x, P[0].y, P[1].x, P[1].y]);
        if (P[2]) g.segs.push([P[1].x, P[1].y, P[2].x, P[2].y]);
        break;
      }
      case 'long': case 'short': {
        const x1 = P[0].x; const x2 = P[1].x;
        g.pos = { x1, x2, ye: P[0].y, yt: P[1].y, ys: P[2].y };
        g.areas.push({ rect: [Math.min(x1, x2), Math.min(P[0].y, P[1].y, P[2].y), Math.abs(x2 - x1), Math.abs(Math.max(P[1].y, P[2].y, P[0].y) - Math.min(P[0].y, P[1].y, P[2].y))] });
        g.handles = [{ x: x1, y: P[0].y, idx: 0 }, { x: x1, y: P[1].y, idx: 1 }, { x: x1, y: P[2].y, idx: 2 }, { x: x2, y: P[0].y, idx: 3 }];
        break;
      }
      case 'text': {
        const fs = s.fontSize || 14;
        const lines = String(d.text || tx('Текст', 'Text')).split('\n');
        const w = Math.max(...lines.map((l) => l.length)) * fs * 0.6 + 8;
        const h = lines.length * fs * 1.3 + 6;
        g.areas.push({ rect: [P[0].x - 4, P[0].y - fs - 2, w, h] });
        g.text = { lines, fs, w, h };
        break;
      }
      case 'note': {
        if (P.length < 2) return g;
        const fs = s.fontSize || 13;
        const lines = String(d.text || tx('Текст', 'Text')).split('\n');
        const w = Math.max(...lines.map((l) => l.length)) * fs * 0.6 + 20;
        const h = lines.length * fs * 1.3 + 12;
        g.segs.push([P[0].x, P[0].y, P[1].x, P[1].y]);
        g.areas.push({ rect: [P[1].x - w / 2, P[1].y - h / 2, w, h] });
        g.text = { lines, fs, w, h };
        break;
      }
      case 'plabel': {
        const fs = s.fontSize || 12;
        const label = this.fmtP(d.pts[0].p);
        const w = label.length * fs * 0.62 + 14; const h = fs + 10;
        g.areas.push({ rect: [P[0].x, P[0].y - h - 6, w, h] });
        g.label = { label, w, h, fs };
        break;
      }
      case 'arrowup': case 'arrowdown':
        g.areas.push({ rect: [P[0].x - 9, d.type === 'arrowup' ? P[0].y : P[0].y - 26, 18, 26] });
        break;
      default:
        break;
    }
    g.P = P;
    return g;
  }

  channelOffset(d, P) {
    /* Зсув паралелі — різниця між третьою точкою й ціною базової
       лінії в той самий момент часу. */
    const [a, b, c] = d.pts;
    const k = b.t === a.t ? 0 : (c.t - a.t) / (b.t - a.t);
    const base = a.p + (b.p - a.p) * k;
    const yb = this.y(base);
    const yc = this.y(c.p);
    return yb == null || yc == null ? 0 : yc - yb;
  }

  fibPrices(d) {
    const [a, b, c] = d.pts;
    const levels = (d.style.levels || []).filter((l) => l.on);
    return levels.map((l) => {
      const v = d.style.reverse ? 1 - l.v : l.v;
      const price = d.type === 'fib' ? b.p + (a.p - b.p) * v : (c ? c.p : b.p) + (b.p - a.p) * v;
      return { ...l, price };
    });
  }

  hit(x, y) {
    for (let i = this.list.length - 1; i >= 0; i -= 1) {
      const d = this.list[i];
      if (!this.visible(d)) continue;
      const g = this.geom(d);
      if (!g) continue;
      if (d.id === this.sel || (this.hover && this.hover.id === d.id)) {
        for (const h of g.handles) if (Math.hypot(h.x - x, h.y - y) <= HANDLE + 3) return { id: d.id, part: 'point', idx: h.idx };
      }
      for (const sgm of g.segs) if (distToSeg(x, y, ...sgm) <= HIT + (d.style?.width || 1) / 2) return { id: d.id, part: 'body' };
      for (const a of g.areas) {
        if (a.rect) {
          const [rx, ry, rw, rh] = a.rect;
          if (d.type === 'ellipse') {
            const cx = rx + rw / 2; const cy = ry + rh / 2;
            const v = ((x - cx) / (rw / 2 || 1)) ** 2 + ((y - cy) / (rh / 2 || 1)) ** 2;
            if (v <= 1.08) return { id: d.id, part: 'body' };
          } else if (x >= rx && x <= rx + rw && y >= ry && y <= ry + rh) return { id: d.id, part: 'body' };
        }
        if (a.poly && pointInPoly(x, y, a.poly)) return { id: d.id, part: 'body' };
      }
    }
    return null;
  }

  /* ---------------- малювання ---------------- */

  fmtP(p) { return Number(p).toFixed(this.e.base?.digits ?? 2); }

  svg() {
    if (!this.ready) return '';
    const out = [];
    for (const d of this.list) if (this.visible(d)) out.push(this.draw(d, d.id === this.sel, this.hover?.id === d.id));
    if (this.draft) out.push(this.draw(this.draft, true, false));
    if (this.temp) out.push(this.draw(this.temp, false, false));
    return out.join('');
  }

  draw(d, selected, hovered) {
    const g = this.geom(d);
    if (!g) return '';
    const s = d.style || {};
    const W = this.plot().w; const H = this.plot().h;
    const col = s.color || '#2962ff';
    const width = s.width || 1;
    const dash = DASH[s.lineStyle] || '';
    const stroke = `stroke="${col}" stroke-width="${width}" ${dash ? `stroke-dasharray="${dash}"` : ''} stroke-linecap="round" fill="none"`;
    const o = [];
    const P = g.P;
    const label = (x, y, text, bg, fg = '#fff', anchor = 'middle', fs = 11) => {
      const w = String(text).length * fs * 0.6 + 12; const h = fs + 8;
      const lx = anchor === 'middle' ? x - w / 2 : anchor === 'end' ? x - w : x;
      o.push(`<rect x="${lx}" y="${y - h / 2}" width="${w}" height="${h}" rx="4" fill="${bg}"/>`);
      o.push(`<text x="${lx + w / 2}" y="${y + fs / 2 - 1.5}" fill="${fg}" font-size="${fs}" text-anchor="middle" font-family="-apple-system,BlinkMacSystemFont,'Trebuchet MS',Roboto,sans-serif">${esc(text)}</text>`);
    };

    switch (d.type) {
      case 'trend': case 'ray': case 'extended': case 'info': case 'angle': case 'arrow': case 'path':
        g.segs.forEach(([a, b, c, e]) => o.push(`<line x1="${a}" y1="${b}" x2="${c}" y2="${e}" ${stroke}/>`));
        if (d.type === 'arrow' && P.length > 1) {
          const ang = Math.atan2(P[1].y - P[0].y, P[1].x - P[0].x);
          const L = 10 + width * 2;
          const p1 = [P[1].x - L * Math.cos(ang - 0.45), P[1].y - L * Math.sin(ang - 0.45)];
          const p2 = [P[1].x - L * Math.cos(ang + 0.45), P[1].y - L * Math.sin(ang + 0.45)];
          o.push(`<polygon points="${P[1].x},${P[1].y} ${p1} ${p2}" fill="${col}"/>`);
        }
        if ((d.type === 'info' || s.showInfo) && P.length > 1 && d.type !== 'path') {
          const [a, b] = d.pts;
          const dp = b.p - a.p;
          const bars = Math.round(this.absOf(b.t) - this.absOf(a.t));
          const txt = `${dp >= 0 ? '+' : ''}${this.fmtP(dp)} (${((dp / a.p) * 100).toFixed(2)}%) · ${bars} ${tx('бар.', 'bars')}`;
          label(P[1].x, P[1].y + (P[1].y > P[0].y ? 18 : -18), txt, withAlpha(col, 0.9));
        }
        if ((d.type === 'angle' || s.showAngle) && P.length > 1) {
          const ang = -Math.atan2(P[1].y - P[0].y, P[1].x - P[0].x) * 180 / Math.PI;
          o.push(`<line x1="${P[0].x}" y1="${P[0].y}" x2="${P[0].x + 50}" y2="${P[0].y}" stroke="${col}" stroke-width="1" stroke-dasharray="3 3"/>`);
          label(P[0].x + 64, P[0].y - 12, `${ang.toFixed(1)}°`, withAlpha(col, 0.9));
        }
        break;
      case 'brush': case 'highlighter':
        if (P.length > 1) o.push(`<polyline points="${P.map((q) => `${q.x},${q.y}`).join(' ')}" stroke="${col}" stroke-width="${width}" stroke-linecap="round" stroke-linejoin="round" fill="none"/>`);
        break;
      case 'hline': case 'hray': case 'vline': case 'cross':
        g.segs.forEach(([a, b, c, e]) => o.push(`<line x1="${a}" y1="${b}" x2="${c}" y2="${e}" ${stroke}/>`));
        if (s.showPrice && d.type !== 'vline') label(W - 4, P[0].y, this.fmtP(d.pts[0].p), col, '#fff', 'end');
        if (s.showTime && (d.type === 'vline' || d.type === 'cross')) label(P[0].x, H - 12, this.e.fmtTime?.(d.pts[0].t) || '', col);
        break;
      case 'channel':
        if (g.areas[0] && s.fill) o.push(`<polygon points="${g.areas[0].poly.map((q) => q.join(',')).join(' ')}" fill="${s.fill}"/>`);
        g.segs.forEach(([a, b, c, e]) => o.push(`<line x1="${a}" y1="${b}" x2="${c}" y2="${e}" ${stroke}/>`));
        if (P.length > 2 && s.showMiddle) {
          o.push(`<line x1="${P[0].x}" y1="${P[0].y + g.off / 2}" x2="${P[1].x}" y2="${P[1].y + g.off / 2}" stroke="${col}" stroke-width="1" stroke-dasharray="6 4"/>`);
        }
        break;
      case 'rect':
        o.push(`<rect x="${g.box.x1}" y="${g.box.y1}" width="${g.box.x2 - g.box.x1}" height="${g.box.y2 - g.box.y1}" fill="${s.fill || 'none'}" ${stroke.replace('fill="none"', '')}/>`);
        if (s.showMiddle) o.push(`<line x1="${g.box.x1}" y1="${(g.box.y1 + g.box.y2) / 2}" x2="${g.box.x2}" y2="${(g.box.y1 + g.box.y2) / 2}" stroke="${col}" stroke-width="1" stroke-dasharray="6 4"/>`);
        break;
      case 'ellipse': {
        const { x1, x2, y1, y2 } = g.box;
        o.push(`<ellipse cx="${(x1 + x2) / 2}" cy="${(y1 + y2) / 2}" rx="${(x2 - x1) / 2}" ry="${(y2 - y1) / 2}" fill="${s.fill || 'none'}" ${stroke.replace('fill="none"', '')}/>`);
        break;
      }
      case 'prange': case 'drange': case 'dprange': case 'measure': {
        const { x1, x2, y1, y2 } = g.box;
        const [a, b] = d.pts;
        const dp = b.p - a.p;
        const up = dp >= 0;
        const mc = d.type === 'measure' ? (up ? '#2962ff' : '#f23645') : col;
        const fill = d.type === 'measure' ? withAlpha(mc, 0.18) : (s.fill || 'none');
        o.push(`<rect x="${x1}" y="${y1}" width="${x2 - x1}" height="${y2 - y1}" fill="${fill}"/>`);
        const mx = (x1 + x2) / 2; const my = (y1 + y2) / 2;
        const bars = Math.round(this.absOf(b.t) - this.absOf(a.t));
        const vert = d.type !== 'drange';
        const horz = d.type !== 'prange';
        if (vert) {
          o.push(`<line x1="${mx}" y1="${P[0].y}" x2="${mx}" y2="${P[1].y}" stroke="${mc}" stroke-width="1"/>`);
          const ay = P[1].y; const dir = P[1].y > P[0].y ? -1 : 1;
          o.push(`<polygon points="${mx},${ay} ${mx - 5},${ay + dir * 8} ${mx + 5},${ay + dir * 8}" fill="${mc}"/>`);
        }
        if (horz) {
          o.push(`<line x1="${P[0].x}" y1="${my}" x2="${P[1].x}" y2="${my}" stroke="${mc}" stroke-width="1"/>`);
          const ax = P[1].x; const dir = P[1].x > P[0].x ? -1 : 1;
          o.push(`<polygon points="${ax},${my} ${ax + dir * 8},${my - 5} ${ax + dir * 8},${my + 5}" fill="${mc}"/>`);
        }
        if (s.showInfo !== false) {
          const parts = [];
          if (vert) parts.push(`${up ? '+' : ''}${this.fmtP(dp)} (${((dp / a.p) * 100).toFixed(2)}%)`);
          if (horz) parts.push(`${bars} ${tx('бар.', 'bars')}, ${fmtSpan(b.t - a.t)}`);
          const ly = P[1].y > P[0].y ? y2 + 16 : y1 - 16;
          label(mx, ly, parts.join(' · '), withAlpha(mc, 0.92));
        }
        break;
      }
      case 'zoom': {
        const { x1, x2, y1, y2 } = g.box;
        o.push(`<rect x="${x1}" y="${y1}" width="${x2 - x1}" height="${y2 - y1}" fill="rgba(41,98,255,0.08)" stroke="#2962ff" stroke-dasharray="4 3"/>`);
        break;
      }
      case 'fib': case 'fibext': {
        const { x1, x2, lv } = g.fib;
        const ys = lv.map((l) => ({ ...l, y: this.y(l.price) })).filter((l) => l.y != null);
        if (s.fillLevels) {
          const sorted = [...ys].sort((a, b) => a.v - b.v);
          for (let i = 1; i < sorted.length; i += 1) {
            const a = sorted[i - 1]; const b = sorted[i];
            o.push(`<rect x="${x1}" y="${Math.min(a.y, b.y)}" width="${x2 - x1}" height="${Math.abs(b.y - a.y)}" fill="${withAlpha(b.c, s.fillAlpha ?? 0.12)}"/>`);
          }
        }
        ys.forEach((l) => {
          o.push(`<line x1="${x1}" y1="${l.y}" x2="${x2}" y2="${l.y}" stroke="${l.c}" stroke-width="${width}" ${dash ? `stroke-dasharray="${dash}"` : ''}/>`);
          if (s.showLevels || s.showPrices) {
            const t = `${s.showLevels ? l.v : ''}${s.showLevels && s.showPrices ? ' ' : ''}${s.showPrices ? `(${this.fmtP(l.price)})` : ''}`;
            o.push(`<text x="${x1 - 6}" y="${l.y + 4}" fill="${l.c}" font-size="11" text-anchor="end" font-family="-apple-system,BlinkMacSystemFont,'Trebuchet MS',Roboto,sans-serif">${esc(t)}</text>`);
          }
        });
        o.push(`<line x1="${P[0].x}" y1="${P[0].y}" x2="${P[1].x}" y2="${P[1].y}" stroke="${col}" stroke-width="1" stroke-dasharray="4 4"/>`);
        if (P[2]) o.push(`<line x1="${P[1].x}" y1="${P[1].y}" x2="${P[2].x}" y2="${P[2].y}" stroke="${col}" stroke-width="1" stroke-dasharray="4 4"/>`);
        break;
      }
      case 'long': case 'short': {
        const { x1, x2, ye, yt, ys } = g.pos;
        const L = Math.min(x1, x2); const Wd = Math.abs(x2 - x1);
        o.push(`<rect x="${L}" y="${Math.min(ye, yt)}" width="${Wd}" height="${Math.abs(yt - ye)}" fill="${s.tp}"/>`);
        o.push(`<rect x="${L}" y="${Math.min(ye, ys)}" width="${Wd}" height="${Math.abs(ys - ye)}" fill="${s.sl}"/>`);
        o.push(`<line x1="${L}" y1="${ye}" x2="${L + Wd}" y2="${ye}" stroke="${col}" stroke-width="1"/>`);
        if (s.showInfo !== false) {
          const [en, tp, sl] = d.pts;
          const risk = Math.abs(en.p - sl.p) || 1e-9;
          const rr = Math.abs(tp.p - en.p) / risk;
          const pct = (v) => `${((Math.abs(v - en.p) / en.p) * 100).toFixed(2)}%`;
          label(L + Wd / 2, yt + (yt < ye ? -14 : 14), `${tx('Ціль', 'Target')}: ${this.fmtP(tp.p)} (${pct(tp.p)})`, '#089981');
          label(L + Wd / 2, ys + (ys > ye ? 14 : -14), `${tx('Стоп', 'Stop')}: ${this.fmtP(sl.p)} (${pct(sl.p)})`, '#f23645');
          label(L + Wd / 2, ye, `R:R ${rr.toFixed(2)}`, d.type === 'long' ? '#2962ff' : '#e91e63');
        }
        break;
      }
      case 'text': {
        const { lines, fs, w, h } = g.text;
        const [rx, ry] = g.areas[0].rect;
        if (s.bg) o.push(`<rect x="${rx}" y="${ry}" width="${w}" height="${h}" rx="4" fill="${s.bg}" ${s.border ? `stroke="${s.border}"` : ''}/>`);
        lines.forEach((ln, i) => o.push(`<text x="${P[0].x}" y="${P[0].y + i * fs * 1.3}" fill="${s.textColor}" font-size="${fs}" font-weight="${s.bold ? 700 : 400}" font-style="${s.italic ? 'italic' : 'normal'}" font-family="-apple-system,BlinkMacSystemFont,'Trebuchet MS',Roboto,sans-serif">${esc(ln)}</text>`));
        break;
      }
      case 'note': {
        if (P.length < 2) break;
        const { lines, fs, w, h } = g.text;
        o.push(`<line x1="${P[0].x}" y1="${P[0].y}" x2="${P[1].x}" y2="${P[1].y}" stroke="${col}" stroke-width="1.5"/>`);
        o.push(`<circle cx="${P[0].x}" cy="${P[0].y}" r="3" fill="${col}"/>`);
        o.push(`<rect x="${P[1].x - w / 2}" y="${P[1].y - h / 2}" width="${w}" height="${h}" rx="6" fill="${col}"/>`);
        lines.forEach((ln, i) => o.push(`<text x="${P[1].x}" y="${P[1].y - h / 2 + 6 + fs + i * fs * 1.3 - 2}" fill="${s.textColor}" font-size="${fs}" text-anchor="middle" font-weight="${s.bold ? 700 : 400}" font-style="${s.italic ? 'italic' : 'normal'}" font-family="-apple-system,BlinkMacSystemFont,'Trebuchet MS',Roboto,sans-serif">${esc(ln)}</text>`));
        break;
      }
      case 'plabel': {
        const { label: lt, w, h, fs } = g.label;
        const x = P[0].x; const y = P[0].y;
        o.push(`<path d="M${x},${y} L${x + 6},${y - 6} L${x + w},${y - 6} L${x + w},${y - 6 - h} L${x},${y - 6 - h} Z" fill="${col}"/>`);
        o.push(`<text x="${x + w / 2}" y="${y - 6 - h / 2 + fs / 2 - 1}" fill="${s.textColor}" font-size="${fs}" text-anchor="middle" font-family="-apple-system,BlinkMacSystemFont,'Trebuchet MS',Roboto,sans-serif">${esc(lt)}</text>`);
        break;
      }
      case 'arrowup': case 'arrowdown': {
        const x = P[0].x; const y = P[0].y; const dir = d.type === 'arrowup' ? 1 : -1;
        o.push(`<path d="M${x},${y} L${x + 9},${y + dir * 11} L${x + 4},${y + dir * 11} L${x + 4},${y + dir * 26} L${x - 4},${y + dir * 26} L${x - 4},${y + dir * 11} L${x - 9},${y + dir * 11} Z" fill="${col}"/>`);
        break;
      }
      default:
        break;
    }

    if (selected || hovered) {
      g.handles.forEach((h) => {
        o.push(`<circle cx="${h.x}" cy="${h.y}" r="${HANDLE}" fill="${selected ? '#ffffff' : 'rgba(255,255,255,0.6)'}" stroke="#2962ff" stroke-width="1.5"/>`);
      });
    }
    return o.join('');
  }
}

function pointInPoly(x, y, poly) {
  let inside = false;
  for (let i = 0, j = poly.length - 1; i < poly.length; j = i, i += 1) {
    const [xi, yi] = poly[i]; const [xj, yj] = poly[j];
    if ((yi > y) !== (yj > y) && x < ((xj - xi) * (y - yi)) / (yj - yi) + xi) inside = !inside;
  }
  return inside;
}
