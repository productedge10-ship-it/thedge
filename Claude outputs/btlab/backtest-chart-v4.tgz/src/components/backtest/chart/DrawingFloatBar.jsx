import { T } from '../../../lib/theme';
import { t as tx } from '../../../lib/lang';
import { caps, itemName } from '../../../lib/candles/drawings';
import ColorPicker from './ColorPicker';
import { usePopover, PopPanel } from './Popover';
import DrawIcon from './DrawingIcons';

/* ==================================================================
   Плаваюча панель вибраного малюнка — як у TV: колір, заливка,
   товщина, стиль лінії, налаштування, замок, копія, видалити.
   Найчастіше людина міняє саме це, і лізти заради кольору у вікно
   налаштувань — зайвий крок.
================================================================== */

function Pop({ label, children, value }) {
  const pop = usePopover();
  return (
    <>
      <button
        ref={pop.anchor}
        type="button"
        title={label}
        aria-label={label}
        aria-expanded={pop.open}
        onClick={pop.toggle}
        className="grid h-8 min-w-8 place-items-center rounded-md px-1.5 transition-colors hover:bg-white/10"
        style={{ color: pop.open ? '#5b8cff' : T.text2, background: pop.open ? 'rgba(41,98,255,0.14)' : undefined }}
      >
        {value}
      </button>
      <PopPanel pop={pop} align="center">
        <div onClick={() => pop.setOpen(false)}>{children}</div>
      </PopPanel>
    </>
  );
}

const LineSample = ({ w = 2, style = 'solid' }) => (
  <svg width="34" height="12" aria-hidden>
    <line x1="2" y1="6" x2="32" y2="6" stroke="currentColor" strokeWidth={w} strokeDasharray={style === 'dashed' ? '6 4' : style === 'dotted' ? '1.5 3.5' : ''} strokeLinecap="round" />
  </svg>
);

export default function DrawingFloatBar({ d, onStyle, onPatch, onSettings, onClone, onDelete }) {
  if (!d) return null;
  const c = caps(d.type);
  const s = d.style || {};
  const Sep = () => <span className="mx-0.5 h-5 w-px" style={{ background: T.line }} />;
  return (
    <div
      className="absolute left-1/2 top-2 z-[12] flex -translate-x-1/2 items-center gap-0.5 rounded-xl px-1.5 py-1"
      style={{ background: T.surface3, border: `1px solid ${T.lineHi}`, boxShadow: '0 10px 26px rgba(0,0,0,0.4)', animation: 'edgeFly .14s ease-out' }}
    >
      <span className="px-1.5 text-[12px] font-semibold" style={{ color: T.text3 }}>{itemName(d.type)}</span>
      <Sep />
      {c.color && <ColorPicker value={s.color} onChange={(v) => onStyle({ color: v })} label={tx('Колір лінії', 'Line color')} />}
      {c.fill && <span className="ml-1"><ColorPicker value={s.fill} onChange={(v) => onStyle({ fill: v })} label={tx('Заливка', 'Fill')} /></span>}
      {c.textStyle && <span className="ml-1"><ColorPicker value={s.textColor} onChange={(v) => onStyle({ textColor: v })} label={tx('Колір тексту', 'Text color')} /></span>}
      {c.width && (
        <Pop label={tx('Товщина', 'Width')} value={<span className="flex items-center gap-1"><LineSample w={s.width} /><span className="text-[11px]">{s.width}px</span></span>}>
          {[1, 2, 3, 4].map((w) => (
            <button key={w} type="button" onClick={() => onStyle({ width: w })} className="flex w-full items-center gap-2 rounded-lg px-2 py-1.5 hover:bg-white/10" style={{ color: w === s.width ? '#5b8cff' : T.text }}>
              <LineSample w={w} /> <span className="text-[12px]">{w}px</span>
            </button>
          ))}
        </Pop>
      )}
      {c.lineStyle && (
        <Pop label={tx('Стиль лінії', 'Line style')} value={<LineSample w={2} style={s.lineStyle} />}>
          {['solid', 'dashed', 'dotted'].map((v) => (
            <button key={v} type="button" onClick={() => onStyle({ lineStyle: v })} className="flex w-full items-center rounded-lg px-2 py-1.5 hover:bg-white/10" style={{ color: v === s.lineStyle ? '#5b8cff' : T.text }}>
              <LineSample w={2} style={v} />
            </button>
          ))}
        </Pop>
      )}
      {c.textStyle && (
        <Pop label={tx('Розмір тексту', 'Font size')} value={<span className="text-[12px] tabular-nums">{s.fontSize}</span>}>
          {[10, 12, 14, 16, 20, 24, 28].map((v) => (
            <button key={v} type="button" onClick={() => onStyle({ fontSize: v })} className="block w-full rounded-lg px-3 py-1 text-left text-[12.5px] hover:bg-white/10" style={{ color: v === s.fontSize ? '#5b8cff' : T.text }}>{v}</button>
          ))}
        </Pop>
      )}
      <Sep />
      <button type="button" title={tx('Налаштування', 'Settings')} aria-label={tx('Налаштування', 'Settings')} onClick={onSettings} className="grid h-8 w-8 place-items-center rounded-md hover:bg-white/10" style={{ color: T.text2 }}><DrawIcon id="gear" size={22} /></button>
      <button type="button" title={d.locked ? tx('Розблокувати', 'Unlock') : tx('Заблокувати', 'Lock')} aria-label={tx('Замок', 'Lock')} onClick={() => onPatch({ locked: !d.locked })} className="grid h-8 w-8 place-items-center rounded-md hover:bg-white/10" style={{ color: d.locked ? '#5b8cff' : T.text2 }}><DrawIcon id={d.locked ? 'lock' : 'unlock'} size={22} /></button>
      <button type="button" title={tx('Копія', 'Clone')} aria-label={tx('Копія', 'Clone')} onClick={onClone} className="grid h-8 w-8 place-items-center rounded-md hover:bg-white/10" style={{ color: T.text2 }}><DrawIcon id="clone" size={22} /></button>
      <button type="button" title={tx('Видалити (Delete)', 'Remove (Delete)')} aria-label={tx('Видалити', 'Remove')} onClick={onDelete} className="grid h-8 w-8 place-items-center rounded-md transition-colors hover:bg-white/10 hover:text-[#f23645]" style={{ color: T.text2 }}><DrawIcon id="trash" size={22} /></button>
    </div>
  );
}
