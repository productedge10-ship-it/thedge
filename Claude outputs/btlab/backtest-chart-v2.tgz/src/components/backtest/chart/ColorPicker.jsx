import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Plus } from 'lucide-react';
import { T } from '../../../lib/theme';
import { t as tx } from '../../../lib/lang';
import { parseColor, toCss, toHex } from '../../../lib/candles/chartPrefs';

/* ==================================================================
   Вибір кольору як у TradingView: палітра, свій колір і прозорість.
   Звичайний <input type="color"> прозорості не вміє, а без неї сітка
   й водяний знак або кричать, або зникають.

   Віконце — через портал: модалка налаштувань прокручується, і
   звичайний absolute обрізався б її краєм.
================================================================== */

const PALETTE = [
  ['#ffffff', '#d1d4dc', '#b2b5be', '#9598a1', '#787b86', '#5d606b', '#434651', '#2a2e39', '#131722', '#000000'],
  ['#f23645', '#ff9800', '#ffeb3b', '#4caf50', '#089981', '#00bcd4', '#2962ff', '#673ab7', '#9c27b0', '#e91e63'],
  ['#fccbcd', '#ffe0b2', '#fff9c4', '#c8e6c9', '#ace5dc', '#b2ebf2', '#bbd9fb', '#d1c4e9', '#e1bee7', '#f8bbd0'],
  ['#faa1a4', '#ffcc80', '#fff59d', '#a5d6a7', '#70ccbd', '#80deea', '#90bff9', '#b39ddb', '#ce93d8', '#f48fb1'],
  ['#f7525f', '#ffb74d', '#fff176', '#81c784', '#42bda8', '#4dd0e1', '#5b9cf6', '#9575cd', '#ba68c8', '#f06292'],
  ['#b22833', '#f57c00', '#fbc02d', '#388e3c', '#056656', '#0097a7', '#1848cc', '#512da8', '#7b1fa2', '#c2185b'],
  ['#801922', '#e65100', '#f57f17', '#1b5e20', '#00332a', '#006064', '#0c3299', '#311b92', '#4a148c', '#880e4f'],
];

const CHECKER = 'repeating-conic-gradient(#808080 0% 25%, #c0c0c0 0% 50%) 50% / 8px 8px';

export function Swatch({ value, size = 28 }) {
  return (
    <span className="relative block overflow-hidden rounded-md" style={{ width: size, height: size, background: CHECKER, border: `1px solid ${T.lineHi}` }}>
      <span className="absolute inset-0" style={{ background: value }} />
    </span>
  );
}

export default function ColorPicker({ value, onChange, label, disabled }) {
  const [open, setOpen] = useState(false);
  const [at, setAt] = useState({ x: 0, y: 0 });
  const btn = useRef(null);
  const pop = useRef(null);
  const c = parseColor(value);

  useEffect(() => {
    if (!open) return undefined;
    const down = (e) => {
      if (pop.current?.contains(e.target) || btn.current?.contains(e.target)) return;
      setOpen(false);
    };
    const key = (e) => { if (e.key === 'Escape') { e.stopPropagation(); setOpen(false); } };
    window.addEventListener('mousedown', down);
    window.addEventListener('keydown', key, true);
    return () => { window.removeEventListener('mousedown', down); window.removeEventListener('keydown', key, true); };
  }, [open]);

  const toggle = () => {
    if (disabled) return;
    const r = btn.current.getBoundingClientRect();
    const W = 252; const H = 300;
    setAt({
      x: Math.max(8, Math.min(window.innerWidth - W - 8, r.left)),
      y: r.bottom + 6 + H > window.innerHeight ? Math.max(8, r.top - H - 6) : r.bottom + 6,
    });
    setOpen((v) => !v);
  };

  const pick = (hex) => onChange(toCss({ ...parseColor(hex), a: c.a }));

  return (
    <>
      <button
        ref={btn}
        type="button"
        onClick={toggle}
        aria-label={label}
        title={label}
        className="shrink-0 rounded-md transition-opacity"
        style={{ opacity: disabled ? 0.35 : 1, cursor: disabled ? 'default' : 'pointer' }}
      >
        <Swatch value={value} />
      </button>
      {open && createPortal(
        <div
          ref={pop}
          className="fixed z-[200] rounded-xl p-3"
          style={{ left: at.x, top: at.y, width: 252, background: T.surface3, border: `1px solid ${T.lineHi}`, boxShadow: '0 16px 40px rgba(0,0,0,0.5)' }}
          onMouseDown={(e) => e.stopPropagation()}
        >
          <div className="grid gap-[3px]" style={{ gridTemplateColumns: 'repeat(10, 1fr)' }}>
            {PALETTE.flat().map((hex) => {
              const on = toHex(c) === hex;
              return (
                <button
                  key={hex}
                  type="button"
                  onClick={() => pick(hex)}
                  className="aspect-square rounded-[4px] transition-transform hover:scale-110"
                  style={{ background: hex, outline: on ? '2px solid #2962ff' : 'none', outlineOffset: 1 }}
                  aria-label={hex}
                />
              );
            })}
          </div>
          <div className="mt-3 flex items-center gap-2">
            <label className="relative grid h-7 w-7 cursor-pointer place-items-center rounded-md" style={{ border: `1px dashed ${T.lineHi}`, color: T.text2 }} title={tx('Свій колір', 'Custom color')}>
              <Plus size={14} />
              <input type="color" value={toHex(c)} onChange={(e) => pick(e.target.value)} className="absolute inset-0 h-full w-full cursor-pointer opacity-0" />
            </label>
            <Swatch value={value} size={28} />
            <span className="ml-auto text-[12px] tabular-nums" style={{ fontFamily: T.mono, color: T.text3 }}>{toHex(c).toUpperCase()}</span>
          </div>
          <div className="mt-3">
            <div className="flex justify-between text-[11.5px]" style={{ color: T.text3 }}>
              <span>{tx('Непрозорість', 'Opacity')}</span>
              <span style={{ fontFamily: T.mono }}>{Math.round(c.a * 100)}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={Math.round(c.a * 100)}
              onChange={(e) => onChange(toCss({ ...c, a: Number(e.target.value) / 100 }))}
              className="mt-1.5 w-full accent-[#2962ff]"
            />
          </div>
        </div>,
        document.body,
      )}
    </>
  );
}
