import { createChart, CandlestickSeries, createSeriesMarkers, createTextWatermark, LineStyle } from 'lightweight-charts';
import { aggregate, tfById, tfIndexOfBase, barAt, atr, lowerBound, upperBound } from '../../../lib/candles/agg';
import { chartOptions, seriesOptions, withAlpha, DATA_KEYS } from '../../../lib/candles/chartPrefs';

/* ==================================================================
   Рушій графіка з реплеєм.

   Окремий клас, а не React-стан: на швидкості 0.1 с графік
   оновлюється десять разів на секунду, а позиція — на кожну хвилинку
   всередині кроку. Перемальовувати через React весь екран заради
   цього нема сенсу; сторінка отримує лише підсумки (ціна, позиція,
   закриті угоди) через колбеки.

   Позначення:
   • base   — свічки з файлу (зазвичай M1), лежать у масивах;
   • agg    — поточний таймфрейм, зібраний з base;
   • cut    — скільки base-свічок «вже сталося» (null — реплей вимкнено);
   • win    — з якої свічки agg почато дані графіка. Мільйон свічок
              у бібліотеку разом не віддаємо: стартуємо з останніх
              CHUNK і доклеюємо ліворуч, коли людина прокручує назад —
              так само, як TradingView довантажує історію.
================================================================== */

const CHUNK = 12000;
const CUT_MS = 420;
const easeOut = (t) => 1 - (1 - t) ** 3;

export default class ChartEngine {
  constructor(container, overlay, prefs, cb) {
    this.el = container;
    this.ov = overlay;
    this.cb = cb;
    this.prefs = prefs;
    this.base = null;
    this.agg = null;
    this.aggCache = new Map();
    this.tf = tfById(prefs.tf).id;
    this.cut = null;
    this.win = 0;
    this.lastK = -1;
    this.pos = null;
    this.closed = [];
    this.selecting = false;
    this.hoverLogical = null;
    this.hovering = false;
    this.playing = false;
    this.timer = null;
    this.speedMs = 1000;
    this.extending = false;
    this.anim = null;
    this.cutFx = null;

    this.chart = createChart(container, { ...chartOptions(prefs), autoSize: true });
    this.series = this.chart.addSeries(CandlestickSeries, seriesOptions(prefs, 2));
    this.markers = createSeriesMarkers(this.series, []);
    this.watermark = createTextWatermark(this.chart.panes()[0], { horzAlign: 'center', vertAlign: 'center', lines: [] });

    this.onRange = this.onRange.bind(this);
    this.onMove = this.onMove.bind(this);
    this.onClick = this.onClick.bind(this);
    this.chart.timeScale().subscribeVisibleLogicalRangeChange(this.onRange);
    this.chart.subscribeCrosshairMove(this.onMove);
    this.chart.subscribeClick(this.onClick);

    this.priceLines = {};
    this.auxLines = {};
    this.raf = requestAnimationFrame(() => this.loop());
  }

  destroy() {
    this.pause();
    cancelAnimationFrame(this.raf);
    this.chart.timeScale().unsubscribeVisibleLogicalRangeChange(this.onRange);
    this.chart.unsubscribeCrosshairMove(this.onMove);
    this.chart.unsubscribeClick(this.onClick);
    this.chart.remove();
  }

  /* ---------------- дані ---------------- */

  setData(set) {
    this.pause();
    this.anim = null;
    this.base = set;
    this.aggCache.clear();
    this.cut = null;
    this.pos = null;
    this.closed = [];
    this.clearPriceLines();
    this.series.applyOptions(seriesOptions(this.prefs, set.digits));
    this.useTf(this.tf, true);
    this.emit();
  }

  getAgg(id) {
    if (!this.aggCache.has(id)) this.aggCache.set(id, aggregate(this.base, tfById(id).sec));
    return this.aggCache.get(id);
  }

  useTf(id) {
    if (!this.base) { this.tf = id; return; }
    this.finishAnim();
    /* Таймфрейм дрібніший за файл не зібрати: з H1 не буде M5. */
    const want = tfById(id);
    const tf = want.sec < this.base.baseSec ? tfById('M1') : want;

    /* «Зберегти лівий край при зміні інтервалу» — як у TV: та сама
       дата лишається біля лівого краю, а не стрибаємо в кінець. */
    let leftT = null; let span = null;
    const r = this.agg ? this.chart.timeScale().getVisibleLogicalRange() : null;
    if (this.prefs.keepLeft && r && this.agg) {
      const k = Math.max(0, Math.min(this.lastK, this.win + Math.floor(r.from)));
      leftT = this.agg.t[k];
      span = r.to - r.from;
    }

    this.tf = tf.id;
    this.agg = this.getAgg(this.tf);
    this.lastK = this.cut == null ? this.agg.n - 1 : tfIndexOfBase(this.agg, this.cut - 1);
    this.win = Math.max(0, this.lastK + 1 - CHUNK);
    if (leftT != null) {
      const k = Math.max(0, upperBound(this.agg.t, leftT, 0, this.agg.n) - 1);
      if (k < this.win) this.win = Math.max(0, k - 500);
      this.render({ from: k - this.win, to: k - this.win + span });
    } else {
      this.render();
      this.chart.timeScale().scrollToPosition(this.prefs.rightOffset, false);
    }
    this.updateWatermark();
    this.updateMarkers();
    this.updateAux();
    this.emit();
  }

  /* Свічка k так, як її видно зараз (з урахуванням реплею й кольору
     «від попереднього закриття»). */
  bar(k, cut = this.cut) {
    const a = this.agg;
    const b = (cut == null || k < this.lastK)
      ? { time: a.t[k], open: a.o[k], high: a.h[k], low: a.l[k], close: a.c[k] }
      : barAt(a, this.base, k, cut);
    return this.paint(b, k);
  }

  paint(b, k) {
    const p = this.prefs;
    if (!p.prevCloseColor || k < 1) return b;
    const up = b.close >= this.agg.c[k - 1];
    return {
      ...b,
      color: p.body ? (up ? p.up : p.down) : 'rgba(0,0,0,0)',
      borderColor: up ? p.borderUp : p.borderDown,
      wickColor: up ? p.wickUp : p.wickDown,
    };
  }

  render(keep = null) {
    const out = new Array(Math.max(0, this.lastK - this.win + 1));
    for (let k = this.win; k <= this.lastK; k += 1) out[k - this.win] = this.bar(k);
    this.series.setData(out);
    if (keep) this.chart.timeScale().setVisibleLogicalRange(keep);
  }

  /* Доклеюємо історію ліворуч, коли до краю лишилось мало свічок. */
  onRange(r) {
    if (!r || !this.agg) return;
    if (this.prefs.hiLo) this.updateHiLo();
    if (this.extending || this.win === 0 || r.from > 400) return;
    this.extending = true;
    requestAnimationFrame(() => {
      const range = this.chart.timeScale().getVisibleLogicalRange();
      const add = Math.min(this.win, CHUNK);
      this.win -= add;
      this.render(range ? { from: range.from + add, to: range.to + add } : null);
      this.updateMarkers();
      this.extending = false;
    });
  }

  /* ---------------- вигляд ---------------- */

  applyPrefs(p) {
    const prev = this.prefs;
    this.prefs = p;
    this.chart.applyOptions(chartOptions(p));
    this.series.applyOptions(seriesOptions(p, this.base?.digits ?? 2));
    this.updateWatermark();
    if (!this.agg) return;
    if (DATA_KEYS.some((k) => prev[k] !== p[k]) && (p.prevCloseColor || prev.prevCloseColor)) {
      this.render(this.chart.timeScale().getVisibleLogicalRange());
    }
    if (prev.rightOffset !== p.rightOffset) this.chart.timeScale().scrollToPosition(p.rightOffset, false);
    this.syncPriceLines();
    this.updateMarkers();
    this.updateAux();
  }

  updateWatermark() {
    const p = this.prefs;
    const label = tfById(this.tf).label;
    this.watermark.applyOptions({
      visible: !!p.watermark && !!this.base,
      lines: this.base ? [{ text: `${this.base.symbol}, ${label}`, color: p.watermarkColor, fontSize: 64, fontStyle: '600' }] : [],
    });
  }

  resetView() {
    this.chart.priceScale('right').applyOptions({ autoScale: true });
    this.chart.timeScale().applyOptions({ barSpacing: 6 });
    this.chart.timeScale().scrollToPosition(this.prefs.rightOffset, false);
  }

  /* ---------------- курсор і легенда ---------------- */

  onMove(param) {
    this.hoverLogical = param?.logical ?? null;
    this.hovering = param?.time != null && param.logical != null;
    if (!this.agg || this.lastK < 0) return;
    let k = this.lastK;
    if (this.hovering) k = Math.max(0, Math.min(this.lastK, this.win + Math.round(param.logical)));
    const b = (this.anim && k === this.lastK && this.anim.shown) || this.bar(k);
    const prev = k > 0 ? this.agg.c[k - 1] : b.open;
    this.cb.onLegend?.(b, prev);
  }

  /* Без курсора над графіком легенда показує останню свічку — як у TV. */
  legendLast() {
    if (!this.hovering) this.onMove(null);
  }

  /* ---------------- реплей ---------------- */

  get replay() { return this.cut != null; }

  startSelect() {
    if (!this.base) return;
    this.pause();
    this.finishAnim();
    this.selecting = true;
    this.emit();
  }

  cancelSelect() {
    this.selecting = false;
    this.emit();
  }

  onClick(param) {
    if (!this.selecting || param?.logical == null) return;
    const rel = Math.round(param.logical);
    const k = Math.max(1, Math.min(this.lastK, this.win + rel));
    this.selecting = false;
    /* Обрана свічка — остання видима, як у TV. */
    const cut = this.agg.s[k + 1];
    if (!this.prefs.animCut) { this.setCut(cut, true); return; }
    /* «Ножиці»: шторка кольору фону насувається на майбутнє, і лише
       потім дані обрізаються. Вигляд не стрибає — свічки ліворуч
       лишаються на своїх місцях. */
    this.cutFx = { rel: k - this.win, t0: performance.now(), phase: 'wipe', cut };
    this.emit();
  }

  /* Старт реплею з дати: показано все ДО неї. */
  startAtTime(sec) {
    if (!this.base) return;
    const i = lowerBound(this.base.t, sec);
    this.selecting = false;
    this.setCut(Math.max(1, Math.min(this.base.n - 1, i)), false);
  }

  setCut(cut, keepView = false) {
    this.pause();
    this.finishAnim();
    if (this.pos) this.closePosition('manual');
    const r = keepView ? this.chart.timeScale().getVisibleLogicalRange() : null;
    const oldWin = this.win;
    this.cut = cut;
    this.lastK = tfIndexOfBase(this.agg, cut - 1);
    this.win = Math.max(0, this.lastK + 1 - CHUNK);
    if (r) {
      const d = oldWin - this.win;
      this.render({ from: r.from + d, to: r.to + d });
    } else {
      this.render();
      this.chart.timeScale().scrollToPosition(Math.max(20, this.prefs.rightOffset), false);
    }
    this.updateMarkers();
    this.updateAux();
    this.emit();
  }

  exitReplay() {
    this.pause();
    this.finishAnim();
    if (this.pos) this.closePosition('manual');
    this.selecting = false;
    this.cutFx = null;
    this.cut = null;
    this.clearPriceLines();
    this.useTf(this.tf);
  }

  /* Один крок = одна свічка поточного таймфрейму. Усередині кроку
     проходимо кожну базову свічку — інакше на H4 стоп і тейк в одній
     свічці вирішувались би навмання. */
  step(manual = false) {
    if (!this.replay) return false;
    this.finishAnim();
    if (this.cut >= this.base.n) { this.pause(); this.emit(); return false; }
    const k = tfIndexOfBase(this.agg, this.cut);
    const next = this.agg.s[k + 1];
    const from = this.cut;
    /* lastK і cut рухаємо одразу: наступний крок не має повторити цей. */
    this.cut = next;
    this.lastK = k;

    const dur = manual ? 260 : Math.min(700, this.speedMs * 0.7);
    if (!this.prefs.animCandles || dur < 90) {
      this.series.update(this.bar(k));
      this.settle(from, next);
      return true;
    }
    this.anim = { k, from, next, frames: this.framesFor(k, from, next), t0: performance.now(), dur, shown: null };
    return true;
  }

  /* Кадри появи свічки. Якщо всередині є кілька базових свічок (H1 з
     хвилинок) — це справжній шлях ціни: свічка росте так, як росла
     насправді. Якщо одна (M1) — шлях open → екстремум → екстремум →
     close, як тік-реплей у TV. */
  framesFor(k, from, next) {
    const frames = [];
    const n = next - from;
    if (n > 1) {
      const stepN = Math.max(1, Math.floor(n / 28));
      for (let j = from + 1; j <= next; j += stepN) frames.push(barAt(this.agg, this.base, k, j));
      frames.push(barAt(this.agg, this.base, k, next));
      return frames;
    }
    const fin = barAt(this.agg, this.base, k, next);
    const prevPart = k === tfIndexOfBase(this.agg, from - 1) && from > this.agg.s[k] ? barAt(this.agg, this.base, k, from) : null;
    const o = prevPart ? prevPart.close : fin.open;
    const path = fin.close >= fin.open ? [o, fin.low, fin.high, fin.close] : [o, fin.high, fin.low, fin.close];
    let hi = prevPart ? prevPart.high : o; let lo = prevPart ? prevPart.low : o;
    const SEG = 7;
    for (let s = 0; s < path.length - 1; s += 1) {
      for (let q = 1; q <= SEG; q += 1) {
        const px = path[s] + (path[s + 1] - path[s]) * (q / SEG);
        hi = Math.max(hi, px); lo = Math.min(lo, px);
        frames.push({ time: fin.time, open: fin.open, high: hi, low: lo, close: px });
      }
    }
    frames.push(fin);
    return frames;
  }

  tickAnim(now) {
    const a = this.anim;
    if (!a) return;
    const t = Math.min(1, (now - a.t0) / a.dur);
    const idx = Math.min(a.frames.length - 1, Math.floor(t * a.frames.length));
    const f = this.paint(a.frames[idx], a.k);
    if (f !== a.shown) { this.series.update(f); a.shown = f; this.legendLast(); }
    if (t >= 1) this.finishAnim();
  }

  finishAnim() {
    const a = this.anim;
    if (!a) return;
    this.anim = null;
    this.series.update(this.bar(a.k));
    this.settle(a.from, a.next);
  }

  /* Свічка домальована — тепер перевіряємо позицію. Так вихід по
     стопу не зʼявляється раніше, ніж ціна до нього «дійшла» на екрані. */
  settle(from, next) {
    const had = this.closed.length;
    for (let i = from; i < next && this.pos; i += 1) this.checkPos(i);
    if (this.pos) this.pos.bars += 1;
    if (this.closed.length !== had) this.updateMarkers();
    this.updateAux();
    this.emit();
  }

  play(ms) {
    if (ms) this.speedMs = ms;
    if (!this.replay) return;
    this.pause();
    this.playing = true;
    this.timer = setInterval(() => { if (!this.step()) this.pause(); }, this.speedMs);
    this.emit();
  }

  setSpeed(ms) {
    this.speedMs = ms;
    if (this.playing) this.play(ms);
  }

  pause() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    if (this.playing) { this.playing = false; this.emit(); }
  }

  /* ---------------- позиція ---------------- */

  price() {
    if (!this.base) return 0;
    const i = this.replay ? this.cut - 1 : this.base.n - 1;
    return this.base.c[i];
  }

  defaultDistance() {
    const d = atr(this.agg, this.base, this.lastK, this.cut ?? this.base.n);
    return d > 0 ? d : this.price() * 0.002;
  }

  openPosition(side, { rr = 2 } = {}) {
    if (!this.replay || this.pos) return;
    this.finishAnim();
    const entry = this.price();
    const d = this.defaultDistance() * (this.prefs.atrMult || 1);
    const dir = side === 'LONG' ? 1 : -1;
    this.pos = {
      side, entry, sl: entry - dir * d, sl0: entry - dir * d, tp: entry + dir * d * rr,
      entryIdx: this.cut - 1, entryT: this.base.t[this.cut - 1], bars: 0, tf: this.tf,
    };
    this.syncPriceLines();
    this.updateMarkers();
    this.emit();
  }

  setLevels({ sl, tp }) {
    const p = this.pos;
    if (!p) return;
    this.finishAnim();
    const now = this.price();
    const long = p.side === 'LONG';
    /* Мінімальна відстань рівня від ціни: тік або 5% ATR. Без неї стоп,
       притягнутий упритул до входу, давав ризик у мільйонну частку
       пункту — і угода в «−90 000 000R». */
    const tick = 1 / 10 ** (this.base?.digits ?? 2);
    const gap = Math.max(tick * 2, this.defaultDistance() * 0.05);
    if (sl != null && Number.isFinite(sl)) {
      /* Стоп не може стояти по той бік ціни — він спрацював би одразу. */
      p.sl = long ? Math.min(sl, now - gap) : Math.max(sl, now + gap);
      /* Поки не пройшло жодної свічки — це ще планування, і ризик
         угоди рахуємо від нового стопа. Потім стоп можна підтягувати,
         а R лишається від початкового. */
      if (p.bars === 0) p.sl0 = p.sl;
    }
    if (tp != null && Number.isFinite(tp)) p.tp = long ? Math.max(tp, now + gap) : Math.min(tp, now - gap);
    this.syncPriceLines();
    this.emit();
  }

  moveToBE() {
    if (!this.pos) return;
    this.finishAnim();
    const now = this.price();
    const p = this.pos;
    if ((p.side === 'LONG' && now <= p.entry) || (p.side === 'SHORT' && now >= p.entry)) return;
    p.sl = p.entry;
    this.syncPriceLines();
    this.emit();
  }

  rOf(p, price) {
    const risk = Math.abs(p.entry - p.sl0) || 1e-9;
    return (p.side === 'LONG' ? price - p.entry : p.entry - price) / risk;
  }

  checkPos(i) {
    const p = this.pos;
    if (!p || i <= p.entryIdx) return;
    const b = this.base;
    const long = p.side === 'LONG';
    const o = b.o[i];
    const hitSL = long ? b.l[i] <= p.sl : b.h[i] >= p.sl;
    const hitTP = long ? b.h[i] >= p.tp : b.l[i] <= p.tp;
    if (!hitSL && !hitTP) return;
    /* Гепом відкрились за рівнем — виходимо по відкриттю, як і в
       реальності. Обидва рівні в одній хвилинці — вважаємо, що першим
       був стоп: краще недооцінити систему, ніж перехвалити. */
    let reason; let px;
    if (long ? o <= p.sl : o >= p.sl) { reason = 'sl'; px = o; }
    else if (long ? o >= p.tp : o <= p.tp) { reason = 'tp'; px = o; }
    else if (hitSL) { reason = 'sl'; px = p.sl; }
    else { reason = 'tp'; px = p.tp; }
    this.finish(reason, px, i);
  }

  closePosition(reason = 'manual') {
    if (!this.pos) return;
    this.finishAnim();
    if (!this.pos) return;
    this.finish(reason, this.price(), this.cut - 1);
  }

  finish(reason, px, idx) {
    const p = this.pos;
    const r = this.rOf(p, px);
    const result = Math.abs(r) < 0.05 ? 'BE' : r > 0 ? 'WIN' : 'LOSS';
    const trade = {
      id: `c${Date.now()}${Math.random().toString(36).slice(2, 6)}`,
      symbol: this.base.symbol, side: p.side, tf: p.tf,
      entry: p.entry, sl: p.sl0, slFinal: p.sl, tp: p.tp, exit: px,
      entryIdx: p.entryIdx, exitIdx: idx, entryT: p.entryT, exitT: this.base.t[idx],
      r: Math.round(r * 100) / 100, result, reason, digits: this.base.digits,
    };
    this.pos = null;
    this.closed.push(trade);
    this.syncPriceLines();
    this.updateMarkers();
    this.cb.onClosed?.(trade);
    this.emit();
  }

  /* ---------------- лінії й маркери ---------------- */

  clearPriceLines() {
    Object.values(this.priceLines).forEach((l) => { try { this.series.removePriceLine(l); } catch { /* вже немає */ } });
    this.priceLines = {};
  }

  syncPriceLines() {
    const p = this.pos;
    if (!p || !this.prefs.showPositions) { this.clearPriceLines(); return; }
    const txt = this.prefs.markerText;
    const want = {
      entry: { price: p.entry, color: '#787b86', title: txt ? (p.side === 'LONG' ? 'Long' : 'Short') : '', lineStyle: LineStyle.Dashed },
      sl: { price: p.sl, color: '#f23645', title: txt ? 'SL' : '', lineStyle: LineStyle.Solid },
      tp: { price: p.tp, color: '#089981', title: txt ? 'TP' : '', lineStyle: LineStyle.Solid },
    };
    Object.entries(want).forEach(([key, o]) => {
      const opts = { price: o.price, color: o.color, lineWidth: 1, lineStyle: o.lineStyle, axisLabelVisible: true, title: o.title };
      if (this.priceLines[key]) this.priceLines[key].applyOptions(opts);
      else this.priceLines[key] = this.series.createPriceLine(opts);
    });
  }

  /* Допоміжні лінії з «Шкали і лінії»: закриття попереднього дня,
     максимум і мінімум видимої ділянки. */
  setAux(key, price, opts) {
    if (price == null) {
      if (this.auxLines[key]) { try { this.series.removePriceLine(this.auxLines[key]); } catch { /* ок */ } delete this.auxLines[key]; }
      return;
    }
    const o = { price, lineWidth: 1, axisLabelVisible: true, ...opts };
    if (this.auxLines[key]) this.auxLines[key].applyOptions(o);
    else this.auxLines[key] = this.series.createPriceLine(o);
  }

  updateAux() {
    if (!this.agg || this.lastK < 0) return;
    const p = this.prefs;
    if (p.prevDayClose) {
      const d1 = this.getAgg('D1');
      const lastBase = (this.cut ?? this.base.n) - 1;
      const dk = tfIndexOfBase(d1, lastBase);
      this.setAux('pdc', dk > 0 ? d1.c[dk - 1] : null, { color: '#787b86', lineStyle: LineStyle.Dotted, title: p.markerText ? 'PDC' : '' });
    } else this.setAux('pdc', null);
    this.updateHiLo();
  }

  updateHiLo() {
    if (!this.prefs.hiLo || !this.agg) { this.setAux('hi', null); this.setAux('lo', null); return; }
    const r = this.chart.timeScale().getVisibleLogicalRange();
    if (!r) return;
    const a = Math.max(this.win, this.win + Math.floor(r.from));
    const b = Math.min(this.lastK, this.win + Math.ceil(r.to));
    let hi = -Infinity; let lo = Infinity;
    for (let k = a; k <= b; k += 1) {
      /* Свічка, що зараз «росте», — лише те, що вже показано. */
      const bar = k === this.lastK ? ((this.anim && this.anim.shown) || this.bar(k)) : null;
      const h = bar ? bar.high : this.agg.h[k];
      const l = bar ? bar.low : this.agg.l[k];
      if (h > hi) hi = h;
      if (l < lo) lo = l;
    }
    if (!Number.isFinite(hi)) return;
    const txt = this.prefs.markerText;
    this.setAux('hi', hi, { color: withAlpha(this.prefs.up, 0.8), lineStyle: LineStyle.Dashed, title: txt ? 'High' : '' });
    this.setAux('lo', lo, { color: withAlpha(this.prefs.down, 0.8), lineStyle: LineStyle.Dashed, title: txt ? 'Low' : '' });
  }

  timeOfBase(i) {
    const k = tfIndexOfBase(this.agg, i);
    return k >= this.win && k <= this.lastK ? this.agg.t[k] : null;
  }

  updateMarkers() {
    if (!this.agg) return;
    const m = [];
    const txt = this.prefs.markerText;
    const add = (i, side, isEntry, text) => {
      const time = this.timeOfBase(i);
      if (time == null) return;
      const long = side === 'LONG';
      if (isEntry) {
        m.push({ time, position: long ? 'belowBar' : 'aboveBar', shape: long ? 'arrowUp' : 'arrowDown', color: long ? '#2962ff' : '#e91e63', text: txt ? text : '' });
      } else {
        m.push({ time, position: long ? 'aboveBar' : 'belowBar', shape: 'circle', color: '#9598a1', size: 0.6, text: txt ? text : '' });
      }
    };
    if (this.prefs.showClosed) {
      this.closed.forEach((t) => {
        add(t.entryIdx, t.side, true, t.side === 'LONG' ? 'Buy' : 'Sell');
        add(t.exitIdx, t.side, false, `${t.r > 0 ? '+' : ''}${t.r.toFixed(2)}R`);
      });
    }
    if (this.pos && this.prefs.showPositions) add(this.pos.entryIdx, this.pos.side, true, this.pos.side === 'LONG' ? 'Buy' : 'Sell');
    m.sort((a, b) => a.time - b.time);
    this.markers.setMarkers(m);
  }

  /* ---------------- оверлей (зони позиції, ножиці) ---------------- */

  xOfBase(i) {
    const k = tfIndexOfBase(this.agg, i);
    return this.chart.timeScale().logicalToCoordinate(k - this.win);
  }

  loop() {
    this.raf = requestAnimationFrame(() => this.loop());
    if (!this.ov || !this.agg) return;
    const now = performance.now();
    this.tickAnim(now);

    const ts = this.chart.timeScale();
    const plotW = ts.width();
    const plotH = this.chart.paneSize(0).height;
    const p = this.prefs;
    const parts = [];

    const zone = (x1, x2, yA, yB, color) => {
      const x = Math.max(0, Math.min(x1, x2)); const w = Math.min(plotW, Math.max(x1, x2)) - x;
      if (w <= 0) return;
      const y = Math.min(yA, yB); const h = Math.abs(yA - yB);
      parts.push(`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${color}"/>`);
    };

    /* Закриті угоди — бліді коробки від входу до виходу, як позиції в TV. */
    if (p.showClosed) {
      for (const t of this.closed) {
        const x1 = this.xOfBase(t.entryIdx); const x2 = this.xOfBase(t.exitIdx);
        if (x1 == null || x2 == null || (x1 > plotW && x2 > plotW) || (x1 < 0 && x2 < 0)) continue;
        const ye = this.series.priceToCoordinate(t.entry);
        const ys = this.series.priceToCoordinate(t.sl);
        const yt = this.series.priceToCoordinate(t.tp);
        const yx = this.series.priceToCoordinate(t.exit);
        if (ye == null) continue;
        const xx2 = Math.max(x2, x1 + 6);
        if (yt != null) zone(x1, xx2, ye, yt, 'rgba(8,153,129,0.13)');
        if (ys != null) zone(x1, xx2, ye, ys, 'rgba(242,54,69,0.13)');
        if (yx != null) parts.push(`<line x1="${x1}" y1="${ye}" x2="${xx2}" y2="${yx}" stroke="${t.r >= 0 ? '#089981' : '#f23645'}" stroke-width="1" stroke-dasharray="3 3"/>`);
      }
    }

    /* Відкрита позиція — від входу до правого краю. */
    const pos = this.pos;
    if (pos && p.showPositions) {
      const x1 = this.xOfBase(pos.entryIdx);
      const ye = this.series.priceToCoordinate(pos.entry);
      const ys = this.series.priceToCoordinate(pos.sl);
      const yt = this.series.priceToCoordinate(pos.tp);
      if (x1 != null && ye != null) {
        if (yt != null) zone(x1, plotW, ye, yt, 'rgba(8,153,129,0.2)');
        if (ys != null) zone(x1, plotW, ye, ys, 'rgba(242,54,69,0.2)');
      }
    }

    /* Ножиці: вертикаль під курсором і затемнення «майбутнього». */
    if (this.selecting && this.hoverLogical != null) {
      const x = ts.logicalToCoordinate(Math.round(this.hoverLogical));
      if (x != null) {
        parts.push(`<rect x="${x}" y="0" width="${Math.max(0, plotW - x)}" height="${plotH}" fill="${withAlpha(p.bg, 0.72)}"/>`);
        parts.push(`<line x1="${x}" y1="0" x2="${x}" y2="${plotH}" stroke="#2962ff" stroke-width="1.5"/>`);
      }
    }

    /* Анімація розрізу: шторка насувається зліва направо, потім дані
       обрізаються, і лінія розрізу гасне. */
    const fx = this.cutFx;
    if (fx) {
      const x = ts.logicalToCoordinate(fx.rel) ?? 0;
      const xr = x + (ts.logicalToCoordinate(fx.rel + 1) - x || 6) / 2;
      const t = (now - fx.t0) / CUT_MS;
      if (fx.phase === 'wipe') {
        const e = easeOut(Math.min(1, t));
        const w = Math.max(0, plotW - xr) * e;
        parts.push(`<rect x="${xr}" y="0" width="${w}" height="${plotH}" fill="${p.bg}"/>`);
        parts.push(`<rect x="${xr + w - 2}" y="0" width="2" height="${plotH}" fill="rgba(41,98,255,${0.9 * (1 - e) + 0.1})"/>`);
        parts.push(`<line x1="${xr}" y1="0" x2="${xr}" y2="${plotH}" stroke="#2962ff" stroke-width="2"/>`);
        if (t >= 1) {
          this.setCut(fx.cut, true);
          this.cutFx = { ...fx, phase: 'fade', t0: now };
          this.emit();
        }
      } else {
        const a = 1 - Math.min(1, t * 1.4);
        if (a <= 0) this.cutFx = null;
        else parts.push(`<line x1="${xr}" y1="0" x2="${xr}" y2="${plotH}" stroke="rgba(41,98,255,${a})" stroke-width="2"/>`);
      }
    }

    const html = parts.join('');
    if (html !== this.lastOv) { this.ov.innerHTML = html; this.lastOv = html; }
    this.cb.onFrame?.();
  }

  /* Координата ціни — для ручок SL/TP, які малює сторінка. */
  y(price) { return this.series.priceToCoordinate(price); }
  priceAt(y) { return this.series.coordinateToPrice(y); }

  /* ---------------- стан для сторінки ---------------- */

  emit() {
    if (this.agg && this.lastK >= 0) this.legendLast();
    const p = this.pos;
    const now = this.price();
    this.cb.onState?.({
      ready: !!this.base,
      tf: this.tf,
      replay: this.replay,
      selecting: this.selecting,
      cutting: !!this.cutFx && this.cutFx.phase === 'wipe',
      playing: this.playing,
      atEnd: this.replay && this.cut >= this.base.n,
      time: this.base ? this.base.t[(this.replay ? this.cut : this.base.n) - 1] : null,
      price: now,
      pos: p ? { ...p, r: this.rOf(p, now), rr: Math.abs(p.tp - p.entry) / (Math.abs(p.entry - p.sl0) || 1e-9) } : null,
    });
  }
}
