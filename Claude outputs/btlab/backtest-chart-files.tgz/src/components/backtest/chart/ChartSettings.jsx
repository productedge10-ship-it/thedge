import { useEffect, useState } from 'react';
import { X } from 'lucide-react';
import { T } from '../../../lib/theme';
import { t as tx } from '../../../lib/lang';
import { act, ACT } from '../accent';
import { PRESETS } from '../../../lib/candles/chartPrefs';

/* ==================================================================
   Налаштування графіка — дві вкладки, як у TradingView: «Символ»
   (свічки) і «Полотно» (фон, сітка, шкали). Зміни застосовуються
   одразу, без кнопки «Зберегти»: людина бачить результат під модалкою
   і крутить, поки не сподобається.
================================================================== */

function ColorRow({ label, value, onChange, on, onToggle }) {
  return (
    <div className="flex items-center justify-between gap-3 py-2">
      <label className="flex min-w-0 items-center gap-2.5 text-[13.5px]" style={{ color: on === false ? T.text3 : T.text }}>
        {onToggle && (
          <input type="checkbox" checked={!!on} onChange={(e) => onToggle(e.target.checked)} className="h-4 w-4 accent-[#5b4dff]" />
        )}
        <span className="truncate">{label}</span>
      </label>
      <span className="relative h-7 w-10 shrink-0 overflow-hidden rounded-md" style={{ border: `1px solid ${T.lineHi}`, opacity: on === false ? 0.4 : 1 }}>
        <span className="absolute inset-0" style={{ background: value }} />
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="absolute inset-0 h-full w-full cursor-pointer opacity-0"
          aria-label={label}
        />
      </span>
    </div>
  );
}

function PairRow({ label, up, down, onUp, onDown, on, onToggle }) {
  return (
    <div className="flex items-center justify-between gap-3 py-2">
      <label className="flex min-w-0 items-center gap-2.5 text-[13.5px]" style={{ color: on === false ? T.text3 : T.text }}>
        {onToggle && <input type="checkbox" checked={!!on} onChange={(e) => onToggle(e.target.checked)} className="h-4 w-4 accent-[#5b4dff]" />}
        <span className="truncate">{label}</span>
      </label>
      <span className="flex gap-1.5" style={{ opacity: on === false ? 0.4 : 1 }}>
        {[[up, onUp, '↑'], [down, onDown, '↓']].map(([v, fn, a]) => (
          <span key={a} className="relative h-7 w-10 overflow-hidden rounded-md" style={{ border: `1px solid ${T.lineHi}` }}>
            <span className="absolute inset-0" style={{ background: v }} />
            <input type="color" value={v} onChange={(e) => fn(e.target.value)} className="absolute inset-0 h-full w-full cursor-pointer opacity-0" aria-label={`${label} ${a}`} />
          </span>
        ))}
      </span>
    </div>
  );
}

export default function ChartSettings({ prefs, onChange, onClose }) {
  const [tab, setTab] = useState('symbol');
  const set = (patch) => onChange({ ...prefs, ...patch });

  useEffect(() => {
    const k = (e) => { if (e.key === 'Escape') onClose(); };
    window.addEventListener('keydown', k);
    return () => window.removeEventListener('keydown', k);
  }, [onClose]);

  const presets = [
    ['tvDark', tx('TradingView темна', 'TradingView dark')],
    ['tvLight', tx('TradingView світла', 'TradingView light')],
    ['edge', 'THE EDGE'],
  ];

  return (
    <div className="fixed inset-0 z-[80] grid place-items-center p-4" style={{ background: 'rgba(0,0,0,0.45)' }} onMouseDown={onClose}>
      <div
        className="w-full max-w-[420px] overflow-hidden rounded-2xl"
        style={{ background: T.surface, border: `1px solid ${T.line}`, boxShadow: '0 24px 60px rgba(0,0,0,0.5)' }}
        onMouseDown={(e) => e.stopPropagation()}
        role="dialog"
        aria-label={tx('Налаштування графіка', 'Chart settings')}
      >
        <div className="flex items-center justify-between px-5 pb-2 pt-4">
          <h3 className="text-[16px] font-bold" style={{ color: T.text }}>{tx('Налаштування графіка', 'Chart settings')}</h3>
          <button type="button" onClick={onClose} className="grid h-8 w-8 place-items-center rounded-lg transition-colors hover:bg-white/5" style={{ color: T.text3 }} aria-label={tx('Закрити', 'Close')}>
            <X size={17} />
          </button>
        </div>

        <div className="px-5">
          <div className="flex flex-wrap gap-1.5">
            {presets.map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => set(PRESETS[id])}
                className="flex items-center gap-2 rounded-lg px-2.5 py-1.5 text-[12.5px] font-semibold transition-colors"
                style={{ background: T.sunken, border: `1px solid ${T.line}`, color: T.text2 }}
              >
                <span className="h-3.5 w-3.5 rounded-sm" style={{ background: PRESETS[id].bg, border: `1px solid ${T.lineHi}` }} />
                {label}
              </button>
            ))}
          </div>

          <div className="mt-4 flex gap-1 rounded-[10px] p-1" style={{ background: T.sunken }}>
            {[['symbol', tx('Символ', 'Symbol')], ['canvas', tx('Полотно', 'Canvas')]].map(([id, label]) => (
              <button
                key={id}
                type="button"
                onClick={() => setTab(id)}
                className="flex-1 rounded-lg px-3 py-1.5 text-[13px] font-semibold transition-colors"
                style={{ background: tab === id ? act(0.9) : 'transparent', color: tab === id ? '#fff' : T.text2 }}
              >
                {label}
              </button>
            ))}
          </div>
        </div>

        <div className="max-h-[60vh] overflow-y-auto px-5 pb-5 pt-2">
          {tab === 'symbol' ? (
            <>
              <PairRow label={tx('Тіло', 'Body')} up={prefs.up} down={prefs.down} onUp={(v) => set({ up: v })} onDown={(v) => set({ down: v })} />
              <PairRow
                label={tx('Рамки', 'Borders')}
                up={prefs.borderUp} down={prefs.borderDown}
                onUp={(v) => set({ borderUp: v })} onDown={(v) => set({ borderDown: v })}
                on={prefs.border} onToggle={(v) => set({ border: v })}
              />
              <PairRow label={tx('Ґноти', 'Wicks')} up={prefs.wickUp} down={prefs.wickDown} onUp={(v) => set({ wickUp: v })} onDown={(v) => set({ wickDown: v })} />
              <button
                type="button"
                onClick={() => set({ borderUp: prefs.up, wickUp: prefs.up, borderDown: prefs.down, wickDown: prefs.down })}
                className="mt-2 text-[12.5px] font-semibold"
                style={{ color: ACT.tint }}
              >
                {tx('Рамки й ґноти — як тіло', 'Borders & wicks = body')}
              </button>
            </>
          ) : (
            <>
              <ColorRow label={tx('Фон', 'Background')} value={prefs.bg} onChange={(v) => set({ bg: v })} />
              <ColorRow label={tx('Вертикальна сітка', 'Vert grid lines')} value={prefs.grid} onChange={(v) => set({ grid: v })} on={prefs.gridV} onToggle={(v) => set({ gridV: v })} />
              <ColorRow label={tx('Горизонтальна сітка', 'Horz grid lines')} value={prefs.grid} onChange={(v) => set({ grid: v })} on={prefs.gridH} onToggle={(v) => set({ gridH: v })} />
              <ColorRow label={tx('Текст шкал', 'Scale text')} value={prefs.text} onChange={(v) => set({ text: v })} />
              <ColorRow label={tx('Лінії шкал', 'Scale lines')} value={prefs.scaleLine} onChange={(v) => set({ scaleLine: v })} />
              <label className="flex items-center gap-2.5 py-2 text-[13.5px]" style={{ color: T.text }}>
                <input type="checkbox" checked={!!prefs.watermark} onChange={(e) => set({ watermark: e.target.checked })} className="h-4 w-4 accent-[#5b4dff]" />
                {tx('Водяний знак символу', 'Symbol watermark')}
              </label>
              <div className="flex items-center justify-between py-2 text-[13.5px]" style={{ color: T.text }}>
                <span>{tx('Перехрестя', 'Crosshair')}</span>
                <select
                  value={prefs.crosshair}
                  onChange={(e) => set({ crosshair: e.target.value })}
                  className="rounded-lg px-2 py-1.5 text-[13px] outline-none"
                  style={{ background: T.sunken, border: `1px solid ${T.line}`, color: T.text }}
                >
                  <option value="normal">{tx('Вільне', 'Normal')}</option>
                  <option value="magnet">{tx('Магніт до OHLC', 'Magnet to OHLC')}</option>
                </select>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
