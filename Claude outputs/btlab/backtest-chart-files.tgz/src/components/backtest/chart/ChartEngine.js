import { createChart, CandlestickSeries, createSeriesMarkers, createTextWatermark } from 'lightweight-charts';
import { aggregate, tfById, tfIndexOfBase, barAt, atr, lowerBound } from '../../../lib/candles/agg';
import { chartOptions, seriesOptions, isLight } from '../../../lib/candles/chartPrefs';

/* ==================================================================
   Рушій графіка з реплеєм.

   Окремий клас, а не React-стан: на швидкості 0.1 с графік
   оновлюється десять разів на секунду, а позиція — на кожну хвилинку
   всередині кроку. Перемальовувати через React весь екран заради
   цього нема сенсу; сторінка отримує лише підсумки (ціна, позиція,
   закриті угоди) через колбеки.

   Позначення:
   • base   — свічки з файлу (зазвичай M1), лежать у масивах;
   • agg    — поточний таймфрейм, зібраний з base;
   • cut    — скільки base-свічок «вже сталося» (null — реплей вимкнено);
   • win    — з якої свічки agg почато дані графіка. Мільйон свічок
              у бібліотеку разом не віддаємо: стартуємо з останніх
              CHUNK і доклеюємо ліворуч, коли людина прокручує назад —
              так само, як TradingView довантажує історію.
================================================================== */

const CHUNK = 12000;

const rgba = (hex, a) => {
  const m = /^#?([0-9a-f]{6})$/i.exec(hex || '');
  if (!m) return `rgba(128,128,128,${a})`;
  const n = parseInt(m[1], 16);
  return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`;
};

export default class ChartEngine {
  constructor(container, overlay, prefs, cb) {
    this.el = container;
    this.ov = overlay;
    this.cb = cb;
    this.prefs = prefs;
    this.base = null;
    this.agg = null;
    this.aggCache = new Map();
    this.tf = tfById(prefs.tf).id;
    this.cut = null;
    this.win = 0;
    this.lastK = -1;
    this.pos = null;
    this.closed = [];
    this.selecting = false;
    this.hoverLogical = null;
    this.playing = false;
    this.timer = null;
    this.speedMs = 1000;
    this.extending = false;

    this.chart = createChart(container, { ...chartOptions(prefs), autoSize: true });
    this.series = this.chart.addSeries(CandlestickSeries, seriesOptions(prefs, 2));
    this.markers = createSeriesMarkers(this.series, []);
    this.watermark = createTextWatermark(this.chart.panes()[0], { horzAlign: 'center', vertAlign: 'center', lines: [] });

    this.onRange = this.onRange.bind(this);
    this.onMove = this.onMove.bind(this);
    this.onClick = this.onClick.bind(this);
    this.chart.timeScale().subscribeVisibleLogicalRangeChange(this.onRange);
    this.chart.subscribeCrosshairMove(this.onMove);
    this.chart.subscribeClick(this.onClick);

    this.priceLines = {};
    this.raf = requestAnimationFrame(() => this.loop());
  }

  destroy() {
    this.pause();
    cancelAnimationFrame(this.raf);
    this.chart.timeScale().unsubscribeVisibleLogicalRangeChange(this.onRange);
    this.chart.unsubscribeCrosshairMove(this.onMove);
    this.chart.unsubscribeClick(this.onClick);
    this.chart.remove();
  }

  /* ---------------- дані ---------------- */

  setData(set) {
    this.pause();
    this.base = set;
    this.aggCache.clear();
    this.cut = null;
    this.pos = null;
    this.closed = [];
    this.clearPriceLines();
    this.series.applyOptions(seriesOptions(this.prefs, set.digits));
    this.useTf(this.tf, true);
    this.emit();
  }

  getAgg(id) {
    if (!this.aggCache.has(id)) this.aggCache.set(id, aggregate(this.base, tfById(id).sec));
    return this.aggCache.get(id);
  }

  useTf(id, fresh = false) {
    if (!this.base) { this.tf = id; return; }
    /* Таймфрейм дрібніший за файл не зібрати: з H1 не буде M5. */
    const want = tfById(id);
    const tf = want.sec < this.base.baseSec ? tfById('M1') : want;
    this.tf = tf.id;
    this.agg = this.getAgg(this.tf);
    this.lastK = this.cut == null ? this.agg.n - 1 : tfIndexOfBase(this.agg, this.cut - 1);
    this.win = Math.max(0, this.lastK + 1 - CHUNK);
    this.render();
    if (fresh) this.chart.timeScale().scrollToPosition(12, false);
    else this.chart.timeScale().scrollToPosition(12, false);
    this.updateWatermark();
    this.updateMarkers();
    this.emit();
  }

  bar(k) {
    const a = this.agg;
    if (this.cut == null || k < this.lastK) return { time: a.t[k], open: a.o[k], high: a.h[k], low: a.l[k], close: a.c[k] };
    return barAt(a, this.base, k, this.cut);
  }

  render(keep = null) {
    const out = new Array(Math.max(0, this.lastK - this.win + 1));
    for (let k = this.win; k <= this.lastK; k += 1) out[k - this.win] = this.bar(k);
    this.series.setData(out);
    if (keep) this.chart.timeScale().setVisibleLogicalRange(keep);
  }

  /* Доклеюємо історію ліворуч, коли до краю лишилось мало свічок. */
  onRange(r) {
    if (!r || !this.agg || this.extending || this.win === 0) return;
    if (r.from > 400) return;
    this.extending = true;
    requestAnimationFrame(() => {
      const range = this.chart.timeScale().getVisibleLogicalRange();
      const add = Math.min(this.win, CHUNK);
      this.win -= add;
      this.render(range ? { from: range.from + add, to: range.to + add } : null);
      this.updateMarkers();
      this.extending = false;
    });
  }

  /* ---------------- вигляд ---------------- */

  applyPrefs(p) {
    this.prefs = p;
    this.chart.applyOptions(chartOptions(p));
    this.series.applyOptions(seriesOptions(p, this.base?.digits ?? 2));
    this.updateWatermark();
  }

  updateWatermark() {
    const p = this.prefs;
    const label = tfById(this.tf).label;
    this.watermark.applyOptions({
      visible: !!p.watermark && !!this.base,
      lines: this.base ? [{ text: `${this.base.symbol}, ${label}`, color: isLight(p.bg) ? 'rgba(19,23,34,0.07)' : 'rgba(178,181,190,0.08)', fontSize: 64, fontStyle: '600' }] : [],
    });
  }

  resetView() {
    this.chart.priceScale('right').applyOptions({ autoScale: true });
    this.chart.timeScale().applyOptions({ barSpacing: 7 });
    this.chart.timeScale().scrollToPosition(12, false);
  }

  /* ---------------- курсор і легенда ---------------- */

  onMove(param) {
    this.hoverLogical = param?.logical ?? null;
    this.hovering = param?.time != null && param.logical != null;
    if (!this.agg) return;
    let k = this.lastK;
    if (this.hovering) k = Math.min(this.lastK, this.win + Math.round(param.logical));
    if (k < 0) return;
    const b = this.bar(k);
    const prev = k > 0 ? this.agg.c[k - 1] : b.open;
    this.cb.onLegend?.(b, prev);
  }

  /* Без курсора над графіком легенда показує останню свічку — як у TV. */
  legendLast() {
    if (!this.hovering) this.onMove(null);
  }

  /* ---------------- реплей ---------------- */

  get replay() { return this.cut != null; }

  startSelect() {
    if (!this.base) return;
    this.pause();
    this.selecting = true;
    this.emit();
  }

  cancelSelect() {
    this.selecting = false;
    this.emit();
  }

  onClick(param) {
    if (!this.selecting || param?.logical == null) return;
    const k = Math.max(1, Math.min(this.lastK, this.win + Math.round(param.logical)));
    this.selecting = false;
    /* Обрана свічка — остання видима, як у TV. */
    this.setCut(this.agg.s[k + 1]);
  }

  /* Старт реплею з дати: показано все ДО неї. */
  startAtTime(sec) {
    if (!this.base) return;
    const i = lowerBound(this.base.t, sec);
    this.selecting = false;
    this.setCut(Math.max(1, Math.min(this.base.n - 1, i)));
  }

  setCut(cut) {
    this.pause();
    if (this.pos) this.closePosition('manual');
    this.cut = cut;
    this.lastK = tfIndexOfBase(this.agg, cut - 1);
    this.win = Math.max(0, this.lastK + 1 - CHUNK);
    this.render();
    this.chart.timeScale().scrollToPosition(20, false);
    this.updateMarkers();
    this.emit();
  }

  exitReplay() {
    this.pause();
    if (this.pos) this.closePosition('manual');
    this.selecting = false;
    this.cut = null;
    this.clearPriceLines();
    this.useTf(this.tf);
  }

  /* Один крок = одна свічка поточного таймфрейму. Усередині кроку
     проходимо кожну базову свічку — інакше на H4 стоп і тейк в одній
     свічці вирішувались би навмання. */
  step() {
    if (!this.replay) return false;
    if (this.cut >= this.base.n) { this.pause(); this.emit(); return false; }
    const k = tfIndexOfBase(this.agg, this.cut);
    const next = this.agg.s[k + 1];
    const had = this.closed.length;
    /* lastK і cut рухаємо до перевірки позиції: маркер виходу ставиться
       на свічку, яку вже видно. */
    const from = this.cut;
    this.cut = next;
    this.lastK = k;
    for (let i = from; i < next && this.pos; i += 1) this.checkPos(i);
    this.series.update(this.bar(k));
    if (this.pos) this.pos.bars += 1;
    if (this.closed.length !== had) this.updateMarkers();
    this.emit();
    return true;
  }

  play(ms) {
    if (ms) this.speedMs = ms;
    if (!this.replay) return;
    this.pause();
    this.playing = true;
    this.timer = setInterval(() => { if (!this.step()) this.pause(); }, this.speedMs);
    this.emit();
  }

  setSpeed(ms) {
    this.speedMs = ms;
    if (this.playing) this.play(ms);
  }

  pause() {
    if (this.timer) clearInterval(this.timer);
    this.timer = null;
    if (this.playing) { this.playing = false; this.emit(); }
  }

  /* ---------------- позиція ---------------- */

  price() {
    if (!this.base) return 0;
    const i = this.replay ? this.cut - 1 : this.base.n - 1;
    return this.base.c[i];
  }

  defaultDistance() {
    const d = atr(this.agg, this.base, this.lastK, this.cut ?? this.base.n);
    return d > 0 ? d : this.price() * 0.002;
  }

  openPosition(side, { slDist, rr = 2 } = {}) {
    if (!this.replay || this.pos) return;
    const entry = this.price();
    const d = slDist > 0 ? slDist : this.defaultDistance();
    const dir = side === 'LONG' ? 1 : -1;
    this.pos = {
      side, entry, sl: entry - dir * d, sl0: entry - dir * d, tp: entry + dir * d * rr,
      entryIdx: this.cut - 1, entryT: this.base.t[this.cut - 1], bars: 0, tf: this.tf,
    };
    this.syncPriceLines();
    this.updateMarkers();
    this.emit();
  }

  setLevels({ sl, tp }) {
    const p = this.pos;
    if (!p) return;
    const now = this.price();
    const long = p.side === 'LONG';
    /* Мінімальна відстань рівня від ціни: тік або 5% ATR. Без неї стоп,
       притягнутий упритул до входу, давав ризик у мільйонну частку
       пункту — і угода в «−90 000 000R». */
    const tick = 1 / 10 ** (this.base?.digits ?? 2);
    const gap = Math.max(tick * 2, this.defaultDistance() * 0.05);
    if (sl != null && Number.isFinite(sl)) {
      /* Стоп не може стояти по той бік ціни — він спрацював би одразу. */
      p.sl = long ? Math.min(sl, now - gap) : Math.max(sl, now + gap);
      /* Поки не пройшло жодної свічки — це ще планування, і ризик
         угоди рахуємо від нового стопа. Потім стоп можна підтягувати,
         а R лишається від початкового. */
      if (p.bars === 0) p.sl0 = p.sl;
    }
    if (tp != null && Number.isFinite(tp)) p.tp = long ? Math.max(tp, now + gap) : Math.min(tp, now - gap);
    this.syncPriceLines();
    this.emit();
  }

  moveToBE() {
    if (!this.pos) return;
    const now = this.price();
    const p = this.pos;
    if ((p.side === 'LONG' && now <= p.entry) || (p.side === 'SHORT' && now >= p.entry)) return;
    p.sl = p.entry;
    this.syncPriceLines();
    this.emit();
  }

  rOf(p, price) {
    const risk = Math.abs(p.entry - p.sl0) || 1e-9;
    return (p.side === 'LONG' ? price - p.entry : p.entry - price) / risk;
  }

  checkPos(i) {
    const p = this.pos;
    if (!p || i <= p.entryIdx) return;
    const b = this.base;
    const long = p.side === 'LONG';
    const o = b.o[i];
    const hitSL = long ? b.l[i] <= p.sl : b.h[i] >= p.sl;
    const hitTP = long ? b.h[i] >= p.tp : b.l[i] <= p.tp;
    if (!hitSL && !hitTP) return;
    /* Гепом відкрились за рівнем — виходимо по відкриттю, як і в
       реальності. Обидва рівні в одній хвилинці — вважаємо, що першим
       був стоп: краще недооцінити систему, ніж перехвалити. */
    let reason; let px;
    if (long ? o <= p.sl : o >= p.sl) { reason = 'sl'; px = o; }
    else if (long ? o >= p.tp : o <= p.tp) { reason = 'tp'; px = o; }
    else if (hitSL) { reason = 'sl'; px = p.sl; }
    else { reason = 'tp'; px = p.tp; }
    this.finish(reason, px, i);
  }

  closePosition(reason = 'manual') {
    if (!this.pos) return;
    this.finish(reason, this.price(), this.cut - 1);
  }

  finish(reason, px, idx) {
    const p = this.pos;
    const r = this.rOf(p, px);
    const result = Math.abs(r) < 0.05 ? 'BE' : r > 0 ? 'WIN' : 'LOSS';
    const trade = {
      id: `c${Date.now()}${Math.random().toString(36).slice(2, 6)}`,
      symbol: this.base.symbol, side: p.side, tf: p.tf,
      entry: p.entry, sl: p.sl0, slFinal: p.sl, tp: p.tp, exit: px,
      entryIdx: p.entryIdx, exitIdx: idx, entryT: p.entryT, exitT: this.base.t[idx],
      r: Math.round(r * 100) / 100, result, reason, digits: this.base.digits,
    };
    this.pos = null;
    this.closed.push(trade);
    this.syncPriceLines();
    this.updateMarkers();
    this.cb.onClosed?.(trade);
    this.emit();
  }

  removeClosed(id) {
    this.closed = this.closed.filter((t) => t.id !== id);
    this.updateMarkers();
  }

  /* ---------------- лінії й маркери ---------------- */

  clearPriceLines() {
    Object.values(this.priceLines).forEach((l) => { try { this.series.removePriceLine(l); } catch { /* вже немає */ } });
    this.priceLines = {};
  }

  syncPriceLines() {
    const p = this.pos;
    if (!p) { this.clearPriceLines(); return; }
    const want = {
      entry: { price: p.entry, color: '#787b86', title: p.side === 'LONG' ? 'Long' : 'Short', lineStyle: 2 },
      sl: { price: p.sl, color: '#f23645', title: 'SL', lineStyle: 0 },
      tp: { price: p.tp, color: '#089981', title: 'TP', lineStyle: 0 },
    };
    Object.entries(want).forEach(([key, o]) => {
      const opts = { price: o.price, color: o.color, lineWidth: 1, lineStyle: o.lineStyle, axisLabelVisible: true, title: o.title };
      if (this.priceLines[key]) this.priceLines[key].applyOptions(opts);
      else this.priceLines[key] = this.series.createPriceLine(opts);
    });
  }

  timeOfBase(i) {
    const k = tfIndexOfBase(this.agg, i);
    return k >= this.win && k <= this.lastK ? this.agg.t[k] : null;
  }

  updateMarkers() {
    if (!this.agg) return;
    const m = [];
    const add = (i, side, isEntry, text) => {
      const time = this.timeOfBase(i);
      if (time == null) return;
      const long = side === 'LONG';
      if (isEntry) {
        m.push({ time, position: long ? 'belowBar' : 'aboveBar', shape: long ? 'arrowUp' : 'arrowDown', color: long ? '#2962ff' : '#e91e63', text });
      } else {
        m.push({ time, position: long ? 'aboveBar' : 'belowBar', shape: 'circle', color: '#9598a1', size: 0.6, text });
      }
    };
    this.closed.forEach((t) => {
      add(t.entryIdx, t.side, true, t.side === 'LONG' ? 'Buy' : 'Sell');
      add(t.exitIdx, t.side, false, `${t.r > 0 ? '+' : ''}${t.r.toFixed(2)}R`);
    });
    if (this.pos) add(this.pos.entryIdx, this.pos.side, true, this.pos.side === 'LONG' ? 'Buy' : 'Sell');
    m.sort((a, b) => a.time - b.time);
    this.markers.setMarkers(m);
  }

  /* ---------------- оверлей (зони позиції, ножиці) ---------------- */

  xOfBase(i) {
    const k = tfIndexOfBase(this.agg, i);
    return this.chart.timeScale().logicalToCoordinate(k - this.win);
  }

  loop() {
    this.raf = requestAnimationFrame(() => this.loop());
    if (!this.ov || !this.agg) return;
    const ts = this.chart.timeScale();
    const plotW = ts.width();
    const plotH = this.chart.paneSize(0).height;
    const parts = [];

    const zone = (x1, x2, yA, yB, color) => {
      const x = Math.max(0, Math.min(x1, x2)); const w = Math.min(plotW, Math.max(x1, x2)) - x;
      if (w <= 0) return;
      const y = Math.min(yA, yB); const h = Math.abs(yA - yB);
      parts.push(`<rect x="${x}" y="${y}" width="${w}" height="${h}" fill="${color}"/>`);
    };

    /* Закриті угоди — бліді коробки від входу до виходу, як позиції в TV. */
    for (const t of this.closed) {
      const x1 = this.xOfBase(t.entryIdx); const x2 = this.xOfBase(t.exitIdx);
      if (x1 == null || x2 == null || (x1 > plotW && x2 > plotW) || (x1 < 0 && x2 < 0)) continue;
      const ye = this.series.priceToCoordinate(t.entry);
      const ys = this.series.priceToCoordinate(t.sl);
      const yt = this.series.priceToCoordinate(t.tp);
      const yx = this.series.priceToCoordinate(t.exit);
      if (ye == null) continue;
      const xx2 = Math.max(x2, x1 + 6);
      if (yt != null) zone(x1, xx2, ye, yt, 'rgba(8,153,129,0.13)');
      if (ys != null) zone(x1, xx2, ye, ys, 'rgba(242,54,69,0.13)');
      if (yx != null) parts.push(`<line x1="${x1}" y1="${ye}" x2="${xx2}" y2="${yx}" stroke="${t.r >= 0 ? '#089981' : '#f23645'}" stroke-width="1" stroke-dasharray="3 3"/>`);
    }

    /* Відкрита позиція — від входу до правого краю. */
    const p = this.pos;
    if (p) {
      const x1 = this.xOfBase(p.entryIdx);
      const ye = this.series.priceToCoordinate(p.entry);
      const ys = this.series.priceToCoordinate(p.sl);
      const yt = this.series.priceToCoordinate(p.tp);
      if (x1 != null && ye != null) {
        if (yt != null) zone(x1, plotW, ye, yt, 'rgba(8,153,129,0.2)');
        if (ys != null) zone(x1, plotW, ye, ys, 'rgba(242,54,69,0.2)');
      }
    }

    /* Ножиці: вертикаль під курсором і затемнення «майбутнього». */
    if (this.selecting && this.hoverLogical != null) {
      const x = ts.logicalToCoordinate(Math.round(this.hoverLogical));
      if (x != null) {
        const bg = this.prefs.bg;
        parts.push(`<rect x="${x}" y="0" width="${Math.max(0, plotW - x)}" height="${plotH}" fill="${rgba(bg, 0.72)}"/>`);
        parts.push(`<line x1="${x}" y1="0" x2="${x}" y2="${plotH}" stroke="#2962ff" stroke-width="1.5"/>`);
      }
    }

    const html = parts.join('');
    if (html !== this.lastOv) { this.ov.innerHTML = html; this.lastOv = html; }
    this.cb.onFrame?.();
  }

  /* Координата ціни — для ручок SL/TP, які малює сторінка. */
  y(price) { return this.series.priceToCoordinate(price); }
  priceAt(y) { return this.series.coordinateToPrice(y); }

  /* ---------------- стан для сторінки ---------------- */

  emit() {
    if (this.agg && this.lastK >= 0) this.legendLast();
    const p = this.pos;
    const now = this.price();
    this.cb.onState?.({
      ready: !!this.base,
      tf: this.tf,
      replay: this.replay,
      selecting: this.selecting,
      playing: this.playing,
      atEnd: this.replay && this.cut >= this.base.n,
      time: this.base ? this.base.t[(this.replay ? this.cut : this.base.n) - 1] : null,
      price: now,
      pos: p ? { ...p, r: this.rOf(p, now), rr: Math.abs(p.tp - p.entry) / (Math.abs(p.entry - p.sl0) || 1e-9) } : null,
    });
  }
}
