import { chromium } from '/home/claude/.npm-global/lib/node_modules/playwright/index.mjs';
import fs from 'node:fs';
const FPS = 30, DUR = 19.8, from = Number(process.argv[2] || 0), to = Number(process.argv[3] || Math.round(FPS * DUR));
fs.mkdirSync('/home/claude/edge-ad14/frames', { recursive: true });
const b = await chromium.launch({ args: ['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const pg = await b.newPage({ viewport: { width: 1080, height: 1920 } });
await pg.goto('http://127.0.0.1:8804/index.html'); await pg.waitForFunction(() => window.__ready, null, { timeout: 30000 });
for (let f = from; f < to; f++) {
  await pg.evaluate((t) => window.renderAt(t), f / FPS);
  await pg.screenshot({ path: `/home/claude/edge-ad14/frames/${String(f).padStart(4, '0')}.jpg`, type: 'jpeg', quality: 93, timeout: 180000 });
}
await b.close(); console.log('done', from, to);
