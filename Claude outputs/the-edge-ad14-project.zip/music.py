# Музика ролика 14: чіл / lo-fi, 85.7 BPM (такт = 2.8 с = одна сцена).
# Тепле родес-піано (maj7/9), мʼякий кік, римшот, свінгові хети, саб, ніжна мелодія-дзвіночок,
# все через простий ревербератор (Шредер), щоб звучало «дорого» і просторово.
# Такт 0 — тільки піано (питання на чорному), з такту 1 — барабани, такт 6 — фінал без барабанів.
import numpy as np
from scipy.signal import butter, sosfilt, lfilter
from scipy.io import wavfile
SR = 44100; B = 60 / 85.7; BAR = 4 * B
DUR = 19.8; N = int(SR * DUR)
L = np.zeros(N); R = np.zeros(N); rng = np.random.default_rng(14)
VL = np.zeros(N); VR = np.zeros(N)          # шина на ревербератор
T = lambda d: np.arange(int(d * SR)) / SR
lp = lambda x, f, o=2: sosfilt(butter(o, f, 'low', fs=SR, output='sos'), x)
hp = lambda x, f, o=2: sosfilt(butter(o, f, 'high', fs=SR, output='sos'), x)
bp = lambda x, a, b, o=2: sosfilt(butter(o, [a, b], 'band', fs=SR, output='sos'), x)
hz = lambda m: 440 * 2 ** ((m - 69) / 12)
def add(s, at, g=1.0, pan=0.0, verb=0.0):
    i = int(at * SR)
    if i >= N: return
    j = min(N, i + len(s)); s = s[:j - i] * g
    L[i:j] += s * (1 - pan); R[i:j] += s * (1 + pan)
    if verb: VL[i:j] += s * verb * (1 - pan); VR[i:j] += s * verb * (1 + pan)
duck = np.ones(N)
def sc(at, depth=.25):
    i = int(at * SR); t = T(.3); e = 1 - depth * np.exp(-t * 10); j = min(N, i + len(t))
    if i < N: duck[i:j] = np.minimum(duck[i:j], e[:j - i])

def rhodes(ms, d, g=1):
    t = T(d); out = 0
    for m in ms:
        f = hz(m) * (1 + .002 * np.sin(2 * np.pi * 5 * t))      # легкий тремоло-вібрато
        ph = 2 * np.pi * np.cumsum(f) / SR
        out = out + np.sin(ph + np.sin(ph) * 1.1 * np.exp(-t * 3)) + .2 * np.sin(2 * ph) * np.exp(-t * 5)
    env = np.minimum(1, t * 60) * np.exp(-t * .9) * np.minimum(1, (d - t) * 8)
    return lp(out, 2600) * env * .05 * g
def kick():
    t = T(.4); f = 48 + 70 * np.exp(-t * 30)
    return lp(np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 7), 1500) * .75
def rim():
    t = T(.12); n = rng.standard_normal(len(t))
    return (bp(n, 1500, 5000) * np.exp(-t * 45) * .6 + np.sin(2 * np.pi * 1700 * t) * np.exp(-t * 70) * .35) * .3
def snare():
    t = T(.35); n = rng.standard_normal(len(t))
    return (lp(bp(n, 900, 6000), 5000) * np.exp(-t * 14) * .5 + np.sin(2 * np.pi * 190 * t) * np.exp(-t * 25) * .3) * .38
def hat(g=1):
    t = T(.05); return hp(rng.standard_normal(len(t)), 7000, 4) * np.exp(-t * 80) * .09 * g
def sub(m, d):
    t = T(d); return np.sin(2 * np.pi * hz(m) * t) * np.minimum(1, t * 80) * np.minimum(1, (d - t) * 10) * .32
def bell(m, g=1):
    t = T(1.4); f = hz(m)
    return (np.sin(2 * np.pi * f * t) + .3 * np.sin(2 * np.pi * f * 3 * t) * np.exp(-t * 8)) * np.exp(-t * 2.6) * np.minimum(1, t * 400) * .06 * g
def air(d):
    t = T(d); return lp(hp(rng.standard_normal(len(t)), 3000), 9000) * np.sin(np.pi * t / d) ** 2 * .02

# Ре-бемоль: Dbmaj9 – Cm7 – Bbm9 – Gbmaj7(#11) — м'яко, «по-епловськи»
CH = [[49, 53, 56, 60, 63], [48, 51, 55, 58, 62], [46, 49, 53, 56, 60], [42, 46, 49, 53, 58], [49, 53, 56, 60, 63], [48, 51, 55, 58, 62], [46, 49, 53, 56, 60]]
BS = [37, 36, 34, 30, 37, 36, 34]
MEL = [[68, 72, 75], [67, 70, 74], [65, 68, 72], [65, 70, 73], [68, 72, 75, 77], [70, 74], []]

for b in range(7):
    at = b * BAR
    # піано: акорд на «1» і повтор на «і» 3-ї долі (синкопа)
    g = .8 if b == 0 else 1
    add(rhodes(CH[b], BAR * .62, g), at, 1, -.1, .35)
    add(rhodes(CH[b][1:], BAR * .4, .7 * g), at + 2.5 * B, 1, .1, .35)
    if b >= 1:
        add(sub(BS[b], BAR * .95), at, 1)
    if 1 <= b <= 5:
        for k in range(4):
            bt = at + k * B
            if k in (0,) or (k == 2 and b % 2): add(kick(), bt, 1); sc(bt)
            if k == 2 and not b % 2: add(kick(), bt + B / 2, .85); sc(bt + B / 2)
            if k in (1, 3): add(snare() if b >= 2 else rim(), bt, 1, .05, .25)
            add(hat(.9), bt, 1, -.3); add(hat(.5), bt + B * .58, 1, .3)   # свінг
    for i, m in enumerate(MEL[b]):
        add(bell(m), at + B * (1 + i * 1.0), 1, (-.25, .25)[i % 2], .6)
    add(air(BAR), at, 1, 0, .2)
# фінал: акорд, що тягнеться, і дзвіночок вгору
E = 6 * BAR
for i, m in enumerate([73, 77, 80, 84]): add(bell(m, .9), E + .6 + i * B / 2, 1, (-.2, .2)[i % 2], .7)

# ── ревербератор Шредера: 4 комб-фільтри + 2 all-pass
def reverb(x):
    out = np.zeros_like(x)
    for d, g in ((1557, .84), (1617, .83), (1491, .85), (1422, .84)):
        b = np.zeros(d + 1); b[0] = 1; a = np.zeros(d + 1); a[0] = 1; a[d] = -g
        out += lfilter(b, a, x)
    for d, g in ((225, .5), (556, .5)):
        b = np.zeros(d + 1); b[0] = -g; b[d] = 1; a = np.zeros(d + 1); a[0] = 1; a[d] = -g
        out = lfilter(b, a, out)
    return lp(out, 6000) * .12
L += reverb(VL); R += reverb(VR)
L *= duck; R *= duck
# легке «теплe» насичення і плавне згасання
fade = np.ones(N); fs = int(18.4 * SR); fade[fs:] = np.linspace(1, 0, N - fs) ** 1.3
fi = np.minimum(1, np.arange(N) / (SR * .25))
L = np.tanh(L * 1.1) * fade * fi; R = np.tanh(R * 1.1) * fade * fi
pk = max(abs(L).max(), abs(R).max()); L /= pk / .85; R /= pk / .85
wavfile.write('music.wav', SR, (np.stack([L, R], 1) * 32767).astype(np.int16)); print('ok', DUR)
