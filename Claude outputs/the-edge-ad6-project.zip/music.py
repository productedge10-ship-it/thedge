# Звук ролика 6: шум річки → кожен відскок «дзинь» вище на ноту (пентатоніка) + сплеск,
# «буль» при зануренні, райзер і дроп на 2.7 с (120 BPM). Все синтезовано, без чужих семплів
import numpy as np
from scipy.signal import butter, sosfilt
from scipy.io import wavfile
SR = 44100; B = .5; DROP = 2.7; S2 = 5.7; END = 8.2
DUR = 10.9; N = int(SR * DUR)
L = np.zeros(N); R = np.zeros(N); rng = np.random.default_rng(6)
T = lambda d: np.arange(int(d * SR)) / SR
lp = lambda x, f, o=2: sosfilt(butter(o, f, 'low', fs=SR, output='sos'), x)
hp = lambda x, f, o=2: sosfilt(butter(o, f, 'high', fs=SR, output='sos'), x)
bp = lambda x, a, b, o=2: sosfilt(butter(o, [a, b], 'band', fs=SR, output='sos'), x)
hz = lambda m: 440 * 2 ** ((m - 69) / 12)
def add(s, at, g=1.0, pan=0.0):
    i = int(at * SR)
    if i >= N: return
    j = min(N, i + len(s)); s = s[:j - i] * g
    L[i:j] += s * (1 - pan); R[i:j] += s * (1 + pan)
duck = np.ones(N)
def sc(at, depth=.6):
    i = int(at * SR); t = T(.25); e = 1 - depth * np.exp(-t * 14); j = min(N, i + len(t))
    if i < N: duck[i:j] = np.minimum(duck[i:j], e[:j - i])

# ── звуки хука
def plink(m):
    t = T(.9); f = hz(m) * (1 + .02 * np.exp(-t * 40))
    ph = 2 * np.pi * np.cumsum(f) / SR
    return (np.sin(ph) + .35 * np.sin(2 * ph) + .12 * np.sin(3 * ph)) * np.exp(-t * 5) * np.minimum(1, t * 800) * .32
def splash(g=1):
    t = T(.35); return bp(rng.standard_normal(len(t)), 1200, 8000) * (np.exp(-t * 22) + .25 * np.exp(-t * 6)) * .25 * g
def bloop():
    t = T(.35); f = 160 + 480 * (1 - np.exp(-t * 18)); return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 9) * .55
def whoosh(d=.5, a=500, b=5000):
    t = T(d); return bp(rng.standard_normal(len(t)), a, b) * np.sin(np.pi * t / d) ** 2 * .3
def riser(d):
    t = T(d); n = rng.standard_normal(len(t)); out = np.zeros(len(t)); sg = int(SR * .02)
    for s0 in range(0, len(t), sg):
        f = 400 + 9000 * (s0 / len(t)) ** 2; out[s0:s0 + sg] = bp(n[s0:s0 + sg], f * .7, min(f * 1.3, 20000))
    return out * np.linspace(0, 1, len(t)) ** 2 * .4

# ── барабани й синти
def kick():
    t = T(.4); f = 48 + 150 * np.exp(-t * 30); ph = 2 * np.pi * np.cumsum(f) / SR
    return np.tanh(np.sin(ph) * np.exp(-t * 8) * 2) * .85
def clap():
    t = T(.28); n = rng.standard_normal(len(t))
    e = np.exp(-t * 18) + .7 * np.exp(-((t - .011) * 150) ** 2) + .6 * np.exp(-((t - .022) * 150) ** 2)
    return np.tanh(bp(n, 900, 7000) * e * 1.5) * .5
def hat(op=False, g=1):
    t = T(.16 if op else .04); return hp(rng.standard_normal(len(t)), 8000, 4) * np.exp(-t * (16 if op else 110)) * .2 * g
def crash(d=1.6):
    t = T(d); return hp(rng.standard_normal(len(t)), 5000) * np.exp(-t * 2.4) * .2
def impact():
    t = T(1.2); return (np.sin(2 * np.pi * np.cumsum(34 + 90 * np.exp(-t * 7)) / SR) * np.exp(-t * 3) + lp(rng.standard_normal(len(t)), 700) * np.exp(-t * 5) * .5) * .8
def saw(f, t): return 2 * ((t * f) % 1) - 1
def stab(ms, d=.22):
    t = T(d); s = sum(saw(hz(m) * k, t) for m in ms for k in (.997, 1.003))
    return lp(s, 3200) * np.exp(-t * 10) * np.minimum(1, t * 400) * .06
def sub(m, d):
    t = T(d); return np.tanh(np.sin(2 * np.pi * hz(m) * t) * 1.8) * np.minimum(1, t * 300) * np.minimum(1, (d - t) * 60) * .5

# ═════ ХУК 0–2.7
tt = np.arange(N) / SR
water = lp(bp(rng.standard_normal(N), 150, 1500), 900) * (.5 + .5 * np.sin(2 * np.pi * .7 * tt) ** 2) * .5
pad = sum(saw(hz(m + d), tt) for m in (57, 64, 67, 72) for d in (-.1, .1))
pad = lp(pad, 700) * .018
hook_env = np.clip((DROP - tt) / .3, 0, 1) * np.clip(tt / .05, 0, 1)
L += (water + pad) * hook_env; R += (water + pad) * hook_env
add(whoosh(.45, 800, 6000), 0, .9, -.3)
SK = [.5, .92, 1.26, 1.53, 1.75, 1.93, 2.07]
NOTES = [72, 74, 76, 79, 81, 84, 86]   # до-мажорна пентатоніка вгору
for k, (t0, m) in enumerate(zip(SK, NOTES)):
    add(plink(m), t0, 1, (-.2, .2)[k % 2]); add(splash(1 - k * .1), t0, 1)
add(bloop(), 2.18, 1); add(splash(.6), 2.18, 1)
add(riser(.5), 2.2, 1)
add(whoosh(.35, 300, 3000), 2.35, .8)

# ═════ ДРОП 2.7–8.2
add(impact(), DROP, .9); add(crash(), DROP, 1)
CH = [[57, 60, 64], [53, 57, 60], [48, 52, 55], [55, 59, 62]]   # Am F C G
BS = [45, 41, 36, 43]
def groove(t0, t1, fill=False):
    k = 0
    while t0 + k * B < t1 - 1e-3:
        at = t0 + k * B; bar = k // 4; c = k % 4
        if c in (0, 2) or (c == 3 and bar % 2): add(kick(), at, 1); sc(at)
        if c in (1, 3): add(clap(), at, 1)
        add(hat(g=.9), at, 1, -.25); add(hat(True, .5), at + B / 2, 1, .25)
        if c == 0: add(sub(BS[(k // 2) % 4], 2 * B - .02), at, 1)
        if c == 2: add(sub(BS[(k // 2) % 4], 2 * B - .02), at, 1)
        # акорди на офбітах
        add(stab(CH[(k // 2) % 4]), at + B / 2, 1, (-.2, .2)[k % 2])
        k += 1
    if fill:
        for i in range(8): add(clap() * (.3 + i * .08), t1 - B * 2 + i * B / 4, 1)
groove(DROP, S2, fill=True)
add(crash(1.2), S2, .8); add(impact(), S2, .45)
groove(S2, END)
add(riser(.9), END - .95, .9)
# ═════ ФІНАЛ 8.2–кінець
add(impact(), END, 1); add(crash(2), END, 1.1)
for m in (57, 60, 64, 69): add(stab([m], 2.4) * 3, END, 1)
add(sub(45, 2.2), END, 1)
for i, m in enumerate([76, 79, 81, 84]): add(plink(m) * .7, END + .5 + i * .25, 1, (-.2, .2)[i % 2])

# ── мікс
L *= np.where(tt >= DROP, duck, 1); R *= np.where(tt >= DROP, duck, 1)
fade = np.ones(N); fs = int(10.2 * SR); fade[fs:] = np.linspace(1, 0, N - fs) ** 1.5
L = np.tanh(L * 1.3) * fade; R = np.tanh(R * 1.3) * fade
pk = max(abs(L).max(), abs(R).max()); L /= pk / .89; R /= pk / .89
wavfile.write('music.wav', SR, (np.stack([L, R], 1) * 32767).astype(np.int16)); print('ok', DUR)
