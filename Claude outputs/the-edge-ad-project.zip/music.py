# Музика для реклами: 120 BPM, 14 с. Усе синтезоване тут — жодного чужого семплу.
import numpy as np
from scipy.signal import butter, sosfilt
from scipy.io import wavfile
SR=44100; DUR=14.0; N=int(SR*DUR); BEAT=0.5
L=np.zeros(N); R=np.zeros(N)
rng=np.random.default_rng(7)
def t_(d): return np.arange(int(d*SR))/SR
def lp(x,f,o=2): return sosfilt(butter(o,f,'low',fs=SR,output='sos'),x)
def hp(x,f,o=2): return sosfilt(butter(o,f,'high',fs=SR,output='sos'),x)
def bp(x,a,b,o=2): return sosfilt(butter(o,[a,b],'band',fs=SR,output='sos'),x)
def add(sig,at,g=1.0,pan=0.0):
    i=int(at*SR); j=min(N,i+len(sig)); 
    if i>=N: return
    s=sig[:j-i]*g
    L[i:j]+=s*(1-pan)*0.5*2**0.5*0.7071*1.414; R[i:j]+=s*(1+pan)*0.5*1.0
def kick(g=1.0):
    t=t_(0.42); f=45+110*np.exp(-t*28); ph=2*np.pi*np.cumsum(f)/SR
    return np.sin(ph)*np.exp(-t*7.5)*g + 0.25*np.sin(ph*2)*np.exp(-t*30)
def clap():
    t=t_(0.25); n=rng.standard_normal(len(t))
    env=np.exp(-t*18)+0.6*np.exp(-((t-0.012)*120)**2)+0.5*np.exp(-((t-0.024)*120)**2)
    return bp(n,900,5000)*env*0.55
def hat(open_=False):
    t=t_(0.18 if open_ else 0.05); n=rng.standard_normal(len(t))
    return hp(n,7000,4)*np.exp(-t*(18 if open_ else 80))*0.22
def note(f,d,kind='saw'):
    t=t_(d)
    if kind=='saw': s=2*((t*f)%1)-1
    elif kind=='sq': s=np.sign(np.sin(2*np.pi*f*t))
    else: s=np.sin(2*np.pi*f*t)
    return s
def hz(m): return 440*2**((m-69)/12)
# акорди: Am F C G (по такту = 2 с), корені в октаві 1-2
prog=[(45,[57,60,64]),(41,[53,57,60]),(48,[55,60,64]),(43,[55,59,62])]
def chord_at(t): return prog[int(t//2)%4]
duck=np.ones(N)
def sidechain(at):
    i=int(at*SR); t=t_(0.3); env=1-0.75*np.exp(-t*14)
    j=min(N,i+len(t)); duck[i:j]=np.minimum(duck[i:j],env[:j-i])
# ---------- барабани ----------
for b in range(int(DUR/BEAT)):
    at=b*BEAT
    cut = 10.5<=at<11.5          # пауза перед «зрозумій свою»
    if at>=13.5: break
    if not cut:
        add(kick(1.0 if at>=4 else 0.85),at,0.95); sidechain(at)
        if at>=2.0 and b%2==1: add(clap(),at,0.9)
        if at>=4.0:
            add(hat(),at+0.25,0.9,0.3)
            for s in (0.125,0.375): add(hat(),at+s,0.45,-0.3)
            if b%4==3: add(hat(True),at+0.25,0.8,0.2)
# ---------- бас ----------
bass=np.zeros(N)
for b in range(int(DUR/BEAT)):
    at=b*BEAT
    if at>=13.5 or 10.5<=at<11.5: continue
    root,_=chord_at(at)
    for k,off in enumerate((0,0.25)):
        if at<2.0 and k==1: continue
        s=note(hz(root),0.24,'saw'); t=t_(0.24)
        s=lp(s,260 if at<4 else 520)*np.exp(-t*3)
        i=int((at+off)*SR); bass[i:i+len(s)]+=s[:N-i] if i+len(s)>N else s
bass+=0.6*lp(np.sin(2*np.pi*np.cumsum(np.array([hz(chord_at(x/SR)[0]) for x in range(0,N)]))/SR),120)*(np.arange(N)/SR<13.6)
bass=np.tanh(bass*1.4)*duck*0.55
L+=bass; R+=bass
# ---------- арпеджіо з 4 с ----------
arpL=np.zeros(N); arpR=np.zeros(N)
step=BEAT/4
for k in range(int(DUR/step)):
    at=k*step
    if at<4.0 or at>=13.0 or 10.5<=at<11.5: continue
    _,ch=chord_at(at); m=ch[k%3]+12+(12 if k%8>=6 else 0)
    t=t_(0.16); s=(note(hz(m),0.16,'sq')*0.35+note(hz(m)*2,0.16,'sin')*0.5)*np.exp(-t*22)
    s=lp(s,3200); i=int(at*SR); j=min(N,i+len(s))
    pan=0.35 if k%2 else -0.35
    arpL[i:j]+=s[:j-i]*(1-pan); arpR[i:j]+=s[:j-i]*(1+pan)
L+=arpL*0.16*duck; R+=arpR*0.16*duck
# ---------- пед (весь трек, тихо) ----------
pad=np.zeros(N); tt=np.arange(N)/SR
for bar in range(7):
    _,ch=chord_at(bar*2); i=int(bar*2*SR); j=min(N,int((bar*2+2)*SR)); t=tt[i:j]-bar*2
    for m in ch:
        for det in (-0.08,0.08):
            pad[i:j]+=np.sin(2*np.pi*hz(m+det)*t)*0.12
    pad[i:j]*=np.minimum(1,t*3)*np.minimum(1,(2-t)*3)
pad=lp(pad,1800)*(0.35+0.65*((tt>=10.5)&(tt<11.5)))
L+=pad*0.5; R+=pad*0.5
# ---------- ефекти ----------
def riser(d):
    t=t_(d); n=rng.standard_normal(len(t))
    out=np.zeros(len(t)); seg=int(SR*0.02)
    for s0 in range(0,len(t),seg):
        f=600+ (9000-600)*(s0/len(t))**2
        out[s0:s0+seg]=bp(n[s0:s0+seg],f*0.7,min(f*1.3,20000))
    return out*np.linspace(0,1,len(t))**2*0.6
def impact():
    t=t_(1.2); s=np.sin(2*np.pi*np.cumsum(38+60*np.exp(-t*6))/SR)*np.exp(-t*3)
    n=lp(rng.standard_normal(len(t)),900)*np.exp(-t*5)*0.6
    return (s+n)*0.9
def whoosh(d=0.4):
    t=t_(d); n=rng.standard_normal(len(t)); env=np.sin(np.pi*t/d)**2
    return bp(n,800,4000)*env*0.35
def glitch():
    t=t_(0.18); n=np.round(rng.standard_normal(len(t))*3)/3
    return hp(n,1500)*np.exp(-t*12)*0.25
add(glitch(),0.0,1,-0.5); add(glitch(),0.5,1,0.5); add(glitch(),1.0,1,0)
add(riser(1.0),1.0,1); add(impact(),2.0,0.9)
add(riser(1.0),3.0,0.9); add(impact(),4.0,1.0)
for k,at in enumerate((4.3,4.8,5.3,5.8)): add(whoosh(0.35),at,1,(-0.5,0.5)[k%2])
add(whoosh(0.8),6.6,1.2); add(impact(),7.0,0.7)
add(riser(1.0),9.5,0.8)
add(impact(),11.5,1.0); add(impact(),13.0,0.5)
# ---------- мастер ----------
fade=np.ones(N); fs=int(12.8*SR); fade[fs:]=np.linspace(1,0,N-fs)**1.5
L=np.tanh(L*1.1)*fade; R=np.tanh(R*1.1)*fade
pk=max(np.abs(L).max(),np.abs(R).max()); L/=pk/0.89; R/=pk/0.89
wavfile.write('music.wav',SR,(np.stack([L,R],1)*32767).astype(np.int16))
print('ok', DUR)
