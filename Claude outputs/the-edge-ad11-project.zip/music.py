# Біт ролика 11 (на базі ad9): м'який ритмічний 120 BPM (як у ad7, що сподобався): округлий кік, снепи,
# шейкер зі свінгом, FM-піано. Маримба на кожен «пакет» угоди й кожен рядок, свуш на зміну розділу
import numpy as np
from scipy.signal import butter, sosfilt
from scipy.io import wavfile
SR = 44100; B = .5; S16 = B / 4
F0 = 2.5; END = 5.5; DUR = 6.5; N = int(SR * DUR)
L = np.zeros(N); R = np.zeros(N); rng = np.random.default_rng(9)
T = lambda d: np.arange(int(d * SR)) / SR
lp = lambda x, f, o=2: sosfilt(butter(o, f, 'low', fs=SR, output='sos'), x)
hp = lambda x, f, o=2: sosfilt(butter(o, f, 'high', fs=SR, output='sos'), x)
bp = lambda x, a, b, o=2: sosfilt(butter(o, [a, b], 'band', fs=SR, output='sos'), x)
hz = lambda m: 440 * 2 ** ((m - 69) / 12)
def add(s, at, g=1.0, pan=0.0):
    i = int(at * SR)
    if i >= N: return
    j = min(N, i + len(s)); s = s[:j - i] * g
    L[i:j] += s * (1 - pan); R[i:j] += s * (1 + pan)
duck = np.ones(N)
def sc(at, depth=.45):
    i = int(at * SR); t = T(.22); e = 1 - depth * np.exp(-t * 16); j = min(N, i + len(t))
    if i < N: duck[i:j] = np.minimum(duck[i:j], e[:j - i])
def kick():
    t = T(.35); f = 50 + 110 * np.exp(-t * 35); return lp(np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t * 9), 2500) * .9
def snap():
    t = T(.18); n = rng.standard_normal(len(t)); e = np.exp(-t * 30) + .6 * np.exp(-((t - .008) * 200) ** 2)
    return (bp(n, 1500, 6500) * e + np.sin(2 * np.pi * 1800 * t) * np.exp(-t * 60) * .3) * .38
def shaker(g=1):
    t = T(.06); return hp(rng.standard_normal(len(t)), 6000, 4) * np.sin(np.pi * t / .06) ** 2 * .12 * g
def epiano(ms, d=.45, g=1):
    t = T(d); out = 0
    for m in ms:
        f = hz(m); out = out + np.sin(2 * np.pi * f * t + np.sin(2 * np.pi * f * t) * 1.6 * np.exp(-t * 7))
    return lp(out, 3000) * np.exp(-t * 4.5) * np.minimum(1, t * 250) * np.minimum(1, (d - t) * 30) * .09 * g
def marimba(m, g=1):
    t = T(.5); f = hz(m)
    return (np.sin(2 * np.pi * f * t) + .25 * np.sin(2 * np.pi * f * 4 * t) * np.exp(-t * 30)) * np.exp(-t * 9) * np.minimum(1, t * 900) * .28 * g
def sub(m, d):
    t = T(d); return np.sin(2 * np.pi * hz(m) * t) * np.minimum(1, t * 200) * np.minimum(1, (d - t) * 50) * .5
def swish(d=.25):
    t = T(d); n = rng.standard_normal(len(t)); out = np.zeros(len(t)); sg = int(SR * .01)
    for s0 in range(0, len(t), sg):
        f = 1200 + 6000 * (s0 / len(t)); out[s0:s0 + sg] = bp(n[s0:s0 + sg], f * .7, min(f * 1.4, 20000))
    return out * np.sin(np.pi * t / d) ** 2 * .2
def crash(d=1.6):
    t = T(d); return hp(rng.standard_normal(len(t)), 6000) * np.exp(-t * 2.6) * .13
def thump():
    t = T(.8); return np.sin(2 * np.pi * np.cumsum(40 + 70 * np.exp(-t * 10)) / SR) * np.exp(-t * 4) * .7
def typing(t0, t1):
    k = 0
    while t0 + k * .045 < t1:
        t = T(.02); add(hp(rng.standard_normal(len(t)), 3000) * np.exp(-t * 250) * .12, t0 + k * .045, 1, (-.2, .2)[k % 2]); k += 1

def zap(d=.14):
    # «лазер» фіналу: швидкий свіп синуса вниз + шум
    t = T(d); f = 4000 * np.exp(-t * 25) + 300
    return (np.sin(2 * np.pi * np.cumsum(f) / SR) * .3 + hp(rng.standard_normal(len(t)), 4000) * .2) * np.exp(-t * 12)
def bell(m, d=1.2, g=1):
    t = T(d); f = hz(m)
    return (np.sin(2 * np.pi * f * t) + .5 * np.sin(2 * np.pi * f * 2.76 * t) * np.exp(-t * 6) + .25 * np.sin(2 * np.pi * f * 5.4 * t) * np.exp(-t * 12)) * np.exp(-t * 3) * .12 * g
CHD = [[65, 69, 72, 76], [64, 69, 72, 76], [62, 65, 69, 74], [64, 67, 72, 76]]
BS = [41, 45, 38, 36]
add(thump(), 0, .9); add(crash(1.0), 0, .5)
for k in range(11):
    at = k * B; c = k % 4
    add(kick(), at, 1); sc(at)
    if c in (1, 3): add(snap(), at, 1, .1)
    for s in range(4): add(shaker(1 if s % 2 == 0 else .55), at + s * S16 + (.02 if s % 2 else 0), 1, (-.3, .3)[s % 2])
    ch = CHD[(k // 2) % 4]
    if k % 2 == 0: add(sub(BS[(k // 2) % 4], 2 * B - .02), at, 1); add(epiano(ch, .4), at + B / 2, 1, -.15)
    else: add(epiano(ch, .3, .8), at + 3 * S16, 1, .15)
# автоімпорт
for i, p in enumerate([.5, .75, 1.0, 1.25]): add(swish(.2), p, .5, -.2); add(marimba([72, 74, 76, 79][i]), p + .2, 1, (-.25, .25)[i % 2])
for i in range(5): add(marimba([79, 81, 84, 86, 88][i], .7), 1.6 + i * .125, 1, (-.25, .25)[i % 2])
# функції: на кожну картку — свуш + акорд піано + маримба
add(swish(), F0 - .2, 1); add(crash(1.0), F0, .5)
for i in range(6):
    at = F0 + i * B; add(swish(.18), at - .12, .8, (-.2, .2)[i % 2])
    add(marimba([72, 74, 76, 79, 81, 84][i], 1.1), at, 1)
    add(marimba([79, 81, 84, 86, 88, 91][i], .5), at + .36, 1, .2)   # «клац» при посадці в сітку
# фінал: лазер → удар → дзвін-акорд
add(zap(), END, 1); add(thump(), END + .12, 1.1); add(crash(1.6), END + .12, 1)
for m in (65, 72, 77, 81): add(bell(m, 1.0, 1.2), END + .2, 1)
add(epiano([65, 69, 72, 76, 81], .9, 2.0), END + .12, 1); add(sub(41, .9), END + .12, 1)
L *= duck; R *= duck
fade = np.ones(N); fs = int(6.15 * SR); fade[fs:] = np.linspace(1, 0, N - fs) ** 1.5
L = np.tanh(L * 1.2) * fade; R = np.tanh(R * 1.2) * fade
pk = max(abs(L).max(), abs(R).max()); L /= pk / .89; R /= pk / .89
wavfile.write('music.wav', SR, (np.stack([L, R], 1) * 32767).astype(np.int16)); print('ok', DUR)
