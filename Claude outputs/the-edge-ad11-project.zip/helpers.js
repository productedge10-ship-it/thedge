const W = 1080, H = 1920, CX = W / 2, CY = H / 2;
const clamp = (x, a = 0, b = 1) => Math.min(b, Math.max(a, x));
const lerp = (a, b, k) => a + (b - a) * k;
const seg = (t, a, b) => clamp((t - a) / (b - a));
const oCub = k => 1 - Math.pow(1 - k, 3);
const oExp = k => k >= 1 ? 1 : 1 - Math.pow(2, -10 * k);
const iCub = k => k * k * k;
const ioCub = k => k < .5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2;
const oBack = (k, s = 1.9) => 1 + (s + 1) * Math.pow(k - 1, 3) + s * Math.pow(k - 1, 2);
// пружина: дає той самий «пружний» поп, що й у референсі
const spring = k => k <= 0 ? 0 : 1 - Math.exp(-7 * k) * Math.cos(13 * k);
const BEAT = 60 / 120;

const world = document.getElementById('world');
function el(html, parent = world) {
  const d = document.createElement('div'); d.className = 'abs'; d.innerHTML = html; parent.appendChild(d); return d;
}
// ставимо елемент центром у (x,y); так простіше рахувати анімацію
function put(e, { x = CX, y = CY, s = 1, r = 0, o = 1, blur = 0, rx = 0, ry = 0, z = 0, sx = 1 } = {}) {
  e.style.opacity = o;
  if (o <= 0.001) { e.style.display = 'none'; return; }
  e.style.display = '';
  const w = e._w ?? (e._w = e.offsetWidth), h = e._h ?? (e._h = e.offsetHeight);
  e.style.transform = `translate(${x - w / 2}px,${y - h / 2}px) translateZ(${z}px) rotateX(${rx}deg) rotateY(${ry}deg) rotate(${r}deg) scale(${s * sx},${s})`;
  e.style.filter = blur > 0.3 ? `blur(${blur.toFixed(1)}px)` : 'none';
}
const hide = e => { e.style.display = 'none'; };

// слово, підігнане під потрібну ширину
function word(txt, size, cls = '') { const e = el(`<div class="word ${cls}" style="font-size:${size}px">${txt}</div>`); return e; }
function fit(e, maxW, base) { if (base) e.firstChild.style.fontSize = base + 'px'; const w = e.firstChild.offsetWidth; if (w > maxW) { e.firstChild.style.fontSize = (parseFloat(e.firstChild.style.fontSize) * maxW / w) + 'px'; } e._w = undefined; e._h = undefined; }

// кінетичний вхід/вихід слова: різкий «удар» з блюром, вихід вгору
function kin(e, t, tin, tout, { x = CX, y = CY, from = 1.7, dir = 0, outDir = -1 } = {}) {
  if (t < tin || t > tout + 0.25) return hide(e);
  const a = oExp(seg(t, tin, tin + 0.28));
  const b = iCub(seg(t, tout, tout + 0.22));
  put(e, { x: x + dir * (1 - a) * 260, y: y + outDir * b * 220, s: lerp(from, 1, a) * lerp(1, 0.92, b), o: Math.min(a * 1.6, 1) * (1 - b), blur: (1 - a) * 22 + b * 18 });
}

