# Біт ролика 8: 128 BPM, енергійний, але чистий (без дисторшну). Кік на кожну долю, клеп на 2 і 4,
# відкриті хети на офбіт, 16-ковий пласк-арпеджіо, на кожну зміну екрана — «свуш».
# Доля 6: напівтемп + райзер (камера влітає в екран), доля 7: удар і фінал зі стабами на кожен рядок.
import numpy as np
from scipy.signal import butter, sosfilt
from scipy.io import wavfile
SR = 44100; B = 60 / 128; S16 = B / 4; ZOOM = 6 * B; END = 7 * B
DUR = 5.7; N = int(SR * DUR)
L = np.zeros(N); R = np.zeros(N); rng = np.random.default_rng(8)
T = lambda d: np.arange(int(d * SR)) / SR
lp = lambda x, f, o=2: sosfilt(butter(o, f, 'low', fs=SR, output='sos'), x)
hp = lambda x, f, o=2: sosfilt(butter(o, f, 'high', fs=SR, output='sos'), x)
bp = lambda x, a, b, o=2: sosfilt(butter(o, [a, b], 'band', fs=SR, output='sos'), x)
hz = lambda m: 440 * 2 ** ((m - 69) / 12)
def add(s, at, g=1.0, pan=0.0):
    i = int(at * SR)
    if i >= N: return
    j = min(N, i + len(s)); s = s[:j - i] * g
    L[i:j] += s * (1 - pan); R[i:j] += s * (1 + pan)
duck = np.ones(N)
def sc(at, depth=.55):
    i = int(at * SR); t = T(.2); e = 1 - depth * np.exp(-t * 18); j = min(N, i + len(t))
    if i < N: duck[i:j] = np.minimum(duck[i:j], e[:j - i])

def kick():
    t = T(.38); f = 50 + 170 * np.exp(-t * 38); ph = 2 * np.pi * np.cumsum(f) / SR
    click = hp(rng.standard_normal(len(t)), 3000) * np.exp(-t * 400) * .3
    return np.tanh((np.sin(ph) * np.exp(-t * 8) + click) * 1.6) * .9
def clap():
    t = T(.3); n = rng.standard_normal(len(t))
    e = np.exp(-t * 15) + .7 * np.exp(-((t - .01) * 150) ** 2) + .6 * np.exp(-((t - .021) * 150) ** 2)
    return np.tanh(bp(n, 1000, 7500) * e * 1.4) * .5
def hat(op=False, g=1):
    t = T(.2 if op else .035); return hp(rng.standard_normal(len(t)), 8000, 4) * np.exp(-t * (13 if op else 120)) * .2 * g
def swish(d=.18):
    t = T(d); n = rng.standard_normal(len(t)); out = np.zeros(len(t)); sg = int(SR * .01)
    for s0 in range(0, len(t), sg):
        f = 1500 + 7000 * (s0 / len(t)); out[s0:s0 + sg] = bp(n[s0:s0 + sg], f * .7, min(f * 1.4, 20000))
    return out * np.sin(np.pi * t / d) ** 2 * .22
def saw(f, t): return 2 * ((t * f) % 1) - 1
def pluck(m, d=.2, g=1, cut=3500):
    t = T(d); s = saw(hz(m) * .997, t) + saw(hz(m) * 1.003, t)
    return lp(s * np.exp(-t * 16), cut) * np.minimum(1, t * 600) * .07 * g
def stab(ms, d=.35, g=1):
    t = T(d); s = sum(saw(hz(m) * k, t) for m in ms for k in (.995, 1.005))
    return lp(s, 4500) * np.exp(-t * 6) * np.minimum(1, t * 500) * .05 * g
def sub(m, d):
    t = T(d); return np.tanh(np.sin(2 * np.pi * hz(m) * t) * 2) * np.minimum(1, t * 300) * np.minimum(1, (d - t) * 50) * .45
def riser(d):
    t = T(d); n = rng.standard_normal(len(t)); out = np.zeros(len(t)); sg = int(SR * .02)
    for s0 in range(0, len(t), sg):
        f = 500 + 9000 * (s0 / len(t)) ** 2; out[s0:s0 + sg] = bp(n[s0:s0 + sg], f * .7, min(f * 1.3, 20000))
    return out * np.linspace(0, 1, len(t)) ** 2 * .45
def impact():
    t = T(1.4); return (np.sin(2 * np.pi * np.cumsum(32 + 100 * np.exp(-t * 7)) / SR) * np.exp(-t * 2.6) + lp(rng.standard_normal(len(t)), 800) * np.exp(-t * 5) * .5) * .9
def crash(d=1.8):
    t = T(d); return hp(rng.standard_normal(len(t)), 5000) * np.exp(-t * 2.4) * .18
def whoosh(d=.4):
    t = T(d); return bp(rng.standard_normal(len(t)), 400, 5000) * np.sin(np.pi * t / d) ** 2 * .35

# Ля-мінор з підйомом: Am – F – C – G
CH = [[57, 60, 64], [53, 57, 60], [55, 60, 64], [55, 59, 62]]
ROOT = [45, 41, 48, 43]
ARP = [[69, 72, 76, 81], [65, 69, 72, 77], [67, 72, 76, 79], [67, 71, 74, 79]]

# ── влітання телефона
add(whoosh(.35), 0, 1, -.2); add(impact(), 0, .55); add(crash(1.2), 0, .7)
# ── грув: долі 0–5 повний, доля 6 напівтемп під наїзд
for k in range(7):
    at = k * B; ci = (k // 2) % 4 if k < 6 else 0
    if k < 6:
        add(kick(), at, 1); sc(at)
        if k % 2: add(clap(), at, 1, .05)
        add(hat(g=.8), at, 1, -.25); add(hat(True, .7), at + B / 2, 1, .25)
        add(sub(ROOT[ci], B / 2 - .02), at + B / 2, 1)   # хаус-бас на офбіт
        for s in range(4): add(pluck(ARP[ci][s], .18, .9 if s % 2 == 0 else .6, 2800 + k * 400), at + s * S16, 1, (-.3, .3)[s % 2])
        if k: add(swish(), at - .09, 1)   # «свуш» на зміну екрана
    else:
        add(kick(), at, .8)
        for s in range(8): add(clap() * (.25 + s * .1), at + s * S16 / 2, 1)
add(riser(B * 1.4), END - B * 1.4, 1.1)

# ── фінал: удар + стаб на кожен рядок (по 1/8) і тепла кода
add(impact(), END, 1); add(crash(2.2), END, 1.1); add(kick(), END, 1)
LINES_CH = [[57, 60, 64, 69], [60, 64, 67, 72], [62, 65, 69, 74], [64, 69, 72, 76]]
for i, ch in enumerate(LINES_CH): add(stab(ch, .3, 1.2), END + .05 + i * B / 2, 1, (-.15, .15)[i % 2])
pad_t = T(DUR - END); pad = sum(saw(hz(m) * k, pad_t) for m in (57, 64, 69, 72, 76) for k in (.996, 1.004))
add(lp(pad, 2000) * .022 * np.minimum(1, pad_t * 3), END, 1)
add(sub(45, 1.8), END, 1.1)
for i in range(4):  # легкий пульс хетів, щоб фінал не «вмер»
    add(hat(True, .5), END + 2 * B + i * B + B / 2, 1, .2)
for i, m in enumerate([81, 84, 88]): add(pluck(m, .4, 1.2, 5000), END + 2 * B + .1 + i * S16 * 2, 1, (-.2, .2)[i % 2])

L *= duck; R *= duck
fade = np.ones(N); fs = int(5.15 * SR); fade[fs:] = np.linspace(1, 0, N - fs) ** 1.5
L = np.tanh(L * 1.3) * fade; R = np.tanh(R * 1.3) * fade
pk = max(abs(L).max(), abs(R).max()); L /= pk / .89; R /= pk / .89
wavfile.write('music.wav', SR, (np.stack([L, R], 1) * 32767).astype(np.int16)); print('ok', DUR)
