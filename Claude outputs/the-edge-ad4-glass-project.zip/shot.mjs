import { chromium } from '/home/claude/.npm-global/lib/node_modules/playwright/index.mjs';
const times = process.argv.slice(2).map(Number);
const b = await chromium.launch({ args: ['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'] });
const pg = await b.newPage({ viewport: { width: 1080, height: 1920 } });
const errs=[]; pg.on('pageerror', e => errs.push(e.message)); pg.on('console', m => { if (m.type()==='error') errs.push(m.text()); });
await pg.goto('http://127.0.0.1:8794/index.html'); await pg.waitForFunction(() => window.__ready, null, { timeout: 30000 });
for (const t of times) { await pg.evaluate((t) => window.renderAt(t), t); await pg.screenshot({ path: `/home/claude/edge-ad4/prev/p_${t}.jpg`, type: 'jpeg', quality: 80 }); }
console.log(JSON.stringify(errs)); await b.close();
