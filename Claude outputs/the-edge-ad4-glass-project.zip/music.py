# Біт ролика 4: 140 BPM, жорсткий trap/phonk — дисторшн-808, ковбел, рол хетів.
# Все синтезовано з нуля, без чужих семплів, тож ніяких проблем з АП
import numpy as np
from scipy.signal import butter, sosfilt
from scipy.io import wavfile
SR = 44100; B = 60 / 140
T1, T2, T3, T4, T5 = 6 * B, 12 * B, 20 * B, 26 * B, 30 * B
DUR = 40 * B + 0.6; N = int(SR * DUR)
L = np.zeros(N); R = np.zeros(N); rng = np.random.default_rng(21)
T = lambda d: np.arange(int(d * SR)) / SR
lp = lambda x, f, o=2: sosfilt(butter(o, f, 'low', fs=SR, output='sos'), x)
hp = lambda x, f, o=2: sosfilt(butter(o, f, 'high', fs=SR, output='sos'), x)
bp = lambda x, a, b, o=2: sosfilt(butter(o, [a, b], 'band', fs=SR, output='sos'), x)
hz = lambda m: 440 * 2 ** ((m - 69) / 12)
def add(s, at, g=1.0, pan=0.0, buf=None):
    i = int(at * SR)
    if i >= N or i + len(s) <= 0: return
    if i < 0: s = s[-i:]; i = 0
    j = min(N, i + len(s)); s = s[:j - i] * g
    if buf is None: L[i:j] += s * (1 - pan); R[i:j] += s * (1 + pan)
    else: buf[i:j] += s
duck = np.ones(N)
def sc(at, depth=.75):
    i = int(at * SR); t = T(.28); e = 1 - depth * np.exp(-t * 14); j = min(N, i + len(t))
    if i < N: duck[i:j] = np.minimum(duck[i:j], e[:j - i])

# ── інструменти ──
def kick():
    t = T(.45); f = 45 + 160 * np.exp(-t * 32); ph = 2 * np.pi * np.cumsum(f) / SR
    click = hp(rng.standard_normal(len(t)), 2000) * np.exp(-t * 300) * .5
    return np.tanh((np.sin(ph) * np.exp(-t * 7) + click) * 2.2) * .9
def clap():
    t = T(.3); n = rng.standard_normal(len(t))
    e = np.exp(-t * 16) + .7 * np.exp(-((t - .012) * 140) ** 2) + .6 * np.exp(-((t - .024) * 140) ** 2)
    body = np.sin(2 * np.pi * 190 * t) * np.exp(-t * 30) * .5   # «тіло» снейра
    return np.tanh((bp(n, 900, 6000) * e + body) * 1.6) * .6
def hat(open_=False, g=1):
    t = T(.18 if open_ else .04); return hp(rng.standard_normal(len(t)), 8000, 4) * np.exp(-t * (14 if open_ else 110)) * .22 * g
def cowbell(m, d=.22):
    # фонк-ковбел: два квадрати з неточним інтервалом + смуга
    t = T(d); f = hz(m)
    s = np.sign(np.sin(2 * np.pi * f * t)) + .8 * np.sign(np.sin(2 * np.pi * f * 1.483 * t))
    return bp(s, f * .8, min(f * 5, 15000)) * (np.exp(-t * 18) * .8 + .2 * np.exp(-t * 6)) * .2
def crash(d=1.6):
    t = T(d); return hp(rng.standard_normal(len(t)), 5000) * np.exp(-t * 2.4) * .22
def impact():
    t = T(1.4); return (np.sin(2 * np.pi * np.cumsum(32 + 90 * np.exp(-t * 7)) / SR) * np.exp(-t * 2.6) + lp(rng.standard_normal(len(t)), 700) * np.exp(-t * 5) * .6) * .9
def whoosh(d=.5):
    t = T(d); return bp(rng.standard_normal(len(t)), 600, 5000) * np.sin(np.pi * t / d) ** 2 * .3
def riser(d):
    t = T(d); n = rng.standard_normal(len(t)); out = np.zeros(len(t)); sg = int(SR * .02)
    for s0 in range(0, len(t), sg):
        f = 400 + 9000 * (s0 / len(t)) ** 2; out[s0:s0 + sg] = bp(n[s0:s0 + sg], f * .7, min(f * 1.3, 20000))
    return out * np.linspace(0, 1, len(t)) ** 2 * .45
def click(g=1):
    t = T(.025); return hp(rng.standard_normal(len(t)), 3500) * np.exp(-t * 200) * .35 * g

# ── 808 з глайдами і дисторшном — головне «качання» ──
bass = np.zeros(N)
def b808(at, m, dur, glide=None):
    t = T(dur); f0 = hz(m)
    f = np.full(len(t), f0)
    if glide is not None:  # ковзання в кінці ноти
        k = np.clip((t - dur * .55) / (dur * .35), 0, 1); f = f0 * (hz(glide) / f0) ** k
    f = f * (1 + 1.2 * np.exp(-t * 60))  # удар на атаці
    s = np.sin(2 * np.pi * np.cumsum(f) / SR) * np.minimum(1, t * 300) * np.minimum(1, (dur - t) * 40)
    add(np.tanh(s * 3.2), at, 1, 0, bass)

def drums(t0, t1, cow=True, full=True):
    """8-дольний патерн, повторюється від t0 до t1"""
    k = 0
    while t0 + k * B < t1 - 1e-3:
        cyc = k % 8; at = t0 + k * B
        # кік: 0, 1.5, 4, 5.5 (+3.25 у кожному другому такті)
        for kb in (0, 1.5, 4, 5.5) + ((3.25,) if (k // 8) % 2 else ()):
            if cyc == int(kb) and t0 + (k - cyc + kb) * B < t1: add(kick(), t0 + (k - cyc + kb) * B, 1); sc(t0 + (k - cyc + kb) * B)
        if cyc in (2, 6): add(clap(), at, 1); add(hat(True, .6), at, 1, .2)
        # хети вісімками + роли
        for e in (0, .5):
            add(hat(g=.9 if e == 0 else .6), at + e * B, 1, -.25)
        if cyc == 3 and full:
            for r in range(6): add(hat(g=.5 + r * .08), at + .5 * B + r * B / 12, 1, .25)
        if cyc == 7 and full:
            for r in range(8): add(hat(g=.4 + r * .07), at + r * B / 8, 1, .3)
        k += 1
    # 808 — двотактова фраза у фа-мінорі
    BL = [(0, 29, 1.4, None), (1.5, 29, .9, None), (2.5, 32, 1.4, 29), (4, 27, 1.4, None), (5.5, 29, .9, None), (6.5, 36, 1.4, 29)]
    k = 0
    while t0 + k * 8 * B < t1 - 1e-3:
        for bb, m, d, g in BL:
            at = t0 + (k * 8 + bb) * B
            if at < t1 - .05: b808(at, m, min(d * B, t1 - at), g)
        k += 1
    if cow:
        # мелодія ковбела шістнадцятими: «фонкова» фраза
        MEL = [72, None, 72, None, 68, None, 72, 75, None, 72, None, 68, 65, None, 68, None,
               72, None, 72, None, 75, None, 77, None, 75, 72, None, 68, None, 70, 68, None]
        k = 0
        while t0 + k * B / 2 < t1 - 1e-3:
            m = MEL[k % 32]
            if m: add(cowbell(m), t0 + k * B / 2, 1, (-.15, .15)[k % 2])
            k += 1

# ── пед (темний, детюн) ──
tt = np.arange(N) / SR; pad = np.zeros(N)
for m in (53, 56, 60, 63):
    for det in (-.12, .12): pad += 2 * ((tt * hz(m + det)) % 1) - 1
pad = lp(pad, 900) * .025

# ═════ ІНТРО 0–T1: фільтровано, друк, клік, підйом, пауза перед дропом
for i in range(22): add(click(.8), .3 + i * (.85 / 22), 1, (-.3, .3)[i % 2])
add(click(1.8), 1.45, 1); add(whoosh(.35), 1.3, .8)
for i in range(3): add(cowbell(72 + i * 3, .3), 1.55 + i * .1, .7)
intro_cow = np.zeros(N)
for k in range(12):
    m = [72, None, 72, None, 68, None, 72, 75, None, 72, None, 68][k]
    if m: add(cowbell(m), k * B / 2, 1, 0, intro_cow)
intro_cow = lp(intro_cow, 1200) * 1.2; L += intro_cow; R += intro_cow
add(riser(1.0), T1 - 1.05, 1)
# ═════ ДРОП 1 T1–T4
add(impact(), T1, .8); add(crash(), T1, 1)
drums(T1, T4)
add(whoosh(.6), T2 - .35, 1); add(crash(1.0), T2, .7)
add(whoosh(.6), T3 - .35, 1); add(crash(1.0), T3, .7)
# ═════ БРЕЙК T4–T5: тиша, орб, снейр-рол на підйом
add(impact(), T4, .5)
for i in range(16):
    at = T4 + 2 * B + i * (2 * B / 16)
    if at < T5 - .06: add(clap() * (.25 + i * .045), at, 1)
add(riser(2 * B), T5 - 2 * B - .05, 1.1)
# ═════ ДРОП 2 T5–кінець
add(impact(), T5, 1.0); add(crash(2.0), T5, 1.1)
drums(T5, 40 * B)
add(impact(), 40 * B, .7); add(crash(1.5), 40 * B, .6)
b808(40 * B, 29, .6)

# ── мікс ──
env = np.ones(N)
env[:int(T1 * SR)] = .0  # 808 немає в інтро
L += np.tanh(bass * 1.2) * .48 * env * duck; R += np.tanh(bass * 1.2) * .48 * env * duck
padg = np.where((tt < T1) | ((tt >= T4) & (tt < T5)) | (tt >= 40 * B), 1.6, .6)
L += pad * padg * duck; R += pad * padg * duck
fade = np.ones(N); fs = int((40 * B + .1) * SR); fade[fs:] = np.linspace(1, 0, N - fs) ** 1.5
L = np.tanh(L * 1.35) * fade; R = np.tanh(R * 1.35) * fade
pk = max(abs(L).max(), abs(R).max()); L /= pk / .89; R /= pk / .89
wavfile.write('music.wav', SR, (np.stack([L, R], 1) * 32767).astype(np.int16)); print('ok', DUR)
