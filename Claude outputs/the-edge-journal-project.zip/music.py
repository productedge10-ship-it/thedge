# Музика ролика 2: 120 BPM, 15 с. Синтез з нуля, без чужих семплів.
import numpy as np
from scipy.signal import butter, sosfilt
from scipy.io import wavfile
SR=44100; DUR=15.0; N=int(SR*DUR); BEAT=0.5
L=np.zeros(N); R=np.zeros(N); rng=np.random.default_rng(11)
T=lambda d: np.arange(int(d*SR))/SR
lp=lambda x,f,o=2: sosfilt(butter(o,f,'low',fs=SR,output='sos'),x)
hp=lambda x,f,o=2: sosfilt(butter(o,f,'high',fs=SR,output='sos'),x)
bp=lambda x,a,b,o=2: sosfilt(butter(o,[a,b],'band',fs=SR,output='sos'),x)
hz=lambda m: 440*2**((m-69)/12)
def add(s,at,g=1.0,pan=0.0):
    i=int(at*SR); 
    if i>=N: return
    j=min(N,i+len(s)); s=s[:j-i]*g; L[i:j]+=s*(1-pan); R[i:j]+=s*(1+pan)
duck=np.ones(N)
def sc(at):
    i=int(at*SR); t=T(0.3); e=1-0.7*np.exp(-t*13); j=min(N,i+len(t)); duck[i:j]=np.minimum(duck[i:j],e[:j-i])
def kick(g=1):
    t=T(0.4); f=48+120*np.exp(-t*30); ph=2*np.pi*np.cumsum(f)/SR
    return (np.sin(ph)*np.exp(-t*8)+0.2*np.sin(2*ph)*np.exp(-t*35))*g
def clap():
    t=T(0.22); n=rng.standard_normal(len(t))
    return bp(n,1000,5500)*(np.exp(-t*20)+0.6*np.exp(-((t-.011)*130)**2)+.5*np.exp(-((t-.022)*130)**2))*0.5
def hat(o=False):
    t=T(0.2 if o else 0.045); return hp(rng.standard_normal(len(t)),7500,4)*np.exp(-t*(16 if o else 90))*0.2
def bell(m,d=0.9,g=1):
    t=T(d); f=hz(m)
    s=np.sin(2*np.pi*f*t)+0.5*np.sin(2*np.pi*f*2.01*t)*np.exp(-t*6)+0.25*np.sin(2*np.pi*f*3.02*t)*np.exp(-t*9)
    return s*np.exp(-t*5.5)*np.minimum(1,t*400)*0.35*g
def blip(m,g=1):
    t=T(0.25); s=np.sign(np.sin(2*np.pi*hz(m)*t))*0.5+np.sin(2*np.pi*hz(m)*t)
    return lp(s,1400)*np.exp(-t*14)*0.3*g
def click():
    t=T(0.03); return hp(rng.standard_normal(len(t)),3000)*np.exp(-t*160)*0.5
def thump():
    t=T(0.35); return np.sin(2*np.pi*np.cumsum(55+90*np.exp(-t*25))/SR)*np.exp(-t*9)
def whoosh(d=0.5):
    t=T(d); return bp(rng.standard_normal(len(t)),700,4500)*np.sin(np.pi*t/d)**2*0.35
def riser(d):
    t=T(d); n=rng.standard_normal(len(t)); out=np.zeros(len(t)); seg=int(SR*0.02)
    for s0 in range(0,len(t),seg):
        f=500+8500*(s0/len(t))**2; out[s0:s0+seg]=bp(n[s0:s0+seg],f*0.7,min(f*1.3,20000))
    return out*np.linspace(0,1,len(t))**2*0.5
def impact():
    t=T(1.3); return (np.sin(2*np.pi*np.cumsum(36+70*np.exp(-t*6))/SR)*np.exp(-t*3)+lp(rng.standard_normal(len(t)),800)*np.exp(-t*5)*0.5)*0.9
# акорди Fm Db Ab Eb
prog=[(41,[56,60,63]),(37,[56,61,65]),(44,[60,63,68]),(39,[58,63,67])]
chord=lambda t: prog[int(t//2)%4]
GROOVE=(3.0,12.5)
# ---------- S1: кінетичні удари ----------
for k,at in enumerate((0.0,0.5,1.0,1.5)):
    add(thump(),at,0.8+0.1*k); add(click(),at,0.8,(-.3,.3)[k%2]); sc(at)
add(riser(0.5),1.5,0.8)
# ---------- S2 ----------
add(whoosh(0.45),1.95,1.2); add(bell(88,1.0),2.55,0.9,-.2); add(bell(95,1.1),2.68,0.8,.2)
# ---------- грув ----------
for b in range(int(DUR/BEAT)):
    at=b*BEAT
    if GROOVE[0]<=at<GROOVE[1]:
        add(kick(),at,0.95); sc(at)
        if b%2==1: add(clap(),at,0.85)
        add(hat(True),at+0.25,0.75,0.25)
        add(hat(),at+0.125,0.35,-0.3); add(hat(),at+0.375,0.35,-0.3)
# бас: октавний хаус-бас на вісімки
bass=np.zeros(N)
for k in range(int(DUR/0.25)):
    at=k*0.25
    if not (GROOVE[0]<=at<GROOVE[1]): continue
    root,_=chord(at); m=root+(12 if k%2 else 0)
    t=T(0.22); s=2*((t*hz(m))%1)-1; s=lp(s,700)*np.exp(-t*6)
    i=int(at*SR); j=min(N,i+len(s)); bass[i:j]+=s[:j-i]
L+=np.tanh(bass*1.5)*duck*0.42; R+=np.tanh(bass*1.5)*duck*0.42
# акордові стаби на «і»
for b in range(int(DUR/BEAT)):
    at=b*BEAT+0.25
    if not (GROOVE[0]<=at<GROOVE[1]): continue
    _,ch=chord(at); t=T(0.18); s=np.zeros(len(t))
    for m in ch:
        for det in (-0.07,0.07): s+=2*((t*hz(m+det))%1)-1
    s=lp(s,2600)*np.exp(-t*12)*0.06
    add(s,at,1,0.15)
# пед на початку і в кінці
tt=np.arange(N)/SR; pad=np.zeros(N)
for bar in range(8):
    _,ch=chord(bar*2); i=int(bar*2*SR); j=min(N,int((bar*2+2)*SR)); t=tt[i:j]-bar*2
    for m in ch:
        for det in (-0.1,0.1): pad[i:j]+=np.sin(2*np.pi*hz(m-12+det)*t)*0.1
    pad[i:j]*=np.minimum(1,t*2)*np.minimum(1,(2-t)*2)
pad=lp(pad,1500)*(0.25+0.75*(tt<3.0)+0.6*(tt>=12.5)); L+=pad*0.55; R+=pad*0.55
# ---------- S3: угоди приходять — дзвіночки ----------
wins=[1,1,0,0,1,1,1,0]; scale=[84,86,88,91,93,96,98,100]; w=0
for i,win in enumerate(wins):
    at=3.5+i*0.5+0.06
    add(whoosh(0.25),at-0.12,0.7,(-.5,.5)[i%2])
    if win: add(bell(scale[min(w,7)],0.8),at,1.0,(-.25,.25)[i%2]); add(bell(scale[min(w,7)]+7,0.6),at+0.07,0.5); w+=1
    else: add(blip(64),at,1.0); add(blip(61),at+0.08,0.8)
# ---------- переходи ----------
add(whoosh(0.7),7.65,1.3); add(impact(),8.0,0.6)
add(riser(1.25),8.35,0.7); add(bell(91,1.2),9.6,0.8); add(bell(98,1.0),9.66,0.6)
add(whoosh(0.5),10.3,1.1); add(bell(86,0.9),11.15,0.7)
add(riser(0.6),11.95,0.8); add(impact(),12.55,1.0)
add(bell(80,2.2),12.6,0.7,-.2); add(bell(87,2.2),12.66,0.6,.2); add(bell(92,2.2),12.72,0.5)
add(bell(99,1.2),13.5,0.6)
# ---------- мастер ----------
fade=np.ones(N); fs=int(14.1*SR); fade[fs:]=np.linspace(1,0,N-fs)**1.6
L=np.tanh(L*1.15)*fade; R=np.tanh(R*1.15)*fade
pk=max(abs(L).max(),abs(R).max()); L/=pk/0.89; R/=pk/0.89
wavfile.write('music.wav',SR,(np.stack([L,R],1)*32767).astype(np.int16)); print('ok')
