# Музика ролика 3: 124 BPM, 15 с, вертикаль. Синтез з нуля, без чужих семплів.
import numpy as np
from scipy.signal import butter, sosfilt
from scipy.io import wavfile
SR=44100; DUR=16.0; N=int(SR*DUR); BEAT=60/124
L=np.zeros(N); R=np.zeros(N); rng=np.random.default_rng(11)
T=lambda d: np.arange(int(d*SR))/SR
lp=lambda x,f,o=2: sosfilt(butter(o,f,'low',fs=SR,output='sos'),x)
hp=lambda x,f,o=2: sosfilt(butter(o,f,'high',fs=SR,output='sos'),x)
bp=lambda x,a,b,o=2: sosfilt(butter(o,[a,b],'band',fs=SR,output='sos'),x)
hz=lambda m: 440*2**((m-69)/12)
def add(s,at,g=1.0,pan=0.0):
    i=int(at*SR); 
    if i>=N: return
    j=min(N,i+len(s)); s=s[:j-i]*g; L[i:j]+=s*(1-pan); R[i:j]+=s*(1+pan)
duck=np.ones(N)
def sc(at):
    i=int(at*SR); t=T(0.3); e=1-0.7*np.exp(-t*13); j=min(N,i+len(t)); duck[i:j]=np.minimum(duck[i:j],e[:j-i])
def kick(g=1):
    t=T(0.4); f=48+120*np.exp(-t*30); ph=2*np.pi*np.cumsum(f)/SR
    return (np.sin(ph)*np.exp(-t*8)+0.2*np.sin(2*ph)*np.exp(-t*35))*g
def clap():
    t=T(0.22); n=rng.standard_normal(len(t))
    return bp(n,1000,5500)*(np.exp(-t*20)+0.6*np.exp(-((t-.011)*130)**2)+.5*np.exp(-((t-.022)*130)**2))*0.5
def hat(o=False):
    t=T(0.2 if o else 0.045); return hp(rng.standard_normal(len(t)),7500,4)*np.exp(-t*(16 if o else 90))*0.2
def bell(m,d=0.9,g=1):
    t=T(d); f=hz(m)
    s=np.sin(2*np.pi*f*t)+0.5*np.sin(2*np.pi*f*2.01*t)*np.exp(-t*6)+0.25*np.sin(2*np.pi*f*3.02*t)*np.exp(-t*9)
    return s*np.exp(-t*5.5)*np.minimum(1,t*400)*0.35*g
def blip(m,g=1):
    t=T(0.25); s=np.sign(np.sin(2*np.pi*hz(m)*t))*0.5+np.sin(2*np.pi*hz(m)*t)
    return lp(s,1400)*np.exp(-t*14)*0.3*g
def click():
    t=T(0.03); return hp(rng.standard_normal(len(t)),3000)*np.exp(-t*160)*0.5
def thump():
    t=T(0.35); return np.sin(2*np.pi*np.cumsum(55+90*np.exp(-t*25))/SR)*np.exp(-t*9)
def whoosh(d=0.5):
    t=T(d); return bp(rng.standard_normal(len(t)),700,4500)*np.sin(np.pi*t/d)**2*0.35
def riser(d):
    t=T(d); n=rng.standard_normal(len(t)); out=np.zeros(len(t)); seg=int(SR*0.02)
    for s0 in range(0,len(t),seg):
        f=500+8500*(s0/len(t))**2; out[s0:s0+seg]=bp(n[s0:s0+seg],f*0.7,min(f*1.3,20000))
    return out*np.linspace(0,1,len(t))**2*0.5
def impact():
    t=T(1.3); return (np.sin(2*np.pi*np.cumsum(36+70*np.exp(-t*6))/SR)*np.exp(-t*3)+lp(rng.standard_normal(len(t)),800)*np.exp(-t*5)*0.5)*0.9

# акорди: Fm Db Ab Eb — темний, але «дорогий» настрій
prog=[(41,[56,60,63]),(37,[56,61,65]),(44,[60,63,68]),(39,[58,63,67])]
def stab(at,ch,g=1,pan=.15,d=.2):
    t=T(d); s=np.zeros(len(t))
    for m in ch:
        for det in (-0.07,0.07): s+=2*((t*hz(m+det))%1)-1
    add(lp(s,2800)*np.exp(-t*11)*0.06*g,at,1,pan)
bass=np.zeros(N)
def bassnote(at,m,d=0.2):
    t=T(d); s=2*((t*hz(m))%1)-1; s=lp(s,650)*np.exp(-t*6); i=int(at*SR); j=min(N,i+len(s)); bass[i:j]+=s[:j-i]
# грув стартує заново від кожної сцени, щоб удари падали точно в монтаж
def groove(t0,t1,half=False):
    k=0
    while t0+k*BEAT<t1-0.02:
        at=t0+k*BEAT; root,ch=prog[(k//4)%4]
        if not half or k%2==0: add(kick(),at,0.95); sc(at)
        if (k%2==1 and not half) or (half and k%4==2): add(clap(),at,0.85)
        add(hat(True),at+BEAT/2,0.7,0.25); add(hat(),at+BEAT/4,0.3,-0.3); add(hat(),at+3*BEAT/4,0.3,-0.3)
        for e in range(2): bassnote(at+e*BEAT/2,root+(12 if e else 0))
        stab(at+BEAT/2,ch,0.9)
        k+=1
# ── S1 «раніше»: тихо, удар + пінг телеграму
add(impact(),0.0,0.55); add(click(),0.05,0.9)
add(blip(83),0.47,0.8,.3); add(blip(90),0.55,0.7,.3)
add(riser(0.55),0.9,0.7)
# ── S2 угоди скрізь: грув + поп на кожну іконку (висхідна гама)
groove(1.45,4.9)
add(click(),1.5,0.8,-.3); add(click(),1.5+BEAT,0.8,.3)
for i,at in enumerate([1.62,1.78,1.94,2.10,2.26,2.42,2.58,2.74]):
    add(bell([77,80,84,87,89,92,96,99][i],0.5),at,0.7,(-.4,.4)[i%2])
add(whoosh(1.4),1.75,0.45)
# ── S3 колаж: свист на кожен скрін
add(impact(),3.4,0.5)
for i in range(9): add(whoosh(0.35),3.32+i*0.12+0.35,0.55,(-.6,.6)[i%2])
add(click(),3.6,0.9)
# ── S4 «сповільнюється»: півтемпу + звук, що «зупиняється»
groove(4.9,5.85,half=True)
add(click(),4.95,0.9); add(click(),5.3,0.9)
t=T(1.0); f=hz(53)*np.linspace(1,0.25,len(t))**1.5; s=lp(2*((np.cumsum(f)/SR)%1)-1,900)*np.linspace(1,0,len(t))**0.5*0.35
add(s,5.3,1.0)
add(riser(0.45),5.85,0.8)
# ── S5 глітч: обривки шуму і бас в розсинхроні
add(impact(),6.3,0.9)
for i in range(10):
    at=6.32+i*0.105
    if i%3!=2: add(hp(rng.standard_normal(int(0.04*SR)),2000)*0.35,at,1,(-.5,.5)[i%2])
    add(blip(52+(i*5)%12,0.8),at+0.05,0.6)
add(riser(0.5),6.9,1.0)
# ── S6 телефон: повний грув
add(impact(),7.4,0.8); groove(7.4,12.85)
add(whoosh(0.6),7.85,0.8)
for i in range(6): add(bell([84,87,91,94,96,99][i],0.6),8.25+i*0.1,0.6,(-.5,.5)[i%2])
add(whoosh(0.4),9.3,0.9,.4)
add(bell(91,0.7),8.75,0.5)
# ── S7 картки: глухі удари на кожну
add(whoosh(0.5),10.45,1.0)
for i,dl in enumerate([0,.1,.22,.34,.48,.62]): add(thump(),10.85+dl,0.45,(-.3,.3)[i%2]); add(click(),10.85+dl,0.5)
add(riser(0.8),12.1,0.9)
# ── S8 лого: удар, акорд, клацання букв
add(impact(),12.9,1.0)
for i,m in enumerate([68,75,80,84]): add(bell(m,2.2),12.92+i*0.05,0.55,(-.3,.1,.3,-.1)[i])
for i in range(7): add(click(),13.27+i*0.05,0.5,(-.4,.4)[i%2])
add(bell(92,1.0),14.02,0.6); add(bell(99,1.0),14.08,0.4)
L+=np.tanh(bass*1.5)*duck*0.4; R+=np.tanh(bass*1.5)*duck*0.4
# пед — фон від початку до кінця, сильніше на краях
tt=np.arange(N)/SR; pad=np.zeros(N)
for bar in range(8):
    _,ch=prog[bar%4]; i=int(bar*2*SR); j=min(N,int((bar*2+2)*SR)); t=tt[i:j]-bar*2
    for m in ch:
        for det in (-0.1,0.1): pad[i:j]+=np.sin(2*np.pi*hz(m-12+det)*t)*0.1
    pad[i:j]*=np.minimum(1,t*2)*np.minimum(1,(2-t)*2)
pad=lp(pad,1500)*(0.3+0.7*(tt<1.45)+0.7*(tt>=12.9)); L+=pad*0.55; R+=pad*0.55
fade=np.ones(N); fs=int(15.2*SR); fade[fs:]=np.linspace(1,0,N-fs)**1.6
L=np.tanh(L*1.15)*fade; R=np.tanh(R*1.15)*fade
pk=max(abs(L).max(),abs(R).max()); L/=pk/0.89; R/=pk/0.89
wavfile.write('music_main.wav',SR,(np.stack([L,R],1)*32767).astype(np.int16)); print('ok')
