# Звук хука: дзинькають сповіщення, вібрація, наростає напруга — і різка тиша на «знайомо?»
# Потім склеюємо з основною музикою з 1.45 с (там стартує грув «угоди скрізь»)
import numpy as np
from scipy.io import wavfile
from scipy.signal import butter, sosfilt
SR=44100; HOOK=2.9; OLD=1.45; N=int(HOOK*SR)
L=np.zeros(N); R=np.zeros(N); rng=np.random.default_rng(3)
T=lambda d: np.arange(int(d*SR))/SR
hp=lambda x,f: sosfilt(butter(2,f,'high',fs=SR,output='sos'),x)
lp=lambda x,f: sosfilt(butter(2,f,'low',fs=SR,output='sos'),x)
bp=lambda x,a,b: sosfilt(butter(2,[a,b],'band',fs=SR,output='sos'),x)
def add(s,at,g=1,pan=0):
    i=int(at*SR); j=min(N,i+len(s))
    if j<=i: return
    L[i:j]+=s[:j-i]*g*(1-pan); R[i:j]+=s[:j-i]*g*(1+pan)
def ding(f1,f2):
    # дві короткі ноти, як типовий пуш
    t=T(0.32); s=np.zeros(len(t)); h=int(0.07*SR)
    for k,(f,o) in enumerate(((f1,0),(f2,h))):
        tt=t[:len(t)-o]; s[o:]+=(np.sin(2*np.pi*f*tt)+0.3*np.sin(2*np.pi*f*2*tt))*np.exp(-tt*16)
    return s*0.32
def buzz():
    t=T(0.16); return lp(np.sign(np.sin(2*np.pi*170*t)),600)*(0.5+0.5*np.sin(2*np.pi*28*t))*np.exp(-t*4)*0.22
NT=[0.04+i*0.12 for i in range(10)]
pairs=[(1568,2093),(1319,1760),(1760,2349),(1568,2093),(1175,1568),(2093,2637),(1397,1865),(1319,1760),(1568,2093),(1760,2349)]
for i,(at,(a,b)) in enumerate(zip(NT,pairs)):
    if at<1.24:
        add(ding(a,b),at,0.75+0.03*i,(-.45,.45)[i%2])
        if i%3==0: add(buzz(),at,1.0)
# напруга: шум, що піднімається
t=T(1.24); n=rng.standard_normal(len(t)); out=np.zeros(len(t)); seg=int(SR*0.02)
for s0 in range(0,len(t),seg):
    f=300+5000*(s0/len(t))**2; out[s0:s0+seg]=bp(n[s0:s0+seg],f*0.7,f*1.3)
add(out*np.linspace(0,1,len(t))**2*0.35,0)
# низький гул наростає
add(np.sin(2*np.pi*55*t)*np.linspace(0,1,len(t))*0.25,0)
# «стоп»: глухий удар і різкий обрив усього
cut=int(1.24*SR); L[cut:]*=0; R[cut:]*=0
t=T(0.66); hit=np.sin(2*np.pi*np.cumsum(40+80*np.exp(-t*20))/SR)*np.exp(-t*5)*0.9
add(hit,1.24)
add(hp(rng.standard_normal(int(0.05*SR)),2500)*np.exp(-T(0.05)*80)*0.5,1.26)
# тихий тон-«дзвін у вухах» на паузі
t=T(1.5); add(np.sin(2*np.pi*3100*t)*np.minimum(1,t*8)*np.minimum(1,(1.5-t)*3)*0.025,1.3)
# тихий низький дрон, поки читають «знайомо?»
t=T(1.6); add(np.sin(2*np.pi*55*t)*np.minimum(1,t*3)*0.12+np.sin(2*np.pi*82.4*t)*np.minimum(1,t*2)*0.05,1.3)
# короткий райзер у грув
t=T(0.6); n=rng.standard_normal(len(t)); add(hp(n,2500)*np.linspace(0,1,len(t))**2.5*0.35,2.3)
SRm,m=wavfile.read('music_main.wav'); m=m.astype(np.float64)/32767
H=np.stack([L,R],1); pk=np.abs(H).max(); H*=0.85/pk
B=60/124; h=int((7.4+B)*SR); mm=np.concatenate([m[:h],m[h:h+int(B*SR)],m[h:]])  # +1 доля на кадрі «журнал THE EDGE»
full=np.concatenate([H,mm[int(OLD*SR):]])
f=int(0.006*SR); full[N:N+f]*=np.linspace(0,1,f)[:,None]  # мікро-фейд на стику, щоб не клацало
wavfile.write('music.wav',SR,(np.clip(full,-1,1)*32767).astype(np.int16)); print(len(full)/SR)
